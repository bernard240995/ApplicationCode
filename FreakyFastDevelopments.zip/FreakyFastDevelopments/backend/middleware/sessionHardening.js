export function onLoginSuccess(req, res){
  // If using express-session, rotate the session ID to prevent fixation.
  if (req.session && typeof req.session.regenerate === "function"){
    req.session.regenerate(()=>{});
  }
  // Example cookie hardening for session cookies
  const isProd = process.env.NODE_ENV === "production";
  res.cookie && res.cookie("sid_flags", "1", {
    httpOnly: true, secure: isProd, sameSite: isProd ? "none" : "lax", // adjust to your flow
    maxAge: 7*24*3600*1000
  });
}
