const EMAIL_RE = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/ig;
const CARD_RE = /\b(?:\d[ -]*?){13,19}\b/g;

export default function logRedactSample(req,res,next){
  if (process.env.LOG_SAMPLE_RATE && Math.random() > Number(process.env.LOG_SAMPLE_RATE)) return next();
  const clean = (s)=> String(s||'').replace(EMAIL_RE, '[redacted-email]').replace(CARD_RE, '[redacted-card]');
  const entry = {
    method: req.method,
    path: req.originalUrl.split('?')[0],
    ip: req.ip,
    ua: clean(req.headers['user-agent']),
    body: clean(JSON.stringify(req.body||{})).slice(0, 2000)
  };
  try{ console.info('[req]', JSON.stringify(entry)); }catch{}
  next();
}
