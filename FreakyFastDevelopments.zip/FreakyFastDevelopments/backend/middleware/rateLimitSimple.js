const buckets = new Map();
export default function rateLimitSimple({ windowMs=60000, limit=60 } = {}){
  return (req,res,next)=>{
    const key = (req.ip||"ip")+":"+(req.path||"/");
    const now = Date.now();
    let b = buckets.get(key);
    if (!b || now - b.start > windowMs){ b = { start: now, count: 0 }; buckets.set(key,b); }
    b.count += 1;
    if (b.count > limit){
      res.setHeader("Retry-After", String(Math.ceil((b.start+windowMs-now)/1000)));
      return res.status(429).json({ error: "Too Many Requests" });
    }
    next();
  };
}
