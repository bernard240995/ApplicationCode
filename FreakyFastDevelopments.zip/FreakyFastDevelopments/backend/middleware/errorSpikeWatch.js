import { notifySlack } from "../services/alerting.js";

const BUCKET_MS = 60 * 1000;
const WINDOW_MIN = 5;
const MAX_BUCKETS = WINDOW_MIN;
const buckets = []; // [{ts, total, error}]

function currentBucket(){
  const ts = Math.floor(Date.now() / BUCKET_MS) * BUCKET_MS;
  let b = buckets.find(x => x.ts === ts);
  if (!b){
    b = { ts, total:0, error:0 };
    buckets.push(b);
    while (buckets.length > MAX_BUCKETS) buckets.shift();
  }
  return b;
}

export default function errorSpikeWatch(req, res, next){
  const b = currentBucket();
  const end = res.end;
  res.end = function (...args){
    try{
      b.total += 1;
      const code = res.statusCode || 200;
      if (code >= 500) b.error += 1;
      // compute ratio over window
      const total = buckets.reduce((a,x)=>a+x.total,0);
      const errors = buckets.reduce((a,x)=>a+x.error,0);
      const ratio = total ? (errors/total) : 0;
      if (ratio > 0.05){
        notifySlack(`Alert: 5xx error ratio ${(ratio*100).toFixed(1)}% over last ${WINDOW_MIN}m`, "error-spike", 10*60*1000);
      }
    }catch(_){}
    return end.apply(this, args);
  };
  next();
}
