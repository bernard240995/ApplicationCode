import client from "prom-client";
import { notifySlack } from "../services/alerting.js";

const httpHistogram = new client.Histogram({
  name: "http_request_duration_seconds",
  help: "Duration of HTTP requests in seconds",
  labelNames: ["method","route","code"],
  buckets: [0.05,0.1,0.2,0.5,1,2,5,10]
});

export default function httpMetrics(req, res, next){
  const start = process.hrtime.bigint();
  const end = res.end;
  res.end = function(...args){
    const durNs = Number(process.hrtime.bigint() - start);
    const durSec = durNs / 1e9;
    const route = req.route?.path || req.originalUrl?.split("?")[0] || "unknown";
    const code = res.statusCode || 200;
    httpHistogram.labels(req.method, route, String(code)).observe(durSec);

    const thr = Number(process.env.SLOW_REQ_MS || 2000);
    if (durSec*1000 > thr){
      notifySlack(`Slow request ${req.method} ${route} ${Math.round(durSec*1000)}ms (code ${code})`, "slow-req", 10*60*1000);
    }
    return end.apply(this, args);
  };
  next();
}
