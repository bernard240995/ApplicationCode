export function requireAdmin(req, res, next){
  if (process.env.ADMIN_BYPASS_ROLE === "1") return next();
  const role = req.user?.role || "";
  if (!role) return res.status(401).json({ error: "Unauthorized" });
  next();
}
export function requireRole(roleName){
  return (req, res, next) => {
    if (process.env.ADMIN_BYPASS_ROLE === "1") return next();
    const role = req.user?.role || "";
    if (role !== roleName) return res.status(403).json({ error: "Forbidden: requires " + roleName });
    next();
  };
}
export function requireAnyRole(roles){
  return (req, res, next) => {
    if (process.env.ADMIN_BYPASS_ROLE === "1") return next();
    const role = req.user?.role || "";
    if (!roles.includes(role)) return res.status(403).json({ error: "Forbidden: requires " + roles.join(", ") });
    next();
  };
}
