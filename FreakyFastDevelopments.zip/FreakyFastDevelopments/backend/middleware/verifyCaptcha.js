// backend/middleware/verifyCaptcha.js
import fetch from 'node-fetch';

export async function verifyCaptcha(req, res, next) {
  try {
    const token = req.body['g-recaptcha-response'] || req.body.token;
    if (!token) return res.status(400).json({ ok:false, error: 'Missing captcha token' });

    const secret = process.env.GOOGLE_RECAPTCHA_SECRET;
    if (!secret) return res.status(500).json({ ok:false, error: 'Captcha secret not configured' });

    const params = new URLSearchParams({ secret, response: token });
    const r = await fetch('https://www.google.com/recaptcha/api/siteverify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params
    });
    const data = await r.json();
    if (!data.success) return res.status(400).json({ ok:false, error: 'Captcha failed', details: data['error-codes'] || [] });

    next();
  } catch (e) {
    return res.status(500).json({ ok:false, error: 'Captcha validation error' });
  }
}
