import crypto from "crypto";
const COOKIE = "csrf_token";
function needCheck(method){ return ["POST","PUT","PATCH","DELETE"].includes(method); }
export default function csrf(req,res,next){
  if (process.env.DISABLE_CSRF === "1") return next();
  let token = req.cookies?.[COOKIE];
  if (!token){
    token = crypto.randomBytes(24).toString("hex");
    res.cookie(COOKIE, token, { httpOnly: false, sameSite: "Strict", secure: process.env.NODE_ENV==="production" });
  }
  if (!needCheck(req.method)) return next();
  const hdr = req.headers["x-csrf-token"];
  if (hdr && hdr === token) return next();
  return res.status(403).json({ error: "CSRF token invalid" });
}
