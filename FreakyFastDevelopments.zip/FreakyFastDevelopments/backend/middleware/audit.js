// backend/middleware/audit.js
import AdminAudit from '../models/AdminAudit.js';
export function adminAudit(req, res, next){
  res.on('finish', () => {
    try{
      if (!req.originalUrl.startsWith('/api/admin')) return;
      AdminAudit.create({
        path: req.originalUrl,
        method: req.method,
        actor: (req.user && (req.user.email || req.user._id)) || '',
        ip: req.ip,
        payload: req.body
      }).catch(()=>{});
    }catch{}
  });
  next();
}
