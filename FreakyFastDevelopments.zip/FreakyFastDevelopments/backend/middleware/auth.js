const jwt = require('jsonwebtoken');
module.exports = async function auth(req,res,next){
  try{
    if(process.env.ADMIN_DEV_BYPASS==='1'){
      req.user = { id:'dev', email:'dev@local', roles:['admin'] };
      return next();
    }
    const h = req.headers.authorization||req.headers.Authorization||'';
    const token = (h.startsWith('Bearer ') ? h.slice(7) : null);
    if(!token) return res.status(401).json({ ok:false, error:'unauthorized' });
    req.user = jwt.verify(token, process.env.JWT_SECRET||'devsecret');
    return next();
  }catch(e){ return res.status(401).json({ ok:false, error:'unauthorized' }) }
}
