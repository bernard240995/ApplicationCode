import { RateLimiterRedis, RateLimiterMemory } from "rate-limiter-flexible";
import { createClient } from "redis";

let limiter;
export async function createRateLimiter(){
  try{
    const client = createClient({ url: process.env.REDIS_URL || "redis://127.0.0.1:6379" });
    await client.connect();
    limiter = new RateLimiterRedis({
      storeClient: client,
      points: Number(process.env.RATE_LIMIT_POINTS || 300),
      duration: Number(process.env.RATE_LIMIT_DURATION || 60)
    });
  }catch(e){
    limiter = new RateLimiterMemory({
      points: Number(process.env.RATE_LIMIT_POINTS || 300),
      duration: Number(process.env.RATE_LIMIT_DURATION || 60)
    });
  }
}

export function rateLimit(){
  return async (req, res, next) => {
    try{
      if (!limiter) await createRateLimiter();
      const key = req.ip || "global";
      await limiter.consume(key, 1);
      next();
    }catch(e){
      const retry = e?.msBeforeNext ? Math.ceil(e.msBeforeNext/1000) : 60;
      res.set("Retry-After", String(retry));
      res.status(429).json({ error: "Too Many Requests", retryAfter: retry });
    }
  };
}
