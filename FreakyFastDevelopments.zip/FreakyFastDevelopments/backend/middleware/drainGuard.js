import { isDrained } from "../services/drainState.js";

const WRITE_METHODS = new Set(["POST","PUT","PATCH","DELETE"]);
export default function drainGuard(req,res,next){
  if (isDrained() && WRITE_METHODS.has(req.method)){
    return res.status(503).json({ error: "Service is draining. Try again shortly." });
  }
  next();
}
