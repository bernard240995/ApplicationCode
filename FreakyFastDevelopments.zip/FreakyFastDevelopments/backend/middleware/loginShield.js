const rateLimit = require('express-rate-limit');
const loginShield = rateLimit({ windowMs: 5*60*1000, limit: 20, standardHeaders: true, legacyHeaders: false });
module.exports = loginShield;
