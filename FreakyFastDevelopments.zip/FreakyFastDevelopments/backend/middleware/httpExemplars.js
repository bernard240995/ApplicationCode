import client from "prom-client";

const NAME = "http_request_duration_seconds";
let hist = null;
function ensureHistogram(){
  if (hist) return hist;
  try{
    hist = client.register.getSingleMetric(NAME);
  }catch{}
  if (!hist){
    hist = new client.Histogram({
      name: NAME,
      help: "HTTP request duration seconds",
      labelNames: ["method","route","status"],
      buckets: [0.05,0.1,0.2,0.3,0.5,0.8,1,1.5,2,3,5,8]
    });
  }
  return hist;
}

export default function httpExemplars(req,res,next){
  if (process.env.TRACE_EXEMPLARS !== "1") return next();
  const start = process.hrtime.bigint();
  const end = res.end;
  res.end = function(...args){
    try{
      const dur = Number((process.hrtime.bigint() - start)) / 1e9;
      const route = req.route?.path || req.originalUrl?.split("?")[0] || "unknown";
      const labels = { method: req.method, route, status: String(res.statusCode) };
      const h = ensureHistogram();
      const traceparent = req.headers["traceparent"];
      const traceId = typeof traceparent === "string" ? traceparent.split("-")[1] : req.id;
      // Exemplar support if available (prom-client >=14)
      try{
        if (h.observe.length >= 3){
          h.observe(labels, dur, { trace_id: traceId });
        } else {
          h.observe(labels, dur);
        }
      }catch{ h.observe(labels, dur); }
    }catch{}
    return end.apply(this, args);
  };
  next();
}
