// backend/middleware/testingMode.js
export function testingModeGate(req, res, next) {
  try {
    const enabled = (process.env.TESTING_MODE || 'false').toLowerCase() === 'true';
    if (!enabled) return next();

    const passFromHeader = req.headers['x-test-passcode'];
    const passFromCookie = req.cookies?.__ff_testing_pass;
    const provided = passFromHeader || passFromCookie || req.query.__pass;
    const expected = process.env.TESTING_MODE_PASSCODE;

    if (expected && provided === expected) {
      if (!passFromCookie && res.cookie) {
        res.cookie('__ff_testing_pass', provided, {
          httpOnly: true,
          secure: false,
          sameSite: 'Lax',
          maxAge: 12 * 60 * 60 * 1000
        });
      }
      return next();
    }
    return res.status(401).json({
      ok: false,
      testing: true,
      error: 'Site is in testing mode. Enter correct password or contact admin.'
    });
  } catch (e) {
    return res.status(500).json({ ok:false, error: 'Testing gate error' });
  }
}
