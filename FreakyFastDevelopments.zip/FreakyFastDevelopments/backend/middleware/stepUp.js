import client from "prom-client";
import { notifySlack } from "../services/alerting.js";
import LoginAttempt from "../models/LoginAttempt.js";
import axios from "axios";

const WINDOW_MIN = Number(process.env.LOGIN_WINDOW_MIN || 15);
const THRESHOLD = Number(process.env.LOGIN_STEPUP_THRESHOLD || 5);

const LOGIN_FAILS = new client.Counter({ name:"login_failures_total", help:"Total login failures" });

export async function recordLoginFailure(req, email){
  const filter = { email: (email||"").toLowerCase(), ip: (req.ip||"").toString() };
  const now = new Date();
  const since = new Date(now.getTime() - WINDOW_MIN*60*1000);
  let doc = await LoginAttempt.findOne(filter);
  if (!doc) doc = new LoginAttempt(filter);
  doc.count = (doc.count||0) + 1;
  LOGIN_FAILS.inc();
if (doc.count % THRESHOLD === 0) {
  notifySlack(`Login failures threshold reached for ${filter.email} from ${filter.ip} (count=${doc.count})`, "login-threshold");
}
  doc.lastAt = now;
  await doc.save();
  // also cleanup old attempts (keep simple)
  await LoginAttempt.deleteMany({ lastAt: { $lt: since } });
  return doc.count;
}

export async function clearLoginAttempts(req, email){
  await LoginAttempt.deleteOne({ email: (email||"").toLowerCase(), ip: (req.ip||"").toString() });
}

export async function requireStepUpIfNeeded(req, res, next){
  try{
    const email = String(req.body?.email || "").toLowerCase();
    const ip = (req.ip||"").toString();
    const now = new Date();
    const since = new Date(now.getTime() - WINDOW_MIN*60*1000);
    const doc = await LoginAttempt.findOne({ email, ip, lastAt: { $gte: since } });
    const need = (doc?.count||0) >= THRESHOLD;
    if (!need) return next();

    const token = req.headers["x-recaptcha-token"] || req.body?.recaptchaToken;
    if (!token) return res.status(403).json({ error: "Step-up required: missing reCAPTCHA token" });
    const secret = process.env.RECAPTCHA_SECRET_KEY;
    if (!secret) return res.status(500).json({ error: "reCAPTCHA not configured" });
    const params = new URLSearchParams({ secret, response: token, remoteip: ip });
    const r = await axios.post("https://www.google.com/recaptcha/api/siteverify", params);
    if (!r.data?.success) return res.status(403).json({ error: "reCAPTCHA failed" });
    next();
  }catch(e){
    return res.status(403).json({ error: "Step-up validation error" });
  }
}


export function computeBackoffMs(fails){
  const base = Number(process.env.LOGIN_BACKOFF_BASE_MS || 500);
  const cap  = Number(process.env.LOGIN_BACKOFF_CAP_MS || 30000);
  const ms = Math.min(cap, base * Math.pow(2, Math.max(0, fails-1)));
  return ms;
}
