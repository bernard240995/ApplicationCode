import geoip from "geoip-lite";

/**
 * UK-only access gate. Allows admin/status/local, blocks non-UK with 451.
 * Use behind a trusted proxy for correct IPs.
 */
export default function ukOnly(req, res, next) {
  const path = req.originalUrl || "";
  // Always allow admin APIs and status endpoints
  if (path.startsWith("/api/admin") || path.startsWith("/status")) return next();

  // Determine client IP
  const xf = (req.headers["x-forwarded-for"] || "").split(",")[0].trim();
  const ip = xf || req.socket?.remoteAddress || "";
  const isLocal = ip.startsWith("127.") || ip.includes("::1") || ip === "";

  if (isLocal) return next();

  const geo = geoip.lookup(ip);
  const cc = (geo && geo.country) ? geo.country : "GB"; // default allow if lookup fails
  if (cc === "GB") return next();

  return res.status(451).json({
    error: "Not available in your region",
    country: cc,
    message: "This website is currently accessible only in the United Kingdom."
  });
}
