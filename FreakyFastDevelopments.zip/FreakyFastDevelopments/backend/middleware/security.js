// backend/middleware/security.js
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import hpp from 'hpp';
import xss from 'xss-clean';
import mongoSanitize from 'express-mongo-sanitize';

export function buildCorsOptions(allowedOrigins = []) {
  const whitelist = new Set([
    'http://localhost:3000',
    'http://127.0.0.1:3000',
    ...allowedOrigins.filter(Boolean),
  ]);
  return {
    origin(origin, cb) {
      if (!origin || whitelist.has(origin)) return cb(null, true);
      return cb(new Error('Not allowed by CORS'), false);
    },
    credentials: true,
    allowedHeaders: ['Content-Type', 'Authorization'],
    methods: ['GET','POST','PUT','PATCH','DELETE','OPTIONS']
  };
}

export function applySecurity(app, {allowedOrigins = [], enableCSP = true} = {}) {
  app.disable('x-powered-by');

  app.use(helmet({
    contentSecurityPolicy: enableCSP ? {
      // For stricter rollout you can disable reportOnly after verifying reports\n      reportOnly: (process.env.CSP_REPORT_ONLY||'false').toLowerCase()==='true',
      useDefaults: true,
      directives: {
        "default-src": ["'self'"],
        "img-src": ["'self'", "data:", "blob:", ...(process.env.ADD_IMG_SRC?process.env.ADD_IMG_SRC.split(','):[])],
        "script-src": ["'self'", "'unsafe-inline'", "'unsafe-eval'", ...(process.env.ADD_SCRIPT_SRC?process.env.ADD_SCRIPT_SRC.split(','):[])],
        "style-src": ["'self'", "'unsafe-inline'"],
        "connect-src": ["'self'", "https:", "http://localhost:3000", ...(process.env.ADD_CONNECT_SRC?process.env.ADD_CONNECT_SRC.split(','):[])],
        "frame-ancestors": ["'none'"]
      }
    } : false,
    crossOriginEmbedderPolicy: false
  }));

  app.use(cors(buildCorsOptions(allowedOrigins)));
  app.use(hpp());
  app.use(mongoSanitize());
  app.use(xss());

  const limiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 100,
    standardHeaders: true,
    legacyHeaders: false,
    message: { ok:false, error: 'Too many requests, please try again later.' }
  });
  app.use('/api/', limiter);
}
