// backend/middleware/limits.js
import rateLimit from 'express-rate-limit';

export const webhookLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 60, // 60/min per IP (Stripe forwards via single IP usually; tune as needed)
  standardHeaders: true,
  legacyHeaders: false,
});

export const ordersApiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
});
