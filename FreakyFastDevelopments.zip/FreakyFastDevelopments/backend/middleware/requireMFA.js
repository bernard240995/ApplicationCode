import User from "../models/User.js";

const NEED = new Set(["POST","PUT","PATCH","DELETE"]);

export default async function requireMFA(req,res,next){
  // Only enforce under /api/admin/* by mounting location; bypass when disabled
  if (process.env.REQUIRE_MFA_ADMIN !== "1") return next();
  if (!NEED.has(req.method)) return next();
  const email = req.user?.email;
  if (!email) return res.status(401).json({ error: "Unauthorized" });
  const u = await User.findOne({ email });
  if (!u?.mfa?.enabled) return res.status(403).json({ error: "MFA required" });
  const otp = String(req.headers["x-mfa-otp"]||req.body?.mfa||"");
  if (!otp) return res.status(403).json({ error: "Missing MFA code" });
  const { authenticator } = await import("otplib");
  if (!authenticator.check(otp, u.mfa.secret)) return res.status(403).json({ error: "Invalid MFA code" });
  next();
}
