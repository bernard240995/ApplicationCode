import fs from "fs";
import path from "path";
import { notifySlack } from "../services/alerting.js";

const __dirname = path.resolve();
const budgetsPath = process.env.BUDGETS_FILE || path.join(__dirname, "config", "budgets.json");
const windowMs = Number(process.env.BUDGETS_WINDOW_MS || 5*60*1000);
const sampleCap = Number(process.env.BUDGETS_SAMPLE_CAP || 500);

const samples = new Map(); // route -> [ms,...]
let budgets = {};

function loadBudgets(){
  try{ budgets = JSON.parse(fs.readFileSync(budgetsPath,"utf-8")); }catch{ budgets = {}; }
}
loadBudgets();
fs.watchFile(budgetsPath, { interval: 30000 }, loadBudgets);

function pushSample(route, ms){
  const key = route || "unknown";
  if (!samples.has(key)) samples.set(key, []);
  const arr = samples.get(key);
  arr.push(ms);
  if (arr.length > sampleCap) arr.shift();
}

function p95(arr){
  if (!arr?.length) return 0;
  const sorted = [...arr].sort((a,b)=>a-b);
  const idx = Math.ceil(0.95 * sorted.length) - 1;
  return sorted[Math.max(0, idx)];
}

setInterval(()=>{
  try{
    for (const [route, arr] of samples.entries()){
      const budget = budgets[route];
      if (!budget) continue;
      const val = p95(arr);
      if (val > budget){
        notifySlack(`Perf budget breach: p95 ${route} = ${Math.round(val)}ms (budget ${budget}ms)`, `budget-${route}`, 15*60*1000);
      }
    }
  }catch{}
  // sliding window approximation: trim old samples
  for (const [route, arr] of samples.entries()){
    if (arr.length > sampleCap/2) samples.set(route, arr.slice(-Math.floor(sampleCap/2)));
  }
}, Math.min(windowMs, 60*1000));

export default function httpBudgets(req, res, next){
  const start = Date.now();
  const end = res.end;
  res.end = function(...args){
    try{
      const route = req.route?.path || req.originalUrl?.split("?")[0] || "unknown";
      const ms = Date.now() - start;
      pushSample(route, ms);
    }catch{}
    return end.apply(this, args);
  };
  next();
}
