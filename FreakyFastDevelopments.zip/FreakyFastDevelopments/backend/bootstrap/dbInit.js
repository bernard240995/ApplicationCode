import mongoose from "mongoose";

async function safeImport(path){
  try { return (await import(path)).default; } catch { return null; }
}

async function ensureIndexes(Model, indexes=[]){
  try { await Model.syncIndexes?.(); } catch {}
  for (const [fields, opts] of indexes){
    try { await Model.collection.createIndex(fields, opts || {}); } catch {}
  }
}

export default async function dbInit(){
  const models = {};
  models.Product = await safeImport("../models/Product.js");
  models.Order = await safeImport("../models/Order.js");
  models.EmailEvent = await safeImport("../models/EmailEvent.js");
  models.WebhookEvent = await safeImport("../models/WebhookEvent.js");
  models.OutboxEvent = await safeImport("../models/OutboxEvent.js");
  models.IdempotencyKey = await safeImport("../models/IdempotencyKey.js");
  models.SessionReplay = await safeImport("../models/SessionReplay.js");
  models.AuditLog = await safeImport("../models/AuditLog.js");
  models.User = await safeImport("../models/User.js");
  models.SiteConfig = await safeImport("../models/SiteConfig.js");

  for (const [name, M] of Object.entries(models)){
    if (!M) continue;
    await ensureIndexes(M);
  }

  // Seed admin user (optional)
  if (models.User && process.env.SEED_ADMIN_EMAIL && process.env.SEED_ADMIN_PASSWORD){
    const email = process.env.SEED_ADMIN_EMAIL;
    let u = await models.User.findOne({ email });
    if (!u){
      let hash = process.env.SEED_ADMIN_PASSWORD;
      try {
        const bcrypt = (await import("bcryptjs")).default;
        hash = await bcrypt.hash(process.env.SEED_ADMIN_PASSWORD, 10);
      } catch {}
      u = await models.User.create({ email, role: "superadmin", passwordHash: hash, mfa: { enabled: false } });
      console.log("[dbInit] seeded admin", email);
    }
  }

  // Seed footer/site config
  if (models.SiteConfig){
    const existing = await models.SiteConfig.findOne({ key: "footer" });
    if (!existing){
      await models.SiteConfig.create({
        key: "footer",
        value: {
          columns: [
            { title: "About FreakyFast", links: [
              { label: "Our mission", href: "#" },
              { label: "Security & Trust", href: "#" },
              { label: "Sustainability", href: "#" }
            ]},
            { title: "Resources", links: [
              { label: "Docs & Guides", href: "#" },
              { label: "API Status", href: "/status/health" },
              { label: "Developer Changelog", href: "#" }
            ]},
            { title: "Company", links: [
              { label: "Careers", href: "#" },
              { label: "Press", href: "#" },
              { label: "Contact", href: "/contact" }
            ]}
          ],
          disclaimer: "© " + new Date().getFullYear() + " FreakyFast. All rights reserved. Example content — replace via Admin > Site Settings."
        }
      });
      console.log("[dbInit] seeded footer config");
    }
  }
}
