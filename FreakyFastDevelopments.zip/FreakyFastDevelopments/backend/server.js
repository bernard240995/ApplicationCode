import morgan from 'morgan';
import publicOrderStatus from './routes/publicOrderStatus.js';
import adminFulfillment from './routes/adminFulfillment.js';
import stripeWebhook from './routes/stripeWebhook.js';
import publicRewardsBalance from './routes/publicRewardsBalance.js';
import stripeCheckout from './routes/stripeCheckout.js';
import checkoutPricing from './routes/checkoutPricing.js';
import publicReviewsPost from './routes/publicReviewsPost.js';
import publicReviews from './routes/publicReviews.js';
import publicBanners from './routes/publicBanners.js';
import adminBanners from './routes/adminBanners.js';
import adminRewards from './routes/adminRewards.js';
import adminReviews from './routes/adminReviews.js';
import adminPromos from './routes/adminPromos.js';
import supportRoutes from './routes/support.js';
import { ensureDemoProducts } from './utils/seedProducts.js';
import productsPublic from './routes/productsPublic.js';
import adminProducts from './routes/adminProducts.js';
import { ensureCorePages } from './utils/seedPages.js';
import adminAuditRoute from './routes/adminAudit.js';
import { adminAudit } from './middleware/audit.js';
import adminOrders from './routes/adminOrders.js';
import { mountStripeWebhook } from './routes/stripeWebhook.js';
import paymentsStripe from './routes/paymentsStripe.js';
import printables from './routes/printables.js';
import sitemap from './routes/sitemap.js';
import experimentsPublic from './routes/experimentsPublic.js';
import adminExperiments from './routes/adminExperiments.js';
import adminStats from './routes/adminStats.js';
import ab from './routes/ab.js';
import { initSentry } from './utils/sentry.js';
import pagesPublic from './routes/pagesPublic.js';
import aiSupport from './routes/aiSupport.js';
import adminPages from './routes/adminPages.js';
import supportTickets from './routes/supportTickets.js';
import { testingModeGate } from './middleware/testingMode.js';
import { applySecurity } from './middleware/security.js';
import cookieParser from 'cookie-parser';
import shippoRoute from "./routes/shippo.js";
import path from "path";
// backend/server.js
const path = require('path');
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const compression = require('compression');

let helmet, Sentry, rateLimit;
try { helmet = require('helmet'); } catch {}
try { Sentry = require('@sentry/node'); } catch {}
try { rateLimit = require('express-rate-limit'); } catch {}

const dotenv = require('dotenv');
dotenv.config({ path: process.env.DOTENV_PATH || path.join(__dirname, 'env/.env.dev') });
const PORT = Number(process.env.PORT || 5000);
const FRONTEND = process.env.FRONTEND_ORIGIN || process.env.CORS_ORIGIN || 'http://localhost:3000';
const MONGO_URL = process.env.MONGO_URL || 'mongodb://localhost:27017/freakyfast';

\1
\1
\1
\1
\1
\1
\1
app.use('/api/pages', pagesPublic);
app.use('/api/experiments', experimentsPublic);
app.use('/api/ab', ab);
app.use('/api/admin/stats', adminStats);
app.use('/api/sitemap', sitemap);
app.use('/api/admin/experiments', adminExperiments);
import statusInfoRoute from "./routes/status/info.js";
app.use("/", statusInfoRoute);
import productsPublicRoute from "./routes/products.js";
app.use("/api/products", productsPublicRoute);
import siteConfigRoute from "./routes/site/config.js";
app.use("/api/site", siteConfigRoute);
import adminProductsCrudRoute from "./routes/admin/productsCrud.js";
app.use("/api/admin/products", adminProductsCrudRoute);
import adminAuditRoute from "./routes/admin/audit.js";
app.use("/api/admin/audit", adminAuditRoute);
import adminUsersRoute from "./routes/admin/users.js";
app.use("/api/admin/users", adminUsersRoute);
import tickOutbox from "./workers/outboxWorker.js";
setInterval(()=>{ tickOutbox().catch(()=>{}); }, 5000);
import checkoutTestRoute from "./routes/checkout/test.js";
app.use("/api/checkout/test", checkoutTestRoute);
import adminProductImagesRoute from "./routes/admin/productImages.js";
app.use("/api/admin/products/images", adminProductImagesRoute);
import replayRoute from "./routes/observe/replay.js";
app.use("/api/observe/replay", replayRoute);
import logRedactSample from "./middleware/logRedactSample.js";
app.use(logRedactSample);
import adminProductsImportRoute from "./routes/admin/productsImport.js";
app.use("/api/admin/products/import", adminProductsImportRoute);
import authMfaRoute from "./routes/auth/mfa.js";
app.use("/api/auth/mfa", authMfaRoute);
import seoSitemapRoute from "./routes/seo/sitemap.js";
app.use("/", seoSitemapRoute);
import searchRoute from "./routes/search.js";
app.use("/api/search", searchRoute);
import adminAnalyticsRoute from "./routes/admin/analytics.js";
import requireMFA from "./middleware/requireMFA.js";
app.use("/api/admin", requireMFA);
app.use("/api/admin/analytics", adminAnalyticsRoute);
import security from "./middleware/security.js";
import corsAllowlist from "./middleware/corsAllowlist.js";
import csrf from "./middleware/csrf.js";
import rateLimitSimple from "./middleware/rateLimitSimple.js";
app.use(corsAllowlist);
security(app);
app.use(rateLimitSimple({ windowMs: 60000, limit: 120 }));
app.use(csrf);
import adminEmailEventsRoute from "./routes/admin/emailEvents.js";
app.use("/api/admin/emails", adminEmailEventsRoute);
import accountEmailsRoute from "./routes/account/emails.js";
app.use("/api/account/emails", accountEmailsRoute);
import httpExemplars from "./middleware/httpExemplars.js";
app.use(httpExemplars);
import accountOrdersRoute from "./routes/account/orders.js";
app.use("/api/account/orders", accountOrdersRoute);
import adminEmailTemplatesRoute from "./routes/admin/emailTemplates.js";
app.use("/api/admin/email/templates", adminEmailTemplatesRoute);
import adminOrdersRoute from "./routes/admin/orders.js";
app.use("/api/admin/orders", adminOrdersRoute);
import emailPreviewRoute from "./routes/admin/emailPreview.js";
app.use("/api/admin/email/preview", emailPreviewRoute);
import stripeCheckoutRoute from "./routes/payments/stripeCheckout.js";
app.use("/api/payments/stripe", stripeCheckoutRoute);
import { startTracing } from "./services/tracing.js";
await (async()=>{ try{ await startTracing(); }catch{} })();
import privacyRoute from "./routes/privacy.js";
app.use("/api/privacy", privacyRoute);
import imageProxy from "./routes/imageProxy.js";
app.use("/img", imageProxy);
import stripeWebhook from "./routes/webhooks/stripe.js";
app.use("/webhooks/stripe", stripeWebhook);
import dbStatusRoute from "./routes/dbStatus.js";
app.use("/status/db", dbStatusRoute);
import { runDbBootstrap } from "./bootstrap/dbInit.js";
await (async()=>{ try{ await runDbBootstrap(); }catch(e){ console.warn("[BOOTSTRAP]", e?.message); } })();
import selftestRoute from "./routes/selftest.js";
app.use("/status/selftest", selftestRoute);
import { rateLimit } from "./middleware/rateLimit.js";
app.use(rateLimit());
import drainRoute from "./routes/drain.js";
app.use("/status/drain", drainRoute);
import drainGuard from "./middleware/drainGuard.js";
app.use(drainGuard);
import slowRoute from "./routes/slow.js";
app.use("/api/admin/slow", slowRoute);
import { startMongoSlowLog } from "./services/mongoSlowLog.js";
startMongoSlowLog();
import httpBudgets from "./middleware/httpBudgets.js";
app.use(httpBudgets);
import correlationId from "./middleware/correlationId.js";
app.use(correlationId);
import sitemapRoute from "./routes/sitemap.js";
app.use("/sitemap.xml", sitemapRoute);
import flagsRoute from "./routes/flags.js";
app.use("/api/flags", flagsRoute);
import { mountSession } from "./services/sessionStore.js";
await (async()=>{ try{ await mountSession(app); }catch(_){} })();
import statusRoute from "./routes/status.js";
app.use("/", statusRoute);
import { startMemoryWatch } from "./services/memoryWatch.js";
startMemoryWatch();
import httpMetrics from "./middleware/httpMetrics.js";
app.use(httpMetrics);
import cartRoute from "./routes/cart.js";
app.use("/api/cart", cartRoute);
import errorSpikeWatch from "./middleware/errorSpikeWatch.js";
app.use(errorSpikeWatch);
import { startAuditArchiver } from "./services/auditArchiver.js";
startAuditArchiver();
import { setupCsrf } from "./middleware/csrf.js";
setupCsrf(app);
import newsletterWebhook from "./routes/newsletterWebhook.js";
app.use("/api/newsletter/webhook", newsletterWebhook);
import cmsDbRoute from "./routes/cmsDb.js";
app.use("/api/cms", cmsDbRoute);
import cmsRoute from "./routes/cms.js";
app.use("/api/cms", cmsRoute);
import newsletterProvider from "./routes/newsletterProvider.js";
app.use("/api/newsletter", newsletterProvider);
import shippingRatesRoute from "./routes/shippingRates.js";
app.use("/api/shipping", shippingRatesRoute);
import couponsRoute from "./routes/coupons.js";
app.use("/api/coupons", couponsRoute);
import ordersPublic from "./routes/ordersPublic.js";
app.use("/api/orders", ordersPublic);
import ukOnly from "./middleware/ukOnly.js";
app.use(ukOnly);
Sentry.init({ dsn: process.env.SENTRY_DSN, tracesSampleRate: 0.2 });
app.use(Sentry.Handlers.requestHandler());
app.set('trust proxy', 1);

if (Sentry && process.env.SENTRY_DSN) {
  Sentry.init({ dsn: process.env.SENTRY_DSN, tracesSampleRate: parseFloat(process.env.SENTRY_TRACES || '0.1') });
  app.use(Sentry.Handlers.requestHandler());
}

if (helmet) {
  app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
  app.use(helmet.hsts({ maxAge: 31536000, includeSubDomains: true, preload: true }));
}

app.use(cors({ origin: FRONTEND, credentials: true }));

// Stripe webhook raw body (must come before JSON parser)
app.use('/api/webhooks/stripe', express.raw({ type: 'application/json' }), (req, _res, next) => { req._raw = req.body; next(); });

mountStripeWebhook(app);
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(compression());
const geoip = require('geoip-lite');
app.get('/api/geo', (req, res) => {
  try {
    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
    const geo = geoip.lookup(ip);
    res.json({ ip, country: (geo && geo.country) ? geo.country : null });
  } catch (e) { res.json({ ip: null, country: null }); }
});


const uploadsDir = path.join(__dirname, 'uploads');
app.use('/uploads', express.static(uploadsDir));
console.log('📁 Serving /uploads');

mongoose.set('strictQuery', true);
mongoose
  .connect(MONGO_URL)
  .then(() => console.log('🗄️  Mongo connected'))
  .catch((e) => { console.error('Mongo connection error:', e.message); process.exit(1); });

if (rateLimit) {
  const gen = rateLimit({ windowMs: 15 * 60 * 1000, limit: 200 });
  const strict = rateLimit({ windowMs: 15 * 60 * 1000, limit: 60 });
  app.use('/api/public', gen);
  app.use(['/api/public/payments', '/api/public/returns'], strict);
}

function mount(base, rel) {
  try { app.use(base, require(rel)); console.log(`✅ Mounted ${base} -> ${rel}`); }
  catch (e) { console.warn(`⚠️  Could not mount ${rel}: ${e.message}`); }
}

// Core/public
mount('/api', './routes/products');
mount('/api', './routes/public_extras');
mount('/api', './routes/status');
mount('/api', './routes/mediaPublic');

// Admin/imports
mount('/api', './routes/adminProductsImport');

// Search
mount('/api', './routes/search');
mount('/api', './routes/searchPreview');

// Returns
mount('/api', './routes/returnsFlow');

// Payments
mount('/api', './routes/paymentsStripe');

// Invoices
mount('/api', './routes/invoices');
mount('/api', './routes/invoiceSigned');

// RUM + Feeds/Sitemaps
mount('/api', './routes/rum');
mount('/api', './routes/feeds');

// Health, Audit, QA
mount('/api', './routes/health');
mount('/api', './routes/audit');
mount('/api', './routes/qa');

// Shipping webhooks (optional)
mount('/api', './routes/shippingWebhooks');

if (Sentry && process.env.SENTRY_DSN) {
  app.use(Sentry.Handlers.errorHandler());
}

app.use((err, _req, res, _next) => {
  console.error('Unhandled error:', err && err.stack ? err.stack : err);
  res.status(500).json({ ok: false, error: 'internal_error' });
});

app.listen(PORT, () => { console.log(`🚀 API listening on http://localhost:${PORT}`); });

try{ app.use('/api', require('./routes/auth')); console.log('✅ Mounted /api -> ./routes/auth'); }catch(e){ console.warn('⚠️ mount ./routes/auth', e.message) }
try{ app.use('/api', require('./routes/mediaUpload')); console.log('✅ Mounted /api -> ./routes/mediaUpload'); }catch(e){ console.warn('⚠️ mount ./routes/mediaUpload', e.message) }
try{ app.use('/api', require('./routes/adminSettings')); console.log('✅ Mounted /api -> ./routes/adminSettings'); }catch(e){ console.warn('⚠️ mount ./routes/adminSettings', e.message) }
try{ app.use('/api', require('./routes/shippingTimes')); console.log('✅ Mounted /api -> ./routes/shippingTimes'); }catch(e){ console.warn('⚠️ mount ./routes/shippingTimes', e.message) }
try{ app.use('/api', require('./routes/optimizer')); console.log('✅ Mounted /api -> ./routes/optimizer'); }catch(e){ console.warn('⚠️ mount optimizer', e.message) }
import adminStatsRoute from "./routes/adminStats.js";
app.use("/api/admin/stats", adminStatsRoute);

import adminAuditRoute from "./routes/adminAudit.js";
app.use("/api/admin/audit", adminAuditRoute);

app.use("/uploads", express.static(path.join(process.cwd(), "uploads")));

import adminUploadsRoute from "./routes/adminUploads.js";
app.use("/api/admin/uploads", adminUploadsRoute);

import adminCouponsRoute from "./routes/adminCoupons.js";
app.use("/api/admin/coupons", adminCouponsRoute);

import shippingCarrierRM from "./routes/shippingCarrierRoyalMail.js";
app.use("/api/carriers/royalmail", shippingCarrierRM);

app.use("/api/carriers/shippo", shippoRoute);

import newsletterRoute from "./routes/newsletter.js";
app.use("/api/newsletter", newsletterRoute);

// FOOTER_SCHEDULER
import FooterContent from "./models/FooterContent.js";
setInterval(async () => {
  try {
    const now = new Date();
    const due = await FooterContent.find({ status: "scheduled", publishAt: { $lte: now } }).sort({ publishAt: 1 });
    for (const doc of due) {
      await FooterContent.updateMany({}, { $set: { published: false, status: "draft" } });
      doc.published = true;
      doc.status = "published";
      await doc.save();
    }
  } catch (e) {
    // swallow
  }
}, 60 * 1000);

export default app;

app.use('/api/print', printables);

app.use('/api/payments/stripe', paymentsStripe);

app.use('/api/admin/orders', adminOrders);

app.use('/api/admin/audit', adminAuditRoute);

try{ ensureCorePages(); }catch{}

app.use('/api/admin/products', adminProducts);

app.use('/api/products', productsPublic);

try{ ensureDemoProducts(); }catch{}

app.use('/api/support', supportRoutes);

app.use('/api/admin/promos', adminPromos);
app.use('/api/admin/reviews', adminReviews);
app.use('/api/admin/rewards', adminRewards);
app.use('/api/admin/banners', adminBanners);
app.use('/api/banners', publicBanners);
app.use('/api/reviews', publicReviews);
app.use('/api/checkout', checkoutPricing);
app.use('/api/stripe', stripeCheckout);
app.use('/api/rewards', publicRewardsBalance);
// Stripe Webhook must use raw body parser
import express from 'express';
app.use('/api/stripe/webhook', express.raw({ type: 'application/json' }));
app.use('/api/stripe/webhook', stripeWebhook);

app.use('/api/admin/fulfillment', adminFulfillment);
app.use('/api/order', publicOrderStatus);
app.use(morgan(process.env.NODE_ENV==='production'?'combined':'dev'));
app.get('/health', (_req,res)=>res.json({ ok:true, service:'backend', time:new Date().toISOString() }));

// 404
app.use((req,res,next)=>{ if (res.headersSent) return next(); res.status(404).json({ ok:false, error:'not_found' }); });
// Error handler
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next)=>{
  console.error('Unhandled', err);
  if (res.headersSent) return;
  res.status(500).json({ ok:false, error:'server_error' });
});
