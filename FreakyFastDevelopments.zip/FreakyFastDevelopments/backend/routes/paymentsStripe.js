// backend/routes/paymentsStripe.js
import express from 'express';

const router = express.Router();

router.post('/create-session', async (req,res) => {
  try{
    const sk = process.env.STRIPE_SECRET_KEY;
    const pk = process.env.NEXT_PUBLIC_STRIPE_PK; // used by client
    if (!sk || !pk) return res.status(400).json({ ok:false, error:'Stripe not configured' });
    const stripe = (await import('stripe')).default(sk);
    const { items = [{name:'Basket', amount: 2000, currency:'gbp', quantity:1}], success_url, cancel_url } = req.body || {};
    const line_items = items.map(i => ({
      price_data: { currency: i.currency || 'gbp', product_data: { name: i.name || 'Item' }, unit_amount: Number(i.amount) },
      quantity: Number(i.quantity || 1)
    }));
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      payment_method_types: ['card', 'paypal'], // Stripe handles PayPal via Payment Element where enabled
      line_items,
      success_url: success_url || (process.env.FRONTEND_URL || '') + '/checkout/success?session_id={CHECKOUT_SESSION_ID}',
      cancel_url: cancel_url || (process.env.FRONTEND_URL || '') + '/checkout/cancelled',
    });
    res.json({ ok:true, id: session.id, publicKey: pk });
  }catch(e){
    res.status(500).json({ ok:false, error:'Stripe session error' });
  }
});

export default router;
