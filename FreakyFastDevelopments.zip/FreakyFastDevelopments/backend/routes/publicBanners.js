// backend/routes/publicBanners.js
import express from 'express';
import Banner from '../models/Banner.js';
const router = express.Router();
router.get('/', async (req,res)=>{
  const items = await Banner.find({active:true}).sort({order:1,createdAt:-1}).lean();
  res.json({ ok:true, items });
});
export default router;
