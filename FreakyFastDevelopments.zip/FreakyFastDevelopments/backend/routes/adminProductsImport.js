const router = require('express').Router();
const multer = require('multer');
const xlsx = require('xlsx');
const Product = require('../models/Product');
const path = require('path'); const fs = require('fs');

const upload = multer({ dest: path.join(__dirname,'..','uploads','imports') });

// Download Excel template
router.get('/admin/products/template', (req,res)=>{
  const p = path.join(__dirname,'..','templates','product_upload_template.xlsx');
  if(!fs.existsSync(p)) return res.status(404).send('template missing');
  res.setHeader('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition','attachment; filename="product_upload_template.xlsx"');
  fs.createReadStream(p).pipe(res);
});

// Import Excel
router.post('/admin/products/import', upload.single('file'), async (req,res)=>{
  try{
    const filePath = req.file.path;
    const wb = xlsx.readFile(filePath);
    const ws = wb.Sheets[wb.SheetNames[0]];
    const rows = xlsx.utils.sheet_to_json(ws, { defval:'' });
    let created=0, updated=0, skipped=0;
    for(const r of rows){
      const sku = String(r.SKU||'').trim(); if(!sku){ skipped++; continue }
      const doc = {
        sku,
        title: String(r.Title||'').trim(),
        description: String(r.Description||'').trim(),
        pricePence: Math.round(Number(r.PriceGBP||0)*100),
        stock: Number(r.StockInitial||0),
        stockMin: Number(r.StockMin||0),
        stockMax: Number(r.StockMax||0),
        brand: String(r.Brand||'').trim(),
        active: (String(r.Active).toLowerCase()!=='false'),
        images: String(r.Images||'').split(',').map(u=>({url:u.trim()})).filter(x=>x.url),
        category: String(r.Category||'').trim()
      };
      const existing = await Product.findOne({ sku });
      if(existing){ await Product.updateOne({ _id: existing._id }, { $set: doc }); updated++; }
      else { await Product.create(doc); created++; }
    }
    res.json({ ok:true, created, updated, skipped, total: rows.length });
  }catch(e){
    console.error(e); res.status(500).json({ ok:false, error:e.message })
  }finally{
    try{ fs.unlinkSync(req.file.path) }catch(e){}
  }
});

module.exports = router;
