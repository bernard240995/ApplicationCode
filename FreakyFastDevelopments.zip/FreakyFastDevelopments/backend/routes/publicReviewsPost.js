
// backend/routes/publicReviewsPost.js
import express from 'express';
import Review from '../models/Review.js';
const router = express.Router();
router.post('/', async (req,res)=>{
  const b = req.body || {};
  const item = await Review.create({
    productSlug: b.productSlug,
    customerEmail: b.customerEmail||'guest@freakyfast.co.uk',
    rating: Math.max(1, Math.min(5, Number(b.rating||5))),
    comment: String(b.comment||''),
    status: 'pending'
  });
  res.json({ ok:true, item });
});
export default router;
