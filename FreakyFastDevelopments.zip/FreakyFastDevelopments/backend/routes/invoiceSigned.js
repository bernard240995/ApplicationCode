const router=require('express').Router(); const fs=require('fs'); const path=require('path'); const crypto=require('crypto');
function valid(id, exp, sig){
  const secret=process.env.INVOICE_SIGNING_SECRET||'devsign';
  if(!exp || Number(exp)<Math.floor(Date.now()/1000)) return false;
  const expect = crypto.createHmac('sha256', secret).update(id+':'+exp).digest('hex');
  return expect===sig;
}
router.get('/public/invoice/:id', (req,res)=>{
  const { id } = req.params; const { exp, sig } = req.query;
  if(!valid(id, exp, sig)) return res.status(401).send('invalid');
  const file = path.join(__dirname,'..','uploads',`invoice_${id}.pdf`);
  if(!fs.existsSync(file)) return res.status(404).send('not found');
  res.sendFile(file);
});
module.exports=router;
