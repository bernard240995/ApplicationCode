import express from "express";
import NewsletterEvent from "../models/NewsletterEvent.js";
const router = express.Router();

router.post("/mailchimp", express.json({ type: "*/*" }), async (req, res) => {
  try {
    const ev = req.body || {};
    const email = ev?.data?.email || ev?.email || "";
    const type = ev?.type || ev?.event || "event";
    await NewsletterEvent.create({ email, provider: "mailchimp", event: type, payload: ev });
    res.status(200).json({ ok: true });
  } catch (e) {
    res.status(200).json({ ok: true });
  }
});

export default router;
