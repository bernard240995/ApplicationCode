const router = require('express').Router();
const PDFDocument = require('pdfkit'); const fs = require('fs'); const path = require('path');
const crypto = require('crypto');
const Order = require('../models/Order');

function sign(id, exp){
  const secret=process.env.INVOICE_SIGNING_SECRET||'devsign';
  const h=crypto.createHmac('sha256', secret).update(id+':'+exp).digest('hex');
  return h;
}

router.post('/admin/invoices/:orderId', async (req,res)=>{
  const id=req.params.orderId
  const invPath = path.join(__dirname, '..','uploads',`invoice_${id}.pdf`)
  try{
    const doc = new PDFDocument(); const out = fs.createWriteStream(invPath); doc.pipe(out);
    doc.fontSize(18).text('FreakyFast Invoice',{align:'left'})
    doc.moveDown().fontSize(12).text('Order ID: '+id)
    doc.text('Thank you for your purchase!')
    doc.end(); await new Promise(r=>out.on('finish',r))
    const exp = Math.floor(Date.now()/1000)+7*24*3600
    const sig = sign(id, exp)
    const link = `/api/public/invoice/${id}?exp=${exp}&sig=${sig}`
    return res.json({ ok:true, file:'/uploads/'+path.basename(invPath), signedLink:link })
  }catch(e){ return res.status(500).json({ ok:false, error:e.message }) }
})

module.exports = router;

const { send } = require('../utils/email');
router.post('/admin/invoices/:orderId/send', async (req,res)=>{ try{ const id=req.params.orderId; const link = `${req.protocol}://${req.get('host')}/api/public/invoice/${id}`; await send({ to: req.body.to||'test@local.test', subject:'Your invoice', text:`Download: ${link}` }); res.json({ ok:true }) }catch(e){ res.status(500).json({ ok:false, error:e.message }) } });
