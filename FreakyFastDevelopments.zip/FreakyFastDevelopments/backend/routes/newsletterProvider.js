import express from "express";

const DOUBLE_OPTIN = String(process.env.NEWSLETTER_DOUBLE_OPTIN || "true").toLowerCase() === "true";

import fetch from "node-fetch";

const router = express.Router();

// Provider selection via env
const PROVIDER = (process.env.NEWSLETTER_PROVIDER || "mailchimp").toLowerCase();

router.post("/subscribe", async (req, res) => {
  try {
    const { email } = req.body || {};
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({ error: "Valid email required" });
    }

    if (PROVIDER === "sendgrid") {
      const key = process.env.SENDGRID_API_KEY;
      const listId = process.env.SENDGRID_LIST_ID;
      if (!key || !listId) return res.status(500).json({ error: "Sendgrid not configured" });

      // Create/Upsert a contact and add to list
      const resp = await fetch("https://api.sendgrid.com/v3/marketing/contacts", {
        method: "PUT",
        headers: { "Authorization": `Bearer ${key}`, "Content-Type": "application/json" },
        body: JSON.stringify({ list_ids: [listId], contacts: [{ email }] })
      });
      if (!resp.ok) {
        const t = await resp.text();
        return res.status(502).json({ error: "Sendgrid error", details: t.slice(0,500) });
      }
      return res.status(202).json({ ok: true, provider: "sendgrid" });
    }

    // Default: Mailchimp
    const apiKey = process.env.MAILCHIMP_API_KEY;
    const server = process.env.MAILCHIMP_SERVER_PREFIX; // e.g. "us21"
    const audience = process.env.MAILCHIMP_AUDIENCE_ID;
    if (!apiKey || !server || !audience) return res.status(500).json({ error: "Mailchimp not configured" });

    const url = `https://${server}.api.mailchimp.com/3.0/lists/${audience}/members`;
    const resp = await fetch(url, {
      method: "POST",
      headers: {
        "Authorization": "Basic " + Buffer.from("any:" + apiKey).toString("base64"),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ email_address: email, status: (DOUBLE_OPTIN ? 'pending' : 'subscribed') })
    });
    if (!resp.ok) {
      const t = await resp.text();
      return res.status(502).json({ error: "Mailchimp error", details: t.slice(0,500) });
    }
    return res.status(202).json({ ok: true, provider: "mailchimp" });

  } catch (e) {
    console.error("newsletter subscribe error", e);
    res.status(500).json({ error: "Server error" });
  }
});

export default router;
