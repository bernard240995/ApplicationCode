const r=require('express').Router();
const Model=require('../models/Promotion');
r.get('/admin/promotions', async(_q,res)=>res.json({{items:await Model.find({{}}).limit(50).lean()}}));
r.post('/admin/promotion', async(req,res)=>res.json({{ok:true, item:await Model.create(req.body||{{}})}}));
r.put('/admin/promotion/:id', async(req,res)=>res.json({{ok:true, item:await Model.findByIdAndUpdate(req.params.id,{{$set:req.body||{{}}}},{{new:true}})}}));
r.delete('/admin/promotion/:id', async(req,res)=>{{ await Model.findByIdAndDelete(req.params.id); res.json({{ok:true}}) }});
module.exports=r;
