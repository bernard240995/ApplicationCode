
// backend/routes/adminFulfillment.js
import express from 'express';
import Order from '../models/Order.js';
let { adminGuard } = await import('../utils/authGuards.js').catch(()=>({ adminGuard:(req,res,next)=>next() }));

const router = express.Router();

// List recent paid/unshipped orders
router.get('/orders', adminGuard, async (req,res)=>{
  const items = await Order.find({ status: { $in:['paid','shipped','delivered'] } }).sort({ createdAt:-1 }).limit(200).lean();
  res.json({ ok:true, items });
});

// Set tracking & mark shipped
router.post('/ship', adminGuard, async (req,res)=>{
  const { orderId, carrier, trackingNumber } = req.body || {};
  const it = await Order.findOneAndUpdate(
    { orderId },
    { $set: { carrier, trackingNumber, status:'shipped', shippedAt: new Date() } },
    { new:true }
  );
  res.json({ ok:true, item: it });
});

// Print-friendly label (HTML) for an order
router.get('/label/:orderId', adminGuard, async (req,res)=>{
  const it = await Order.findOne({ orderId: req.params.orderId }).lean();
  if (!it) return res.status(404).send('Order not found');
  const logoUrl = (process.env.PUBLIC_URL || '') + '/logo.png';
  const lines = (it.items||[]).map(i=>`<tr><td style="padding:4px 0">${i.name} × ${i.quantity}</td></tr>`).join('');
  const html = `
  <!doctype html><html><head><meta charset="utf-8"><title>Label #${it.orderId}</title></head>
  <body style="font-family:Inter,system-ui,Segoe UI,Arial,sans-serif">
    <div style="width:780px;margin:0 auto;border:1px solid #ddd;border-radius:12px;overflow:hidden">
      <div style="padding:12px 16px;display:flex;align-items:center;border-bottom:1px solid #eee;background:#0b0d12;color:#fff">
        <img src="${logoUrl}" alt="FreakyFast" style="height:28px;margin-right:8px" /><b>Packing Label</b>
        <span style="margin-left:auto">#${it.orderId}</span>
      </div>
      <div style="padding:16px">
        <div><b>Ship To:</b> ${it.email}</div>
        <div style="margin-top:8px"><b>Items</b></div>
        <table style="width:100%">${lines}</table>
        <div style="margin-top:8px"><b>Carrier:</b> ${it.carrier||'-'} &nbsp; <b>Tracking:</b> ${it.trackingNumber||'-'}</div>
      </div>
    </div>
    <script>window.onload=()=>window.print();</script>
  </body></html>`;
  res.setHeader('Content-Type','text/html'); return res.send(html);
});

export default router;

router.get('/export.csv', adminGuard, async (req,res)=>{ const rows = await (await import('../models/Order.js')).default.find({ status: { $in:['paid','shipped','delivered'] } }).sort({ createdAt:-1 }).lean(); const header=['orderId','email','status','totalMinor','carrier','trackingNumber','createdAt','shippedAt']; const lines=[header.join(',')].concat(rows.map(r=>[r.orderId,r.email,r.status,r.totalMinor,r.carrier||'',r.trackingNumber||'',r.createdAt?.toISOString()||'',r.shippedAt?.toISOString()||''].join(','))); res.setHeader('Content-Type','text/csv'); res.setHeader('Content-Disposition','attachment; filename="shipments.csv"'); res.send(lines.join('\n')); });
router.post('/bulk-ship', adminGuard, async (req,res)=>{ const { orders=[], carrier='Royal Mail' } = req.body||{}; const Order = (await import('../models/Order.js')).default; const updated=[]; for (const o of orders){ const it = await Order.findOneAndUpdate({ orderId:o.orderId }, { $set:{ carrier, trackingNumber:o.trackingNumber||'', status:'shipped', shippedAt:new Date() } }, { new:true }); if (it) updated.push(it.orderId); } res.json({ ok:true, updated }); });

// Royal Mail Click & Drop style export
router.get('/export-royalmail.csv', adminGuard, async (req,res)=>{
  const rows = await (await import('../models/Order.js')).default.find({ status: { $in:['paid','shipped','delivered'] } }).sort({ createdAt:-1 }).lean();
  const header = ['Name','Company','Address line 1','Address line 2','Town','Postcode','Country','Email','Phone','Weight (g)','Service code','Format','Order number'];
  const lines = [header.join(',')];
  for (const r of rows){
    const line = [
      r.shippingName||'',
      '',
      r.shippingAddress1||'',
      r.shippingAddress2||'',
      r.shippingCity||'',
      r.shippingPostcode||'',
      r.shippingCountry||'GB',
      r.email||'',
      r.shippingPhone||'',
      '',
      '', // service
      '', // format
      r.orderId||''
    ].map(v=>String(v).replace(/,/g,' '));
    lines.push(line.join(','));
  }
  res.setHeader('Content-Type','text/csv');
  res.setHeader('Content-Disposition','attachment; filename="royalmail_clickdrop.csv"');
  res.send(lines.join('\n'));
});

// DPD-style export (basic columns)
router.get('/export-dpd.csv', adminGuard, async (req,res)=>{
  const rows = await (await import('../models/Order.js')).default.find({ status: { $in:['paid','shipped','delivered'] } }).sort({ createdAt:-1 }).lean();
  const header = ['Reference','Contact','Address1','Address2','City','Postcode','Country','Email','Phone','Weight','Service','Instructions'];
  const lines = [header.join(',')];
  for (const r of rows){
    const line = [
      r.orderId||'',
      r.shippingName||'',
      r.shippingAddress1||'',
      r.shippingAddress2||'',
      r.shippingCity||'',
      r.shippingPostcode||'',
      r.shippingCountry||'GB',
      r.email||'',
      r.shippingPhone||'',
      '',
      '',
      ''
    ].map(v=>String(v).replace(/,/g,' '));
    lines.push(line.join(','));
  }
  res.setHeader('Content-Type','text/csv');
  res.setHeader('Content-Disposition','attachment; filename="dpd_import.csv"');
  res.send(lines.join('\n'));
});
