import express from "express";
import { setDrained, isDrained } from "../services/drainState.js";
const router = express.Router();

router.get("/", (req,res)=> res.json({ drained: isDrained() }));

router.post("/", (req,res)=>{
  const secret = process.env.DRAIN_SECRET || "";
  if (secret && req.headers["x-drain-secret"] !== secret) return res.status(403).json({ error: "Forbidden" });
  setDrained(true);
  res.json({ ok: true, drained: true });
});

router.delete("/", (req,res)=>{
  const secret = process.env.DRAIN_SECRET || "";
  if (secret && req.headers["x-drain-secret"] !== secret) return res.status(403).json({ error: "Forbidden" });
  setDrained(false);
  res.json({ ok: true, drained: false });
});

export default router;
