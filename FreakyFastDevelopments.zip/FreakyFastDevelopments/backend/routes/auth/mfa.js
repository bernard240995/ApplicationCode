import express from "express";
import User from "../../models/User.js";
const router = express.Router();

function authedEmail(req){ return req.user?.email; }

router.post("/setup", async (req,res)=>{
  const email = authedEmail(req);
  if (!email) return res.status(401).json({ error: "Unauthorized" });
  const { authenticator } = await import("otplib");
  const secret = authenticator.generateSecret();
  const otpauth = authenticator.keyuri(email, process.env.MFA_ISSUER || "FreakyFast", secret);
  await User.findOneAndUpdate({ email }, { $set: { "mfa.secret": secret } }, { upsert: true });
  res.json({ ok: true, secret, otpauth });
});

router.post("/verify", async (req,res)=>{
  const email = authedEmail(req);
  if (!email) return res.status(401).json({ error: "Unauthorized" });
  const token = String(req.body?.token||"");
  const u = await User.findOne({ email });
  if (!u?.mfa?.secret) return res.status(400).json({ error: "No MFA secret" });
  const { authenticator } = await import("otplib");
  const ok = authenticator.check(token, u.mfa.secret);
  if (!ok) return res.status(400).json({ error: "Invalid token" });
  u.mfa.enabled = true;
  await u.save();
  res.json({ ok: true });
});

export default router;
