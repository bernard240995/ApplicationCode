import express from "express";
import Order from "../../models/Order.js";
import { ensureInvoiceNumber, buildInvoicePdf } from "../../services/invoicePdf.js";
import { signedUrl } from "../../services/s3.js";

const router = express.Router();

function getUserEmail(req){
  // Prefer authenticated user; allow ?email= in dev if ALLOW_QUERY_EMAIL=1
  const u = req.user?.email;
  if (u) return u;
  if (process.env.ALLOW_QUERY_EMAIL === "1") return String(req.query.email||"");
  return null;
}

router.get("/", async (req,res)=>{
  const email = getUserEmail(req);
  if (!email) return res.status(401).json({ error: "Unauthorized" });
  const { status } = req.query || {};
  const filter = { email };
  if (status) filter.status = status;
  const items = await Order.find(filter).sort({ createdAt: -1 }).limit(100).lean();
  res.json({ ok: true, items });
});

router.get("/:id", async (req,res)=>{
  const email = getUserEmail(req);
  if (!email) return res.status(401).json({ error: "Unauthorized" });
  const doc = await Order.findOne({ _id: req.params.id, email });
  if (!doc) return res.status(404).json({ error: "Not found" });
  res.json({ ok: true, doc });
});

router.get("/:id/invoice.pdf", async (req,res)=>{
  const email = getUserEmail(req);
  if (!email) return res.status(401).json({ error: "Unauthorized" });
  const doc = await Order.findOne({ _id: req.params.id, email });
  if (!doc) return res.status(404).json({ error: "Not found" });
                      await ensureInvoiceNumber(doc);
if (process.env.INVOICE_BUCKET && doc.invoiceS3Key){
  const url = await signedUrl({ bucket: process.env.INVOICE_BUCKET, key: doc.invoiceS3Key, expiresIn: Number(process.env.INVOICE_URL_TTL||3600) });
  return res.redirect(url);
}
res.setHeader("Content-Type", "application/pdf");
  res.setHeader("Content-Disposition", `inline; filename="${doc.invoiceNumber}.pdf"`);
  await buildInvoicePdf(doc, res);
});

export default router;
