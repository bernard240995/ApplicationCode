import express from "express";
import EmailEvent from "../../models/EmailEvent.js";
const router = express.Router();
function getUserEmail(req){ const u = req.user?.email; if (u) return u; if (process.env.ALLOW_QUERY_EMAIL === "1") return String(req.query.email||""); return null; }
router.get("/", async (req,res)=>{
  const email = getUserEmail(req);
  if (!email) return res.status(401).json({ error: "Unauthorized" });
  const items = await EmailEvent.find({ to: email }).sort({ createdAt: -1 }).limit(100).lean();
  res.json({ ok: true, items });
});
export default router;
