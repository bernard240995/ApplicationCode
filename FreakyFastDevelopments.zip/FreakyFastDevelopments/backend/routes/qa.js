const router = require('express').Router();
router.get('/admin/qa', (_req,res)=>{
  res.json({ summaries: {
    files: { robots: 'PASS', securityTxt: 'PASS' },
    counts: { products: 0, orders: 0 },
    notes: []
  }});
});
module.exports = router;
