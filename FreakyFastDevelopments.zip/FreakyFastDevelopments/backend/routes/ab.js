// backend/routes/ab.js
import express from 'express';
import ABEvent from '../models/ABEvent.js';

const router = express.Router();

router.post('/track', async (req,res)=>{
  const { exp, var:variant, type, path } = req.body || {};
  if (!exp || !variant || !type) return res.status(400).json({ ok:false, error:'Missing fields'});
  await ABEvent.create({ exp, var: variant, type, path, user: req.user?._id || '' });
  res.json({ ok:true });
});

export default router;
