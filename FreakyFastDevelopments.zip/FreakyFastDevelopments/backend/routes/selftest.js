import express from "express";
import mongoose from "mongoose";
import { createClient } from "redis";
const router = express.Router();

router.get("/", async (req,res)=>{
  const issues = [];
  // Mongo ping
  try{ await mongoose.connection.db.admin().ping(); } catch(e){ issues.push("Mongo ping failed"); }
  // Redis ping
  try{
    if (process.env.REDIS_URL){
      const client = createClient({ url: process.env.REDIS_URL });
      await client.connect();
      await client.ping();
      await client.quit();
    }
  } catch(e){ issues.push("Redis ping failed"); }
  // Required envs
  const required = ["MONGODB_URI","SENTRY_DSN","FRONTEND_ORIGIN"];
  required.forEach(k => { if (!process.env[k]) issues.push(`Missing env ${k}`); });

  res.json({ ok: issues.length === 0, issues });
});

export default router;
