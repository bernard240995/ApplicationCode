import express from "express";
import mongoose from "mongoose";
import { getRedis } from "../../services/redis.js";
const router = express.Router();

router.get("/status/info", async (req,res)=>{
  const info = {
    uptimeSec: Math.floor(process.uptime()),
    node: process.version,
    commit: process.env.COMMIT_SHA || null,
    db: mongoose.connection.readyState,
    redis: !!(await getRedis())
  };
  res.json({ ok: true, info });
});

export default router;
