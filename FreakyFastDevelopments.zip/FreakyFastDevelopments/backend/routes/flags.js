import express from "express";
import fs from "fs";
import path from "path";
const router = express.Router();
const __dirname = path.resolve();
const flagsPath = process.env.FLAGS_FILE || path.join(__dirname, "config", "flags.json");

router.get("/", (req,res)=>{
  try{ const data = JSON.parse(fs.readFileSync(flagsPath,"utf-8")); return res.json({ ok:true, data }); }
  catch{ return res.json({ ok:true, data: {} }); }
});

router.put("/admin", (req,res)=>{
  try{
    const data = req.body?.data || {};
    fs.mkdirSync(path.dirname(flagsPath), { recursive: true });
    fs.writeFileSync(flagsPath, JSON.stringify(data, null, 2));
    return res.json({ ok:true });
  }catch(e){ return res.status(500).json({ error: "Failed to save flags" }); }
});

export default router;
