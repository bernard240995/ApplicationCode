const r=require('express').Router();
const Model=require('../models/Category');
r.get('/admin/categorys', async(_q,res)=>res.json({{items:await Model.find({{}}).limit(50).lean()}}));
r.post('/admin/category', async(req,res)=>res.json({{ok:true, item:await Model.create(req.body||{{}})}}));
r.put('/admin/category/:id', async(req,res)=>res.json({{ok:true, item:await Model.findByIdAndUpdate(req.params.id,{{$set:req.body||{{}}}},{{new:true}})}}));
r.delete('/admin/category/:id', async(req,res)=>{{ await Model.findByIdAndDelete(req.params.id); res.json({{ok:true}}) }});
module.exports=r;
