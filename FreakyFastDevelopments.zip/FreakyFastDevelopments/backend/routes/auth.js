const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { send } = require('../utils/email');
const User = require('../models/User');
const loginShield = require('../middleware/loginShield');

function token(u){
  return jwt.sign({ id:String(u._id), email:u.email, roles:u.roles||[] }, process.env.JWT_SECRET||'devsecret', { expiresIn:'7d' });
}

router.post('/public/auth/register', async (req,res)=>{
  try{
    const { email, password } = req.body||{};
    if(!email || !password) return res.status(400).json({ ok:false, error:'missing' });
    let u = await User.findOne({ email }); if(u) return res.status(409).json({ ok:false, error:'exists' });
    const hash = await bcrypt.hash(password, 10);
    u = await User.create({ email, password: hash, roles: ['customer'] });
    try{ await send({ to: email, subject:'Welcome to FreakyFast', text:'Thanks for registering!' }) }catch(e){}
    return res.json({ ok:true, token: token(u) });
  }catch(e){ return res.status(500).json({ ok:false, error:e.message }) }
});

router.post('/public/auth/login', loginShield, async (req,res)=>{
  try{
    const { email, password } = req.body||{};
    if(process.env.ADMIN_DEV_BYPASS==='1') return res.json({ ok:true, token: jwt.sign({ id:'dev', email, roles:['admin'] }, process.env.JWT_SECRET||'devsecret') });
    const u = await User.findOne({ email }); if(!u) return res.status(401).json({ ok:false, error:'invalid' });
    const ok = await bcrypt.compare(password, u.password||''); if(!ok) return res.status(401).json({ ok:false, error:'invalid' });
    return res.json({ ok:true, token: token(u) });
  }catch(e){ return res.status(500).json({ ok:false, error:e.message }) }
});

router.post('/public/auth/request-reset', async (req,res)=>{
  try{
    const { email } = req.body||{}; if(!email) return res.status(400).json({ ok:false });
    const u = await User.findOne({ email }); if(!u) return res.json({ ok:true });
    const code = Math.random().toString().slice(2,8);
    u.resetCode = code; u.resetExp = new Date(Date.now()+3600*1000); await u.save();
    await send({ to: email, subject:'Password reset', text:`Your code: ${code}` });
    return res.json({ ok:true });
  }catch(e){ return res.status(500).json({ ok:false, error:e.message }) }
});

router.post('/public/auth/reset', async (req,res)=>{
  try{
    const { email, code, password } = req.body||{};
    const u = await User.findOne({ email }); if(!u || !u.resetCode || !u.resetExp || u.resetExp < new Date()) return res.status(400).json({ ok:false });
    if(String(u.resetCode)!==String(code)) return res.status(400).json({ ok:false });
    u.password = await require('bcryptjs').hash(password,10); u.resetCode=null; u.resetExp=null; await u.save();
    return res.json({ ok:true });
  }catch(e){ return res.status(500).json({ ok:false, error:e.message }) }
});

module.exports = router;
