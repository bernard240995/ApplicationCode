import express from "express";
import SessionReplay from "../../models/SessionReplay.js";
const router = express.Router();

router.post("/", async (req,res)=>{
  if (process.env.ENABLE_REPLAY !== "1") return res.status(404).json({ error: "disabled" });
  const { sessionId, user, page, events, startedAt } = req.body||{};
  if (!sessionId || !Array.isArray(events)) return res.status(400).json({ error: "invalid payload" });
  await SessionReplay.create({ sessionId, user, page, events, startedAt: startedAt ? new Date(startedAt) : new Date() });
  res.json({ ok: true });
});

router.get("/", async (req,res)=>{
  if (process.env.ENABLE_REPLAY !== "1") return res.status(404).json({ error: "disabled" });
  const items = await SessionReplay.find().sort({ createdAt: -1 }).limit(50).lean();
  res.json({ ok: true, items });
});

export default router;
