import express from "express";
import mongoose from "mongoose";
const router = express.Router();

function requireAdmin(req,res,next){
  if (process.env.ADMIN_BYPASS_ROLE === "1") return next();
  const role = req.user?.role;
  if (role !== "superadmin") return res.status(403).json({ error: "Admin only" });
  next();
}

// Export data by email or userId
router.get("/dsr/export", requireAdmin, async (req,res)=>{
  const { email, userId } = req.query;
  const db = mongoose.connection.db;
  const out = {};
  const collections = await db.listCollections().toArray();
  const names = collections.map(c=>c.name);
  for (const name of names){
    const col = db.collection(name);
    const query = email ? { $or: [ { email }, { "shipping.email": email }, { "customer.email": email } ] } :
                 userId ? { $or: [ { userId }, { "user.id": userId } ] } : null;
    if (!query) continue;
    const docs = await col.find(query).limit(500).toArray();
    if (docs.length) out[name] = docs;
  }
  res.json({ ok: true, data: out });
});

// Delete data (soft delete recommended; here we anonymize basic fields)
router.post("/dsr/delete", requireAdmin, async (req,res)=>{
  const { email, userId } = req.body || {};
  if (!email && !userId) return res.status(400).json({ error: "email or userId required" });
  const db = mongoose.connection.db;
  const collections = await db.listCollections().toArray();
  const names = collections.map(c=>c.name);
  let changes = 0;
  for (const name of names){
    const col = db.collection(name);
    const query = email ? { $or: [ { email }, { "shipping.email": email }, { "customer.email": email } ] } :
                 userId ? { $or: [ { userId }, { "user.id": userId } ] } : null;
    if (!query) continue;
    const res1 = await col.updateMany(query, { $set: { email: "deleted@user", "customer.email": "deleted@user", "shipping.email": "deleted@user" } });
    changes += res1.modifiedCount || 0;
  }
  res.json({ ok: true, changes });
});

export default router;
