// backend/routes/adminAudit.js
import express from 'express';
import AdminAudit from '../models/AdminAudit.js';
let adminGuard = (req,res,next)=>next();
try { ({ adminGuard } = await import('../utils/authGuards.js')); } catch {}

const router = express.Router();
router.get('/', adminGuard, async (req,res)=>{
  const items = await AdminAudit.find().sort({ createdAt:-1 }).limit(200);
  res.json({ ok:true, items });
});
export default router;
