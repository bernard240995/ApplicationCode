
import express from "express";
import Coupon from "../models/Coupon.js";

const router = express.Router();

router.get("/validate", async (req,res)=>{
  const code = String(req.query.code || "").trim().toUpperCase();
  const subtotal = Number(req.query.subtotal || 0); // pence
  if (!code) return res.status(400).json({ error: "Missing code" });
  const coupon = await Coupon.findOne({ code }).lean();
  if (!coupon) return res.status(404).json({ error: "Invalid coupon" });

  // replicate isValidNow logic in lean mode
  const now = new Date();
  if (coupon.active === false ||
      (coupon.startsAt && now < new Date(coupon.startsAt)) ||
      (coupon.endsAt && now > new Date(coupon.endsAt)) ||
      (coupon.maxUses && coupon.used >= coupon.maxUses) ||
      (subtotal < (coupon.minSubtotal || 0))) {
    return res.status(400).json({ error: "Coupon not applicable" });
  }

  if (coupon.type === "percent"){
    return res.json({ code: coupon.code, type: "percent", percent_off: coupon.value });
  } else {
    return res.json({ code: coupon.code, type: "fixed", amount_off: coupon.value });
  }
});

export default router;
