// backend/routes/adminPages.js
import express from 'express';
import CmsPage from '../models/CmsPage.js';
import Setting from '../models/Setting.js';
let adminGuard = (req,res,next)=>next();
try { ({ adminGuard } = await import('../utils/authGuards.js')); } catch {}

const router = express.Router();

router.get('/pages', adminGuard, async (_req, res) => {
  const items = await CmsPage.find().sort({ slug: 1 });
  res.json({ ok:true, items });
});

router.post('/pages', adminGuard, async (req, res) => {
  const { slug, title, content, status='published', metaTitle='', metaDescription='', ogImage='' } = req.body;
  const item = await CmsPage.findOneAndUpdate({ slug }, { title, content, status, metaTitle, metaDescription, ogImage }, { upsert: true, new: true });
  res.json({ ok:true, item });
});

router.delete('/pages/:slug', adminGuard, async (req, res) => {
  await CmsPage.deleteOne({ slug: req.params.slug });
  res.json({ ok:true });
});

router.get('/settings', adminGuard, async (_req, res) => {
  const items = await Setting.find().sort({ key: 1 });
  res.json({ ok:true, items });
});

router.post('/settings', adminGuard, async (req, res) => {
  const { key, value } = req.body;
  if (!key) return res.status(400).json({ ok:false, error: 'Key required' });
  const item = await Setting.findOneAndUpdate({ key }, { value }, { upsert: true, new: true });
  res.json({ ok:true, item });
});

export default router;
