import express from "express";
let sharp;
try { sharp = (await import("sharp")).default; } catch { sharp = null; }
const router = express.Router();

router.get("/", async (req,res)=>{
  if (process.env.ENABLE_IMAGE_PROXY !== "1" || !sharp) return res.status(501).json({ error: "Image proxy disabled" });
  const src = req.query.src;
  const w = parseInt(String(req.query.w||"0"),10) || null;
  const h = parseInt(String(req.query.h||"0"),10) || null;
  if (!src) return res.status(400).json({ error: "src required" });
  try{
    const fetchRes = await fetch(src);
    const buf = Buffer.from(await fetchRes.arrayBuffer());
    let img = sharp(buf).resize(w, h, { fit: "inside", withoutEnlargement: true });
    const format = String(req.query.f||"webp").toLowerCase();
    if (format === "avif") img = img.avif({ quality: 50 });
    else if (format === "jpeg" || format === "jpg") img = img.jpeg({ quality: 80 });
    else img = img.webp({ quality: 70 });
    const out = await img.toBuffer();
    res.set("Cache-Control", "public, max-age=31536000, immutable");
    res.type(format === "jpeg" || format==="jpg" ? "image/jpeg" : format === "avif" ? "image/avif" : "image/webp").send(out);
  }catch(e){
    res.status(500).json({ error: "Processing failed" });
  }
});

export default router;
