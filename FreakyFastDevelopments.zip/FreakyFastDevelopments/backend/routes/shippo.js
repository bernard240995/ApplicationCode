
import express from "express";
import fetch from "node-fetch";
const router = express.Router();

// Requires SHIPPO_API_TOKEN in env; this is a safe stub that proxies rate fetch.
router.post("/rates", async (req,res)=>{
  const token = process.env.SHIPPO_API_TOKEN;
  if (!token) return res.status(501).json({ error: "Shippo not configured" });
  try{
    // Minimal payload example; in real use, map items -> parcel, addresses from checkout
    const { items = [], postcode = "SW1A1AA" } = req.body || {};
    const weight_kg = Math.max(0.1, items.reduce((a,b)=> a + ((b.weight_g||200)/1000) * (b.qty||1), 0));
    const shipment = {
      address_from: { name:"Warehouse", street1:"1 Example St", city:"London", zip:"SW1A 1AA", country:"GB" },
      address_to:   { name:"Customer",  street1:"unknown",     city:"unknown", zip: String(postcode||"").replace(/\s+/g,""), country:"GB" },
      parcels: [{ weight: String(weight_kg), mass_unit: "kg", length:"20", width:"20", height:"10", distance_unit:"cm" }]
    };
    const r = await fetch("https://api.goshippo.com/shipments/", {
      method: "POST",
      headers: { "Content-Type":"application/json", "Authorization": `ShippoToken ${token}` },
      body: JSON.stringify({ ...shipment, async: false })
    });
    const data = await r.json();
    if (!r.ok) return res.status(r.status).json(data);
    // Extract top 5 rates
    const rates = (data?.rates || []).slice(0,5).map(rt => ({
      carrier: rt.provider,
      service: rt.servicelevel?.name,
      amount: Math.round(parseFloat(rt.amount || "0") * 100),
      currency: rt.currency || "GBP",
      estimated_days: rt.estimated_days
    }));
    res.json({ rates });
  }catch(e){
    console.error(e);
    res.status(500).json({ error: "Shippo error" });
  }
});

export default router;
