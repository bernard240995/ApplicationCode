// backend/routes/adminBanners.js
import express from 'express';
import Banner from '../models/Banner.js';
let { adminGuard } = await import('../utils/authGuards.js').catch(()=>({ adminGuard:(req,res,next)=>next() }));
const router = express.Router();

router.get('/', adminGuard, async (req,res)=>{
  res.json({ ok:true, items: await Banner.find().sort({order:1,createdAt:-1}).lean() });
});
router.post('/', adminGuard, async (req,res)=>{
  res.json({ ok:true, item: await Banner.create(req.body||{}) });
});
router.patch('/:id', adminGuard, async (req,res)=>{
  res.json({ ok:true, item: await Banner.findByIdAndUpdate(req.params.id, req.body||{}, {new:true}) });
});
router.delete('/:id', adminGuard, async (req,res)=>{
  await Banner.findByIdAndDelete(req.params.id); res.json({ ok:true });
});
export default router;
