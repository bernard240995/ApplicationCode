// backend/routes/supportTickets.js
import express from 'express';
import Ticket from '../models/Ticket.js';
import { createTransport, renderTicketEmail } from '../utils/email.js';
let adminGuard = (req,res,next)=>next();
try { ({ adminGuard } = await import('../utils/authGuards.js')); } catch {}

const router = express.Router();

router.post('/', async (req, res) => {
  try {
    const { subject, message, name, email, phone, orderId, priority = 'normal' } = req.body;
    if (!subject || !message) return res.status(400).json({ ok:false, error: 'Subject and message required' });

    const ticket = await Ticket.create({
      subject, message, name, email, phone, orderId, priority,
      userId: req.user?._id
    });

    try{
      const transporter = await createTransport();
      const html = await renderTicketEmail(ticket);
      await transporter.sendMail({
        from: `"FreakyFast Support" <${process.env.SMTP_USER || "support@localhost"}>`,
        to: (process.env.SUPPORT_EMAIL || process.env.SMTP_USER),
        subject: `New Support Ticket: ${ticket.subject}`,
        html
      });
      if (ticket.email) {
        await transporter.sendMail({
          from: `"FreakyFast Support" <${process.env.SMTP_USER || "support@localhost"}>`,
          to: ticket.email,
          subject: `We received your request — ${ticket.subject}`,
          html
        });
      }
    }catch(e){} 
    res.json({ ok:true, ticket });
  } catch (e) {
    return res.status(500).json({ ok:false, error: 'Failed to create ticket' });
  }
});

router.get('/admin', adminGuard, async (_req, res) => {
  const items = await Ticket.find().sort({ createdAt: -1 }).limit(500);
  res.json({ ok:true, items });
});

router.patch('/:id/status', adminGuard, async (req, res) => {
  const { status } = req.body;
  const allowed = ['open','pending','resolved','closed'];
  if (!allowed.includes(status)) return res.status(400).json({ ok:false, error: 'Invalid status' });
  const t = await Ticket.findByIdAndUpdate(req.params.id, { status }, { new: true });
  try{
    if (t?.email){
      const transporter = await createTransport();
      const html = await renderTicketEmail(t, {statusChanged:true});
      await transporter.sendMail({
        from: `"FreakyFast Support" <${process.env.SMTP_USER || "support@localhost"}>`,
        to: t.email,
        subject: `Your ticket status: ${t.status}`,
        html
      });
    }
  }catch(e){}
  res.json({ ok:true, ticket: t });
});

export default router;
