// backend/routes/adminPromos.js
import express from 'express';
import PromoCode from '../models/PromoCode.js';
let { adminGuard } = await import('../utils/authGuards.js').catch(()=>({ adminGuard:(req,res,next)=>next() }));
const router = express.Router();

router.get('/', adminGuard, async (req,res)=>{
  res.json({ ok:true, items: await PromoCode.find().sort({createdAt:-1}).lean() });
});
router.post('/', adminGuard, async (req,res)=>{
  res.json({ ok:true, item: await PromoCode.create(req.body||{}) });
});
router.patch('/:id', adminGuard, async (req,res)=>{
  res.json({ ok:true, item: await PromoCode.findByIdAndUpdate(req.params.id, req.body||{}, {new:true}) });
});
router.delete('/:id', adminGuard, async (req,res)=>{
  await PromoCode.findByIdAndDelete(req.params.id); res.json({ ok:true });
});
export default router;
