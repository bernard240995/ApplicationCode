// backend/routes/sitemap.js
import express from 'express';
import CmsPage from '../models/CmsPage.js';

const router = express.Router();

router.get('/sitemap.xml', async (req,res) => {
  const origin = (req.protocol + '://' + req.get('host'));
  const pages = await CmsPage.find({ status:'published' }).select('slug').lean();
  const urls = pages.map(p => `${origin}/pages/${p.slug}`);
  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url><loc>${origin}/</loc></url>
  ${urls.map(u=>`<url><loc>${u}</loc></url>`).join('\n  ')}
  ${ (await import('../models/Product.js').then(m=>m.default.find().lean()).catch(()=>[])).map(p=>`<url><loc>${origin}/products/${p.slug}</loc></url>`).join('\n  ')}
</urlset>`;
  res.set('Content-Type','application/xml').send(xml);
});

export default router;
