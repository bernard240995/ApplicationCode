import express from "express";
import Stripe from "stripe";
const router = express.Router();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", { apiVersion: "2022-11-15" });

router.post("/checkout", express.json(), async (req,res)=>{
  try{
    const { items=[], customer_email, success_url, cancel_url, currency="gbp" } = req.body || {};
    const line_items = items.map(i => ({
      quantity: i.qty || 1,
      price_data: {
        currency,
        unit_amount: Math.round((i.price||0) * 100),
        product_data: { name: i.name || "Item", images: i.imageUrl ? [i.imageUrl] : [] }
      }
    }));
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      customer_email,
      line_items,
      success_url: success_url || (process.env.FRONTEND_ORIGIN || "http://localhost:3000") + "/checkout/success?session_id={CHECKOUT_SESSION_ID}",
      cancel_url: cancel_url || (process.env.FRONTEND_ORIGIN || "http://localhost:3000") + "/checkout/cancel",
      metadata: req.body?.metadata || {}
    });
    res.json({ ok: true, id: session.id, url: session.url });
  }catch(e){
    res.status(500).json({ error: "Stripe checkout failed", detail: e?.message });
  }
});

export default router;
