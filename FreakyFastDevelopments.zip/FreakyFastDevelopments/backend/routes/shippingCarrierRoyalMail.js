import express from "express";
const router = express.Router();

// Placeholder carrier integration. In production, call Royal Mail/Shippo here.
router.post("/rates", async (req,res)=>{
  const { items = [], postcode = "", subtotal_pence = 0 } = req.body || {};
  // Return demo carrier-calculated rates (mirroring shippingRates.js but as 'carrier')
  const totalWeight = items.reduce((a,b)=> a + ((b.weight_g||250) * (b.qty||1)), 0);
  const standard = 0; // free promo
  const express = totalWeight > 2000 ? 799 : 499;
  const nextDay = totalWeight > 2000 ? 1299 : 999;
  res.json({
    carrier: "RoyalMail",
    rates: [
      { id: "rm_standard", label: "RM Standard", price_pence: standard, eta: "2-3 working days" },
      { id: "rm_express", label: "RM Tracked 24/48", price_pence: express, eta: "1-2 working days" },
      { id: "rm_next", label: "RM Special Delivery", price_pence: nextDay, eta: "Next working day" }
    ]
  });
});

export default router;
