// backend/routes/publicReviews.js
import express from 'express';
import Review from '../models/Review.js';
const router = express.Router();
router.get('/:slug', async (req,res)=>{
  const items = await Review.find({productSlug:req.params.slug, status:'approved'}).sort({createdAt:-1}).lean();
  res.json({ ok:true, items });
});
export default router;
