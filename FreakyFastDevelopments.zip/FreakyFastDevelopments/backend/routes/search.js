import express from "express";
import Product from "../models/Product.js";
const router = express.Router();
import { cacheGet, cacheSet } from "../services/redis.js";

router.get("/", async (req,res)=>{
  const cacheKey = "search:" + (req.query.q||"") + ":" + (req.query.limit||"");
  const cached = await cacheGet(cacheKey);
  if (cached) return res.json(JSON.parse(cached));
  const q = String(req.query.q || "").trim();
  const limit = Math.min(50, parseInt(req.query.limit||"20",10));
  if (process.env.MEILI_URL && process.env.MEILI_KEY){
    try{
      const { MeiliSearch } = await import("meilisearch");
      const client = new MeiliSearch({ host: process.env.MEILI_URL, apiKey: process.env.MEILI_KEY });
      const idx = client.index(process.env.MEILI_INDEX || "products");
      const r = await idx.search(q, { limit });
      const payload = { ok: true, source: "meili", hits: r.hits };
      await cacheSet(cacheKey, JSON.stringify(payload), 60);
      return res.json(payload);
    }catch(e){ /* fallback */ }
  }
  const f = q ? { $text: { $search: q } } : {};
  const items = await Product.find(f).limit(limit).lean();
  const payload = { ok: true, source: "mongo", hits: items };
  await cacheSet(cacheKey, JSON.stringify(payload), 60);
  res.json(payload);
});

export default router;
