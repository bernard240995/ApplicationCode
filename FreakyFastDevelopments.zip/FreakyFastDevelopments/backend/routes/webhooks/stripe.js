import express from "express";
import Stripe from "stripe";
import WebhookEvent from "../../models/WebhookEvent.js";
import { upsertOrderFromStripeSession } from "../../services/orders.js";

const router = express.Router();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", { apiVersion: "2022-11-15" });

router.post("/", express.raw({ type: "application/json" }), async (req,res)=>{
  const sig = req.headers["stripe-signature"];
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!secret) return res.status(500).send("Stripe webhook not configured");
  let event;
  try{
    event = Stripe.webhooks.constructEvent(req.body, sig, secret);
  }catch (err){
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }
  try{
    const exists = await WebhookEvent.findOne({ eventId: event.id });
    if (exists) return res.json({ ok: true, dedup: true });
    await WebhookEvent.create({ provider: "stripe", eventId: event.id, payload: event, processed: false });
try{
  switch (event.type){
    case "checkout.session.completed":
      await upsertOrderFromStripeSession(event.data.object);
      break;
    case "charge.refunded":
      // TODO: mark order as refunded if linked
      break;
    default:
      break;
  }
}catch(_){}

    // TODO: handle event types mapping to order updates (checkout.session.completed, charge.refunded, etc.)
    // Keep processing async off the webhook thread in a real worker if needed

    res.json({ ok: true });
  }catch(e){
    res.status(500).json({ error: "Failed to persist event" });
  }
});

export default router;
