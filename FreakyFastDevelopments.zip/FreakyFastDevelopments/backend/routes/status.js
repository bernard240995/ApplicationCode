import client from "prom-client";
import { isDrained } from "../services/drainState.js";
import { emailQueue } from "../queues/emailQueue.js";
const Q_WAIT = new client.Gauge({ name:"bullmq_jobs_waiting", help:"BullMQ waiting jobs" });
const Q_ACTIVE = new client.Gauge({ name:"bullmq_jobs_active", help:"BullMQ active jobs" });
const Q_COMPLETED = new client.Gauge({ name:"bullmq_jobs_completed", help:"BullMQ completed jobs" });
const Q_FAILED = new client.Gauge({ name:"bullmq_jobs_failed", help:"BullMQ failed jobs" });
const Q_DELAYED = new client.Gauge({ name:"bullmq_jobs_delayed", help:"BullMQ delayed jobs" });
async function updateQueueMetrics(){
  try{
    const c = await emailQueue.getJobCounts();
    Q_WAIT.set(c.waiting||0); Q_ACTIVE.set(c.active||0); Q_COMPLETED.set(c.completed||0); Q_FAILED.set(c.failed||0); Q_DELAYED.set(c.delayed||0);
  }catch(_){}
}

const r=require('express').Router(); r.get('/public/status',(_q,res)=>res.json({ok:true,ts:Date.now()})); module.exports=r;