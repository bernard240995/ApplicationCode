
// backend/routes/publicRewardsBalance.js
import express from 'express';
import RewardPoint from '../models/RewardPoint.js';
const router = express.Router();
router.get('/balance', async (req,res)=>{
  const email = String(req.query.email||'').toLowerCase();
  if (!email) return res.json({ ok:true, points:0 });
  const ag = await RewardPoint.aggregate([
    { $match: { email } },
    { $group: { _id:null, points: { $sum: '$points' } } }
  ]);
  const points = (ag[0]?.points)||0;
  res.json({ ok:true, points });
});
export default router;
