// backend/routes/adminExperiments.js
import express from 'express';
import HeroVariant from '../models/HeroVariant.js';
let adminGuard = (req,res,next)=>next();
try { ({ adminGuard } = await import('../utils/authGuards.js')); } catch {}

const router = express.Router();

router.get('/hero', adminGuard, async (_req,res) => {
  const items = await HeroVariant.find().sort({ key:1, variant:1 });
  res.json({ ok:true, items });
});

router.post('/hero', adminGuard, async (req,res) => {
  const { key='home_hero', variant, headline='', subhead='', ctaText='Shop Now', ctaHref='/shop', imageUrl='/assets/banners/banner1.jpg', status='active', weight=1 } = req.body;
  if (!variant) return res.status(400).json({ ok:false, error:'variant required' });
  const item = await HeroVariant.findOneAndUpdate({ key, variant }, { headline, subhead, ctaText, ctaHref, imageUrl, status, weight }, { upsert:true, new:true });
  res.json({ ok:true, item });
});

router.delete('/hero/:id', adminGuard, async (req,res) => {
  await HeroVariant.findByIdAndDelete(req.params.id);
  res.json({ ok:true });
});

export default router;
