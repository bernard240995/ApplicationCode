import express from "express";
import SiteConfig from "../../models/SiteConfig.js";
import { requirePerm } from "../../policies/rbac.js";
const router = express.Router();

router.get("/footer", async (req,res)=>{
  const doc = await SiteConfig.findOne({ key: "footer" }).lean();
  res.json({ ok: true, value: doc?.value });
});

router.post("/footer", requirePerm("site","write"), async (req,res)=>{
  const value = req.body?.value || {};
  const doc = await SiteConfig.findOneAndUpdate({ key: "footer" }, { $set: { value } }, { new: true, upsert: true });
  res.json({ ok: true, value: doc.value });
});

export default router;
