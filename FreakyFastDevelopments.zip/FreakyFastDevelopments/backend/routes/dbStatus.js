import express from "express";
import mongoose from "mongoose";
const router = express.Router();

router.get("/", async (req,res)=>{
  try{
    const db = mongoose.connection.db;
    const cols = await db.listCollections().toArray();
    const names = cols.map(c=>c.name).sort();
    res.json({ ok: true, db: mongoose.connection.name, collections: names });
  }catch(e){
    res.status(500).json({ ok: false, error: e?.message });
  }
});

export default router;
