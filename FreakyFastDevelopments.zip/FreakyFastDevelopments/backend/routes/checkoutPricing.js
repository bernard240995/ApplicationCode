
// backend/routes/checkoutPricing.js
import express from 'express';
import PromoCode from '../models/PromoCode.js';
import RewardPoint from '../models/RewardPoint.js';

const router = express.Router();

// POST /api/checkout/apply-promo  { code, totalMinor }
router.post('/apply-promo', async (req,res)=>{
  const { code, totalMinor } = req.body || {};
  const resp = { ok:true, totalMinor: Number(totalMinor||0), discountMinor: 0 };
  if (!code) return res.json(resp);
  const promo = await PromoCode.findOne({ code: String(code).toUpperCase(), active:true }).lean();
  if (!promo) return res.json(resp);
  const now = new Date();
  if (promo.startsAt && now < promo.startsAt) return res.json(resp);
  if (promo.endsAt && now > promo.endsAt) return res.json(resp);
  let discount = 0;
  if (promo.type === 'percent') discount = Math.round((resp.totalMinor * Number(promo.value||0))/100);
  if (promo.type === 'fixed') discount = Math.round(Number(promo.value||0));
  if (promo.type === 'shipping') discount = 0; // free shipping handled client-side; keep subtotal same
  resp.discountMinor = Math.min(discount, resp.totalMinor);
  resp.totalMinor = resp.totalMinor - resp.discountMinor;
  return res.json(resp);
});

// POST /api/checkout/redeem-points { email, points, totalMinor }
// Rule: 100 points = £5 (i.e., 5 pence per point)
router.post('/redeem-points', async (req,res)=>{
  const { email, points, totalMinor } = req.body || {};
  const usePts = Math.max(0, Math.floor(Number(points||0)));
  const valuePerPointMinor = 5; // £0.05 == 5 minor units
  const creditMinor = usePts * valuePerPointMinor;
  const newTotal = Math.max(0, Number(totalMinor||0) - creditMinor);
  // Record redemption (negative points)
  if (email && usePts>0){
    await RewardPoint.create({ email, points: -usePts, note: 'Checkout redemption' });
  }
  return res.json({ ok:true, creditMinor, totalMinor:newTotal });
});

export default router;
