
// backend/routes/stripeCheckout.js
import express from 'express';
import PromoCode from '../models/PromoCode.js';
import Reservation from '../models/Reservation.js';
import Product from '../models/Product.js';
import RewardPoint from '../models/RewardPoint.js';
import { sendOrderEmail, renderOrderEmail } from '../utils/mailer.js';

const router = express.Router();

async function reserveStock(items=[], email){
  const held = [];
  for (const it of (items||[])){
    const name = String(it.name||'').trim();
    const slug = (it.productSlug) || name.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,'');
    const qty = Math.max(1, Number(it.quantity||1));
    const p = await Product.findOne({ $or:[{ title:name }, { slug }] });
    if (p){
      await Product.updateOne({ _id:p._id }, { $inc: { stock: -qty } });
      held.push({ productSlug: p.slug || slug, name: p.title || name, quantity: qty });
    }
  }
  const resv = await Reservation.create({ email, items: held, status:'held', expiresAt: new Date(Date.now() + 1000*60*30) });
  return resv;
}
async function linkReservationSession(resvId, sessionId){ await Reservation.updateOne({ _id:resvId }, { $set: { stripeSessionId: sessionId } }); }
async function releaseReservationBySession(sessionId){
  const resv = await Reservation.findOne({ stripeSessionId: sessionId, status:'held' });
  if (!resv) return;
  for (const it of (resv.items||[])){ await Product.updateOne({ slug: it.productSlug }, { $inc: { stock: it.quantity } }); }
  await Reservation.updateOne({ _id: resv._id }, { $set: { status:'released' } });
}


function calcFromItems(items){
  const subtotal = (items||[]).reduce((s,i)=>s + (Number(i.amountMinor||0) * Number(i.quantity||1)), 0);
  return { subtotal };
}

async function applyPromo(code, totalMinor){
  if (!code) return { totalMinor, discountMinor:0, freeShipping:false };
  const promo = await PromoCode.findOne({ code: String(code).toUpperCase(), active:true }).lean();
  if (!promo) return { totalMinor, discountMinor:0, freeShipping:false };
  let d = 0, free = false;
  if (promo.type==='percent') d = Math.round((totalMinor * Number(promo.value||0))/100);
  if (promo.type==='fixed') d = Math.round(Number(promo.value||0));
  if (promo.type==='shipping') free = true;
  d = Math.min(d, totalMinor);
  return { totalMinor: totalMinor - d, discountMinor: d, freeShipping: free };
}

async function redeemPoints(email, points, totalMinor){
  const valuePerPointMinor = 5; // 100 points = £5
  const usePts = Math.max(0, Math.floor(Number(points||0)));
  const credit = usePts * valuePerPointMinor;
  const newTotal = Math.max(0, Number(totalMinor||0) - credit);
  if (email && usePts>0){
    await RewardPoint.create({ email, points: -usePts, note:'Checkout redemption (pre-charge)' });
  }
  return { totalMinor: newTotal, creditMinor: credit };
}

router.post('/create-session', async (req,res)=>{
  try{
    const { items=[], email, promoCode, redeemPoints: pts=0 } = req.body || {};
    const { subtotal } = calcFromItems(items);
    const reservation = await reserveStock(items, email);
    let total = subtotal;
    const promoRes = await applyPromo(promoCode, total); total = promoRes.totalMinor;
    const pointsRes = await redeemPoints(email, pts, total); total = pointsRes.totalMinor;

    // Build Stripe line items from items (amountMinor in pence)
    const line_items = items.map(i=>({
      price_data: {
        currency: 'gbp',
        product_data: { name: i.name },
        unit_amount: Number(i.amountMinor||0)
      },
      quantity: Number(i.quantity||1)
    }));
    // Adjustments are represented via discounts/coupons normally; here we fold into total by adding a synthetic line item when needed.
    // Note: For production, prefer Stripe Coupons / Promotion Codes.

    const STRIPE_KEY = process.env.STRIPE_SECRET_KEY;
    if (!STRIPE_KEY){
      return res.status(200).json({ ok:true, requiresStripeKey:true, totalMinor: total, preview:true });
    }
    const stripe = (await import('stripe')).default(STRIPE_KEY);

    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      customer_email: email,
      line_items,
      success_url: (process.env.PUBLIC_URL || 'http://localhost:3000') + '/checkout/success?sid={CHECKOUT_SESSION_ID}',
      cancel_url: (process.env.PUBLIC_URL || 'http://localhost:3000') + '/cart',
      currency: 'gbp'
    });

    await linkReservationSession(reservation._id, session.id);
    res.json({ ok:true, id: session.id, url: session.url, totalMinor: total });
  }catch(e){
    console.error(e);
    res.status(500).json({ ok:false, error: 'stripe_session_error' });
  }
});

// Lightweight success handler (call after webhook or success page fetch)
router.post('/send-confirmation', async (req,res)=>{
  try{
    const { email, orderId, items=[], totalMinor } = req.body || {};
    if (email){
      const html = renderOrderEmail({ orderId, items, totalMinor });
      await sendOrderEmail({ to: email, subject: 'Your FreakyFast Order Confirmation', html });
    }
    res.json({ ok:true });
  }catch(e){
    console.error(e); res.status(500).json({ ok:false });
  }
});

export default router;

router.post('/release-reservation', async (req,res)=>{ try{ const { sessionId } = req.body||{}; await releaseReservationBySession(sessionId); res.json({ ok:true }); }catch(e){ console.error(e); res.status(500).json({ ok:false }); }});
