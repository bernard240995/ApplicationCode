// backend/routes/productsPublic.js
import express from 'express';
import Product from '../models/Product.js';

const router = express.Router();

function displayStock(p){
  const s = Number(p.stock||0);
  const min = Number(p.minStock||0);
  if (s < min) return 0;
  return s; // per requirement: send 0 when below min; otherwise send actual
}

router.get('/', async (req,res)=>{
  const { slug } = req.query || {};
  const filter = { status:'active' };
  if (slug) filter.slug = slug;
  const items = await Product.find(filter).sort({ createdAt:-1 }).lean();
  const mapped = items.map(p => ({
    _id: p._id,
    title: p.title,
    slug: p.slug,
    priceMinor: p.priceMinor || Math.round((p.price||0)*100),
    currency: p.currency || 'GBP',
    images: p.images || [],
    sizes: p.sizes || [],
    colors: p.colors || [],
    stock: displayStock(p)
  }));
  res.json({ ok:true, items: mapped });
});

export default router;
