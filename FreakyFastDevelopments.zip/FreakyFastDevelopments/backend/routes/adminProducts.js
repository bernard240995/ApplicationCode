// backend/routes/adminProducts.js
import express from 'express';
import Product from '../models/Product.js';
let adminGuard = (req,res,next)=>next();
try { ({ adminGuard } = await import('../utils/authGuards.js')); } catch {}

const router = express.Router();

router.get('/', adminGuard, async (req,res)=>{
  const items = await Product.find().sort({ createdAt:-1 }).limit(500).lean();
  res.json({ ok:true, items });
});

router.post('/', adminGuard, async (req,res)=>{
  let b = req.body || {};
  if (!b.slug) b.slug = (b.title||'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'');
  const item = await Product.create(b);
  res.json({ ok:true, item });
});

router.patch('/:id', adminGuard, async (req,res)=>{
  const item = await Product.findByIdAndUpdate(req.params.id, req.body||{}, { new:true });
  res.json({ ok:true, item });
});

router.delete('/:id', adminGuard, async (req,res)=>{
  await Product.findByIdAndUpdate(req.params.id, { status:'archived' });
  res.json({ ok:true });
});

export default router;
