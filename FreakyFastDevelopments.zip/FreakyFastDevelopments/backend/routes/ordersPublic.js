import { emailQueue } from "../queues/emailQueue.js";

import express from "express";
import mongoose from "mongoose";
const router = express.Router();

import Order from "../models/Order.js";

router.get("/:id", async (req,res)=>{
  try{
    const id = req.params.id;
    if (!mongoose.Types.ObjectId.isValid(id)) return res.status(400).json({ error: "Invalid id" });
    const doc = await Order.findById(id).lean();
    if (!doc) return res.status(404).json({ error: "Not found" });
    try{
  const email = req.body?.shipping?.email;
  if (email) {
    await emailQueue.add("order-confirmation", {
      to: email,
      subject: "Your Freaky Fast order",
      text: `Thanks for your order ${data?.id||""}. We’ll notify you when it ships.`,
      html: `<p>Thanks for your order <strong>${data?.id||""}</strong>. We’ll notify you when it ships.</p>`
    });
  }
}catch(_){}
res.json(doc);
  }catch(e){
    res.status(500).json({ error: "Server error" });
  }
});

export default router;
