
// backend/routes/stripeWebhook.js
import express from 'express';
import Order from '../models/Order.js';
import Reservation from '../models/Reservation.js';
import Product from '../models/Product.js';
import { sendOrderEmail, renderOrderEmail } from '../utils/mailer.js';

const router = express.Router();

// We expect app to mount express.raw({type:'application/json'}) on this route
router.post('/', async (req,res)=>{
  try{
    const stripeKey = process.env.STRIPE_SECRET_KEY;
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
    if (!stripeKey || !webhookSecret){
      // In dev without secrets, accept event for local testing
      
    } else if (event.type === 'checkout.session.expired'){
      const session = event.data.object;
      try{
        const resv = await Reservation.findOne({ stripeSessionId: session.id, status:'held' });
        if (resv){
          for (const it of (resv.items||[])){
            await Product.updateOne({ slug: it.productSlug }, { $inc: { stock: it.quantity } });
          }
          await Reservation.updateOne({ _id: resv._id }, { $set: { status:'released' } });
        }
      }catch(e){ console.error('release on expired error', e); }

    return res.status(200).send('ok');
    }
    const stripe = (await import('stripe')).default(stripeKey);
    const sig = req.headers['stripe-signature'];
    let event;
    try {
      event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
    } catch (err) {
      console.error('Webhook signature verification failed.', err.message);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    if (event.type === 'checkout.session.completed'){
      const resv = await Reservation.findOne({ stripeSessionId: event.data.object.id, status:'held' });
      if (resv){ await Reservation.updateOne({ _id: resv._id }, { $set: { status:'captured' } }); }
      const session = event.data.object;
      try{
        // Retrieve line items
        const lineItems = await stripe.checkout.sessions.listLineItems(session.id);
        const items = (lineItems.data||[]).map(li=>({
          name: li.description,
          quantity: li.quantity,
          amountMinor: li.amount_subtotal // amount per line (subtotal)
        }));
        const totalMinor = Number(session.amount_total || 0);
        const orderId = session.client_reference_id || session.id;

        // Upsert order
        
        // Decrement inventory for each item (best-effort by product title match)
        try {
          const Product = (await import('../models/Product.js')).default;
          for (const it of items){
            // try match by name first, fallback by slug-like
            const name = String(it.name||'').trim();
            const slug = name.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,'');
            const p = await Product.findOne({ $or:[{ title:name }, { slug }] }).lean();
            if (p){
              await Product.updateOne({ _id:p._id }, { $inc: { stock: -Math.max(1, Number(it.quantity||1)) } });
            }
          }
        } catch(e){ console.error('inventory decrement error', e); }

        const addr = session.customer_details?.address || {};
        const shippingName = session.customer_details?.name || '';
        const shippingPhone = session.customer_details?.phone || '';
        await Order.findOneAndUpdate(
          { stripeSessionId: session.id },
          {
            orderId,
            email: session.customer_details?.email || session.customer_email,
            items,
            totalMinor,
            status: 'paid',
            stripeSessionId: session.id,
            paymentIntentId: session.payment_intent
          },
          { upsert:true, new:true }
        );

        // Send confirmation email
        const to = session.customer_details?.email || session.customer_email;
        if (to){
          const html = renderOrderEmail({ orderId,
            shippingName,
            shippingAddress1: addr.line1||'',
            shippingAddress2: addr.line2||'',
            shippingCity: addr.city||'',
            shippingPostcode: addr.postal_code||'',
            shippingCountry: addr.country||'',
            shippingPhone, items, totalMinor });
          await sendOrderEmail({ to, subject: 'Your FreakyFast Order Confirmation', html });
        }
      }catch(e){
        console.error('checkout.session.completed handling error', e);
      }
    }

    if (event.type === 'payment_intent.succeeded'){
      // Optional: could update order status here too
    }

    
    } else if (event.type === 'checkout.session.expired'){
      const session = event.data.object;
      try{
        const resv = await Reservation.findOne({ stripeSessionId: session.id, status:'held' });
        if (resv){
          for (const it of (resv.items||[])){
            await Product.updateOne({ slug: it.productSlug }, { $inc: { stock: it.quantity } });
          }
          await Reservation.updateOne({ _id: resv._id }, { $set: { status:'released' } });
        }
      }catch(e){ console.error('release on expired error', e); }

    return res.status(200).send('ok');
  }catch(e){
    console.error('webhook error', e);
    return res.status(500).send('error');
  }
});

export default router;
