const router = require('express').Router();
const multer = require('multer'); const path=require('path'); const fs=require('fs');
const upload = multer({ dest: path.join(__dirname,'..','uploads','media') });
router.post('/admin/media/upload', upload.single('file'), (req,res)=>{
  const f = req.file; if(!f) return res.status(400).json({ ok:false });
  const url = '/uploads/media/'+path.basename(f.path);
  res.json({ ok:true, url });
});
module.exports = router;
