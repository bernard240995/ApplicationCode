// backend/routes/pagesPublic.js
import express from 'express';
import CmsPage from '../models/CmsPage.js';

const router = express.Router();

// GET /api/pages/:slug  -> returns published page (for meta/client rendering)
router.get('/:slug', async (req, res) => {
  const item = await CmsPage.findOne({ slug: req.params.slug, status: 'published' }).lean();
  if (!item) return res.status(404).json({ ok:false, error: 'Not found' });
  res.json({ ok:true, item });
});

export default router;
