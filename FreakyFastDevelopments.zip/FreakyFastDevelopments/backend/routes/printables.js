// backend/routes/printables.js
import express from 'express';
import { renderInvoiceHTML, renderLabelHTML } from '../utils/printables.js';

const router = express.Router();

router.post('/invoice/html', async (req,res) => {
  const base = (req.protocol + '://' + req.get('host'));
  const html = await renderInvoiceHTML(req.body || {}, base);
  res.set('Content-Type','text/html').send(html);
});

router.post('/label/html', async (req,res) => {
  const base = (req.protocol + '://' + req.get('host'));
  const html = await renderLabelHTML(req.body || {}, base);
  res.set('Content-Type','text/html').send(html);
});

export default router;


router.post('/invoice/pdf', async (req,res) => {
  try{
    const base = (req.protocol + '://' + req.get('host'));
    const html = await renderInvoiceHTML(req.body || {}, base);
    const { default: puppeteer } = await import('puppeteer');
    const browser = await puppeteer.launch({ args: ['--no-sandbox','--disable-setuid-sandbox'] });
    const page = await browser.newPage();
    await page.setContent(html, { waitUntil:'load' });
    const pdf = await page.pdf({ format:'A4', printBackground:true, margin:{ top:'16mm', right:'12mm', bottom:'16mm', left:'12mm' } });
    await browser.close();
    res.set('Content-Type','application/pdf').send(pdf);
  }catch(e){
    res.status(501).json({ ok:false, error:'PDF not available (install puppeteer)' });
  }
});

router.post('/label/pdf', async (req,res) => {
  try{
    const base = (req.protocol + '://' + req.get('host'));
    const html = await renderLabelHTML(req.body || {}, base);
    const { default: puppeteer } = await import('puppeteer');
    const browser = await puppeteer.launch({ args: ['--no-sandbox','--disable-setuid-sandbox'] });
    const page = await browser.newPage();
    await page.setContent(html, { waitUntil:'load' });
    const pdf = await page.pdf({ width:'4in', height:'6in', printBackground:true });
    await browser.close();
    res.set('Content-Type','application/pdf').send(pdf);
  }catch(e){
    res.status(501).json({ ok:false, error:'PDF not available (install puppeteer)' });
  }
});
