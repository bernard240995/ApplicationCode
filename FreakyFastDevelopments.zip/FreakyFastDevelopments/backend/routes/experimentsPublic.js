// backend/routes/experimentsPublic.js
import express from 'express';
import HeroVariant from '../models/HeroVariant.js';

const router = express.Router();

router.get('/hero/:key', async (req,res) => {
  const items = await HeroVariant.find({ key: req.params.key, status: 'active' }).sort({ variant: 1 }).lean();
  res.json({ ok:true, items });
});

export default router;
