import express from "express";
import idempotency from "../../middleware/idempotency.js";
import { addEvent } from "../../services/outbox.js";
const router=express.Router();
router.use(idempotency());
router.post("/", async (req,res)=>{ const email=String(req.body?.email||"guest@example.com"); await addEvent("email", { to: email, subject: "Order received", html: "<b>Thanks!</b>" }); res.json({ ok:true, message:"queued" }); });
export default router;
