
import express from "express";
const router = express.Router();

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email||"").toLowerCase());
}

// In-memory fallback store (could be swapped to DB later)
const subs = [];

router.post("/subscribe", async (req, res) => {
  try {
    const { email } = req.body || {};
    if (!isValidEmail(email)) return res.status(400).json({ error: "Invalid email address" });
    subs.push({ email, at: new Date().toISOString() });
    // If you want Mailchimp/Sendgrid integration later, plug it here.
    return res.status(202).json({ ok: true });
  } catch (e) {
    return res.status(500).json({ error: "Subscription failed" });
  }
});

export default router;
