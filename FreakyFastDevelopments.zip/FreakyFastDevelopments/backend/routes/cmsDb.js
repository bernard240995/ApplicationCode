
import express from "express";
import FooterContent from "../models/FooterContent.js";
import FooterContentRevision from "../models/FooterContentRevision.js";
import fs from "fs";
import path from "path";

const router = express.Router();

// Public read - returns latest active footer content; falls back to file on first run.
router.get("/footer", async (req,res) => {
  try {
    const latest = await FooterContent.findOne({}).sort({ version: -1 }).lean();
    if (latest) return res.json(latest.data);
    // Fallback to file if DB hasn't been seeded yet
    const filePath = process.env.CMS_DIR ? path.join(process.cwd(), process.env.CMS_DIR, "footer.json") : path.join(process.cwd(), "src", "config", "footer.json");
    if (fs.existsSync(filePath)) {
      const raw = fs.readFileSync(filePath, "utf-8");
      return res.json(JSON.parse(raw));
    }
    return res.json({ columns: [], bottom: "" });
  } catch(e){
    console.error(e); res.status(500).json({ error: "CMS read error" });
  }
});

// Admin write - creates new version and revision entry
router.put("/admin/footer", async (req,res) => {
  try {
    const data = req.body;
    if (!data || typeof data !== "object") return res.status(400).json({ error: "Invalid footer payload" });

    const latest = await FooterContent.findOne({}).sort({ version: -1 });
    const nextVersion = (latest?.version || 0) + 1;

    const entry = new FooterContent({
      data,
      version: nextVersion,
      updatedBy: req.user?._id
    });
    await entry.save();

    const rev = new FooterContentRevision({
      data,
      version: nextVersion,
      updatedBy: req.user?._id,
      footerId: entry._id
    });
    await rev.save();

    res.json({ ok: true, version: nextVersion, id: entry._id });
  } catch(e){
    console.error(e); res.status(500).json({ error: "CMS write error" });
  }
});

// Admin list revisions
router.get("/admin/footer/revisions", async (req,res) => {
  try {
    const revs = await FooterContentRevision.find({}).sort({ createdAt: -1 }).limit(100).lean();
    res.json({ items: revs });
  } catch(e){
    console.error(e); res.status(500).json({ error: "CMS list error" });
  }
});

// Admin revert to a specific version
router.post("/admin/footer/revert", async (req,res) => {
  try {
    const { version } = req.body;
    if (!version) return res.status(400).json({ error: "Missing version" });

    const rev = await FooterContentRevision.findOne({ version });
    if (!rev) return res.status(404).json({ error: "Version not found" });

    const latest = await FooterContent.findOne({}).sort({ version: -1 });
    const nextVersion = (latest?.version || 0) + 1;

    const entry = new FooterContent({
      data: rev.data,
      version: nextVersion,
      updatedBy: req.user?._id
    });
    await entry.save();

    const newRev = new FooterContentRevision({
      data: rev.data,
      version: nextVersion,
      updatedBy: req.user?._id,
      footerId: entry._id
    });
    await newRev.save();

    res.json({ ok: true, version: nextVersion });
  } catch(e){
    console.error(e); res.status(500).json({ error: "CMS revert error" });
  }
});

export default router;
