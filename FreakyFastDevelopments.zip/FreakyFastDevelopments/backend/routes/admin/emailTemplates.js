import express from "express";
import fs from "fs";
import path from "path";
import EmailTemplateRevision from "../../models/EmailTemplateRevision.js";

const router = express.Router();
const dir = path.join(process.cwd(), "templates", "emails", "brand");

function requireAdmin(req,res,next){
  if (process.env.ADMIN_BYPASS_ROLE === "1") return next();
  const role = req.user?.role;
  if (role !== "superadmin") return res.status(403).json({ error: "Admin only" });
  next();
}

router.get("/", requireAdmin, (req,res)=>{
  try{
    fs.mkdirSync(dir, { recursive: true });
    const files = fs.readdirSync(dir).filter(f => f.endsWith(".mjml") || f.endsWith(".html"));
    res.json({ ok: true, files });
  }catch(e){ res.status(500).json({ error: e?.message }); }
});

router.get("/:name", requireAdmin, (req,res)=>{
  try{
    fs.mkdirSync(dir, { recursive: true });
    const name = req.params.name;
    const fp = path.join(dir, name);
    if (!fs.existsSync(fp)) return res.status(404).json({ error: "Not found" });
    const content = fs.readFileSync(fp, "utf-8");
    res.json({ ok: true, name, content });
  }catch(e){ res.status(500).json({ error: e?.message }); }
});

router.put("/:name", requireAdmin, async (req,res)=>{
  try{
    fs.mkdirSync(dir, { recursive: true });
    const name = req.params.name;
    const fp = path.join(dir, name);
    const content = req.body?.content || "";
    fs.writeFileSync(fp, content);
    await EmailTemplateRevision.create({ name, content, author: req.user?.email || "admin" });
    res.json({ ok: true });
  }catch(e){ res.status(500).json({ error: e?.message }); }
});

router.get("/:name/revisions", requireAdmin, async (req,res)=>{
  const name = req.params.name;
  const items = await EmailTemplateRevision.find({ name }).sort({ createdAt: -1 }).limit(20).lean();
  res.json({ ok: true, items });
});

export default router;
