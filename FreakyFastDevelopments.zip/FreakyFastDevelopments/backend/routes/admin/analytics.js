import express from "express";
import Order from "../../models/Order.js";
const router = express.Router();
import { requirePerm } from "../../policies/rbac.js";
router.use(requirePerm("analytics","read"));

function requireAdmin(req,res,next){
  if (process.env.ADMIN_BYPASS_ROLE === "1") return next();
  const role = req.user?.role;
  if (role !== "superadmin") return res.status(403).json({ error: "Admin only" });
  next();
}

router.get("/revenue/daily", requireAdmin, async (req,res)=>{
  const from = new Date(req.query.from || Date.now() - 30*864e5);
  const to = new Date(req.query.to || Date.now());
  const agg = await Order.aggregate([
    { $match: { createdAt: { $gte: from, $lte: to }, status: { $in: ["paid","refunded"] } } },
    { $group: { _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } }, gross: { $sum: "$amountTotal" }, count: { $sum: 1 } } },
    { $sort: { _id: 1 } }
  ]);
  res.json({ ok: true, items: agg });
});

router.get("/revenue/by-product", requireAdmin, async (req,res)=>{
  const from = new Date(req.query.from || Date.now() - 30*864e5);
  const to = new Date(req.query.to || Date.now());
  const agg = await Order.aggregate([
    { $match: { createdAt: { $gte: from, $lte: to }, status: { $in: ["paid","refunded"] } } },
    { $unwind: { path: "$items", preserveNullAndEmptyArrays: false } },
    { $group: { _id: "$items.name", qty: { $sum: { $ifNull: ["$items.qty", 1] } }, sales: { $sum: { $multiply: [ { $ifNull: ["$items.price", 0] }, { $ifNull: ["$items.qty", 1] } ] } } } },
    { $sort: { sales: -1 } },
    { $limit: 20 }
  ]);
  res.json({ ok: true, items: agg });
});

router.get("/rfm", requireAdmin, async (req,res)=>{
  const now = new Date();
  const agg = await Order.aggregate([
    { $match: { status: { $in: ["paid","refunded"] } } },
    { $group: { _id: "$email", last: { $max: "$createdAt" }, freq: { $sum: 1 }, monetary: { $sum: "$amountTotal" } } }
  ]);
  const items = agg.map(a => ({
    email: a._id, recencyDays: Math.round((now - a.last)/864e5), frequency: a.freq, monetary: a.monetary/100
  }));
  res.json({ ok: true, items });
});

export default router;
