import express from "express";
import EmailEvent from "../../models/EmailEvent.js";
import client from "prom-client";
const router = express.Router();
import { requirePerm } from "../../policies/rbac.js";
router.use(requirePerm("emails","read"));
const EMAIL_FAIL = new client.Counter({ name: "email_send_failures_total", help: "Email send failures" });
const EMAIL_SENT = new client.Counter({ name: "email_send_total", help: "Email sent total" });
function requireAdmin(req,res,next){ if (process.env.ADMIN_BYPASS_ROLE === "1") return next(); const role = req.user?.role; if (role !== "superadmin") return res.status(403).json({ error: "Admin only" }); next(); }
router.get("/", requireAdmin, async (req,res)=>{
  const { q, page=1, limit=50 } = req.query;
  const f = {}; if (q) f.$or = [ { to: { $regex: String(q), $options: "i" } }, { subject: { $regex: String(q), $options: "i" } } ];
  const p = Math.max(1, parseInt(page,10)||1); const l = Math.min(100, Math.max(1, parseInt(limit,10)||50));
  const total = await EmailEvent.countDocuments(f);
  const items = await EmailEvent.find(f).sort({ createdAt: -1 }).skip((p-1)*l).limit(l).lean();
  res.json({ ok: true, total, page: p, limit: l, items });
});
export default router;
