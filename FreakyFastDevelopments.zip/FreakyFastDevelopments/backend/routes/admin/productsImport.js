import express from "express";
import Product from "../../models/Product.js";
import multer from "multer";
const upload = multer();

const router = express.Router();
import { requirePerm } from "../../policies/rbac.js";
router.use(requirePerm("products","import"));

function requireAdmin(req,res,next){
  if (process.env.ADMIN_BYPASS_ROLE === "1") return next();
  const role = req.user?.role;
  if (role !== "superadmin") return res.status(403).json({ error: "Admin only" });
  next();
}

function parseCSV(text){
  const lines = text.split(/\r?\n/).filter(Boolean);
  const header = lines.shift().split(",").map(s=>s.trim());
  return lines.map(line => {
    const cols = line.split(",").map(s=>s.trim());
    const obj = {};
    header.forEach((h,i)=> obj[h] = cols[i] || "");
    return obj;
  });
}

router.post("/csv", requireAdmin, upload.single("file"), async (req,res)=>{
  try{
    const text = req.file?.buffer?.toString("utf-8") || "";
    const rows = parseCSV(text);
    let created=0, updated=0;
    for (const r of rows){
      const doc = await Product.findOneAndUpdate(
        { slug: r.slug || undefined, name: r.name },
        { $set: { description: r.description, price: Number(r.price||0), currency: r.currency||"gbp", imageUrl: r.imageUrl, active: r.active!=="false" } },
        { new: true, upsert: true }
      );
      if (doc.createdAt.getTime() === doc.updatedAt.getTime()) created++; else updated++;
    }
    res.json({ ok: true, created, updated });
  }catch(e){ res.status(400).json({ error: e?.message }); }
});

export default router;
