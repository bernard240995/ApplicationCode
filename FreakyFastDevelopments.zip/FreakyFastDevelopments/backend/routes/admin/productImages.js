import express from "express";
import multer from "multer";
import Product from "../../models/Product.js";
import { ingestProductImage } from "../../services/mediaPipeline.js";
import { requirePerm } from "../../policies/rbac.js";
const upload = multer(); const router = express.Router();
router.use(requirePerm("products","import"));
router.post("/", upload.single("file"), async (req,res)=>{
  const slug=String(req.body?.slug||""); if(!slug||!req.file) return res.status(400).json({ error:"slug and file required" });
  const bucket=process.env.MEDIA_BUCKET || process.env.INVOICE_BUCKET; if(!bucket) return res.status(400).json({ error:"MEDIA_BUCKET not set" });
  const keyBase=`products/${slug}/${Date.now()}`; const out=await ingestProductImage({ bucket, keyBase, body:req.file.buffer });
  const pref=out.find(o=>o.key.endsWith("512.webp")) || out[0];
  const doc=await Product.findOneAndUpdate({ slug }, { $set:{ imageUrl:`s3://${bucket}/${pref.key}` } }, { new:true, upsert:true });
  res.json({ ok:true, uploaded:out, product:{ id:doc._id, slug:doc.slug, imageUrl:doc.imageUrl } });
});
export default router;
