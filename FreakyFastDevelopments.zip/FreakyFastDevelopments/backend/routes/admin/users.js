import express from "express";
import User from "../../models/User.js";
import { requirePerm } from "../../policies/rbac.js";
const router = express.Router();
router.use(requirePerm("users","manage"));

router.get("/", async (req,res)=>{
  const users = await User.find().select("email role createdAt updatedAt mfa.enabled").limit(200).lean();
  res.json({ ok: true, users });
});

router.post("/:email/role", async (req,res)=>{
  const email = String(req.params.email);
  const role = String(req.body?.role||"user");
  const u = await User.findOneAndUpdate({ email }, { $set: { role } }, { new: true, upsert: true });
  res.json({ ok: true, user: { email: u.email, role: u.role } });
});

export default router;
