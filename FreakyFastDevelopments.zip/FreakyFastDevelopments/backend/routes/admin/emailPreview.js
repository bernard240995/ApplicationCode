import express from "express";
import { renderTemplate } from "../../services/emailTemplates.js";
import { renderMjml } from "../../services/mjmlRenderer.js";

const router = express.Router();

function sampleData(){
  return {
    customer: { name: "Alex" },
    order: { id: "ORD-12345", total: "199.00", url: "https://example.com/account/orders/ORD-12345" },
    reset: { url: "https://example.com/reset?token=abc" },
    tracking: { id: "TRACK123", url: "https://tracking.example.com/TRACK123" },
    year: new Date().getFullYear()
  };
}

router.get("/", (req,res)=>{
  try{
    const name = String(req.query.template || "brand/order_confirmation.mjml");
    const data = req.query.data ? JSON.parse(req.query.data) : sampleData();
    let html;
    if (name.endsWith(".mjml")){
      const mj = renderTemplate(name, data);
      html = renderMjml(mj) || mj;
    } else {
      html = renderTemplate(name, data);
    }
    res.type("text/html").send(html);
  }catch(e){
    res.status(500).send("<h1>Render failed</h1><pre>"+(e?.message||"")+"</pre>");
  }
});

export default router;
