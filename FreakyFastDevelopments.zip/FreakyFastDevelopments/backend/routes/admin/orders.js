import express from "express";
import Order from "../../models/Order.js";
import Stripe from "stripe";
import { signedUrl } from "../../services/s3.js";
import { emailQueue } from "../../queues/emailQueue.js";

const router = express.Router();

function requireAdmin(req,res,next){
  if (process.env.ADMIN_BYPASS_ROLE === "1") return next();
  const role = req.user?.role;
  if (role !== "superadmin") return res.status(403).json({ error: "Admin only" });
  next();
}

router.get("/", requireAdmin, async (req,res)=>{
  const { status, q, page=1, limit=20 } = req.query;
  const filter = {};
  if (status) filter.status = status;
  if (q){
    filter.$or = [
      { email: { $regex: String(q), $options: "i" } },
      { providerId: { $regex: String(q), $options: "i" } }
    ];
  }
  const p = Math.max(1, parseInt(page,10)||1);
  const l = Math.min(100, Math.max(1, parseInt(limit,10)||20));
  const total = await Order.countDocuments(filter);
  const items = await Order.find(filter).sort({ createdAt: -1 }).skip((p-1)*l).limit(l).lean();
  res.json({ ok: true, total, page: p, limit: l, items });
});

router.get("/:id", requireAdmin, async (req,res)=>{
  const doc = await Order.findById(req.params.id).lean();
  if (!doc) return res.status(404).json({ error: "Not found" });
  res.json({ ok: true, doc });
});

router.post("/:id/refund", requireAdmin, async (req,res)=>{
  try{
    const doc = await Order.findById(req.params.id);
    if (!doc) return res.status(404).json({ error: "Not found" });
    if (doc.provider !== "stripe") return res.status(400).json({ error: "Only Stripe refunds supported here" });
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", { apiVersion: "2022-11-15" });
    const amountMinor = req.body?.amount ? Math.round(Number(req.body.amount) * 100) : undefined;
    const params = doc.paymentIntentId ? { payment_intent: doc.paymentIntentId } : (doc.chargeId ? { charge: doc.chargeId } : null);
    if (!params) return res.status(400).json({ error: "Missing payment intent/charge" });
    if (amountMinor) params.amount = amountMinor;
    const r = await stripe.refunds.create(params);
    doc.status = "refunded";
    await doc.save();
    try{ const url = (doc.invoiceS3Key && process.env.INVOICE_BUCKET) ? await signedUrl({ bucket: process.env.INVOICE_BUCKET, key: doc.invoiceS3Key, expiresIn: Number(process.env.INVOICE_URL_TTL||604800) }) : (process.env.FRONTEND_ORIGIN||"") + "/account/orders/" + doc._id; await emailQueue.add("invoice-refunded", { to: doc.email, subject: `Refund processed for order ${doc._id}`, template: "brand/invoice_refunded.mjml", data: { order: { id: doc._id.toString() }, invoice: { url }, year: new Date().getFullYear() } }); }catch(_){ }
    res.json({ ok: true, refund: r });
  }catch(e){
    res.status(500).json({ error: "Refund failed", detail: e?.message });
  }
});

export default router;
