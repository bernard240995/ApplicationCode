import express from "express";
import AuditLog from "../../models/AuditLog.js";
import { requirePerm } from "../../policies/rbac.js";
const router = express.Router();
router.use(requirePerm("audit","read"));

router.get("/", async (req,res)=>{
  const items = await AuditLog.find().sort({ ts: -1 }).limit(200).lean();
  res.json({ ok: true, items });
});

export default router;
