import express from "express";
import Product from "../../models/Product.js";
import { requirePerm } from "../../policies/rbac.js";
const router = express.Router();
router.use(requirePerm("products","read"));

router.get("/", async (req,res)=>{
  const items = await Product.find().sort({ createdAt: -1 }).limit(200).lean();
  res.json({ ok: true, items });
});

router.post("/", requirePerm("products","import"), async (req,res)=>{
  const { name, slug, description, price, currency, imageUrl, active } = req.body || {};
  const doc = await Product.create({ name, slug, description, price, currency, imageUrl, active });
  res.json({ ok: true, item: doc });
});

router.put("/:id", requirePerm("products","import"), async (req,res)=>{
  const { id } = req.params;
  const doc = await Product.findByIdAndUpdate(id, { $set: req.body||{} }, { new: true });
  res.json({ ok: true, item: doc });
});

router.delete("/:id", requirePerm("products","import"), async (req,res)=>{
  const { id } = req.params;
  await Product.findByIdAndDelete(id);
  res.json({ ok: true });
});

export default router;
