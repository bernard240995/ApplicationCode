import { makeTrackingUrl } from '../utils/carriers.js';
// backend/routes/adminOrders.js
import express from 'express';
import Order from '../models/Order.js';
import OrderEvent from '../models/OrderEvent.js';
let adminGuard = (req,res,next)=>next();
try { ({ adminGuard } = await import('../utils/authGuards.js')); } catch {}

const router = express.Router();

router.get('/', adminGuard, async (req,res)=>{
  const rows = await Order.find().sort({ createdAt:-1 }).limit(100);
  res.json({ ok:true, items: rows });
});

export default router;


router.patch('/:id/status', adminGuard, async (req,res)=>{
  const { status='paid' } = req.body || {};
  const o = await Order.findByIdAndUpdate(req.params.id, { status }, { new:true });
  try{ await OrderEvent.create({ orderId: o.orderId || o._id, type: status, message: 'Status changed', actor: (req.user && (req.user.email||req.user._id)) || '' }); }catch{}
  try{
    if (o?.email){
      const { createTransport, renderOrderEmail } = await import('../utils/email.js');
      const transporter = await createTransport();
      const html = await renderOrderEmail({ id: o.orderId, email: o.email, name:o.name, address:o.address, total: (o.amount/100).toLocaleString('en-GB',{style:'currency',currency:(o.currency||'gbp').toUpperCase()}), items: [] });
      await transporter.sendMail({
        from: `"FreakyFast" <${process.env.SMTP_USER || "orders@localhost"}>`,
        to: o.email,
        subject: `Your order ${o.orderId} status: ${status}`,
        html
      });
    }
  }catch{}
  res.json({ ok:true, item:o });
});


router.get('/:id/events', adminGuard, async (req,res)=>{
  const o = await Order.findById(req.params.id);
  if (!o) return res.status(404).json({ ok:false });
  const items = await OrderEvent.find({ orderId: o.orderId || o._id }).sort({ createdAt:1 });
  res.json({ ok:true, items });
});

router.post('/:id/note', adminGuard, async (req,res)=>{
  const o = await Order.findById(req.params.id);
  if (!o) return res.status(404).json({ ok:false });
  const { message='' } = req.body || {};
  const ev = await OrderEvent.create({ orderId: o.orderId || o._id, type: 'note', message, actor: (req.user && (req.user.email||req.user._id)) || '' });
  res.json({ ok:true, item:ev });
});


router.patch('/:id/tracking', adminGuard, async (req,res)=>{
  const { carrier='', trackingNumber='', trackingUrl='' } = req.body || {};
  const o = await Order.findByIdAndUpdate(req.params.id, { carrier, trackingNumber, trackingUrl, shippedAt: new Date(), status: 'shipped' }, { new: true });
  try{
    const { createTransport } = await import('../utils/email.js');
    const { default: OrderEvent } = await import('../models/OrderEvent.js');
    await OrderEvent.create({ orderId: o.orderId || o._id, type: 'shipped', message: `Tracking ${carrier} ${trackingNumber}`, actor: (req.user && (req.user.email||req.user._id)) || '' });
    if (o?.email){
      const { renderShipmentEmail } = await import('../utils/email.js');
      const transporter = await createTransport();
      const html = await renderShipmentEmail({ id:o.orderId, name:o.name, email:o.email, carrier, trackingNumber, trackingUrl });
      await transporter.sendMail({
        from: `"FreakyFast" <${process.env.SMTP_USER || "orders@localhost"}>`,
        to: o.email,
        subject: `Your order ${o.orderId} has shipped`,
        html
      });
    }
  }catch{}
  res.json({ ok:true, item:o });
});


router.patch('/:id/delivered', adminGuard, async (req,res)=>{
  const o = await Order.findByIdAndUpdate(req.params.id, { status:'delivered', deliveredAt: new Date() }, { new:true });
  try{
    const { createTransport } = await import('../utils/email.js');
    const { default: OrderEvent } = await import('../models/OrderEvent.js');
    await OrderEvent.create({ orderId: o.orderId || o._id, type: 'delivered', message: 'Marked delivered', actor: (req.user && (req.user.email||req.user._id)) || '' });
    if (o?.email){
      const { renderDeliveredEmail } = await import('../utils/email.js');
      const transporter = await createTransport();
      const html = await renderDeliveredEmail({ id:o.orderId, name:o.name });
      await transporter.sendMail({
        from: `"FreakyFast" <${process.env.SMTP_USER || "orders@localhost"}>`,
        to: o.email,
        subject: `Order ${o.orderId} delivered`,
        html
      });
    }
  }catch{}
  res.json({ ok:true, item:o });
});
