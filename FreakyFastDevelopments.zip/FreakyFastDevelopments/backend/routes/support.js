
// backend/routes/support.js
import express from 'express';
import SupportTicket from '../models/SupportTicket.js';
let adminGuard = (req,res,next)=>next();
try { ({ adminGuard } = await import('../utils/authGuards.js')); } catch {}

const router = express.Router();

router.post('/tickets', async (req,res)=>{
  const b = req.body || {};
  const ticket = await SupportTicket.create({
    name: b.name||'',
    email: b.email||'',
    phone: b.phone||'',
    message: b.message||''
  });
  res.json({ ok:true, ticket });
});

router.get('/tickets', adminGuard, async (req,res)=>{
  const items = await SupportTicket.find().sort({ createdAt:-1 }).limit(500).lean();
  res.json({ ok:true, items });
});

export default router;
