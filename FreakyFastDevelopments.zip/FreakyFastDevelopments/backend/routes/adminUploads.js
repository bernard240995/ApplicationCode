import express from "express";
import path from "path";
import fs from "fs";
import multer from "multer";
import sharp from "sharp";
import { parse } from "csv-parse/sync";
import Product from "../models/Product.js"; // ensure this model exists

const router = express.Router();

const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(process.cwd(), "uploads");
const FILE_BASE_URL = process.env.FILE_BASE_URL || "http://localhost:5000";

fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename: (_req, file, cb) => {
    const ts = Date.now();
    const ext = path.extname(file.originalname) || ".bin";
    cb(null, `img_${ts}${ext}`);
  }
});
const upload = multer({ storage });

router.post("/image", upload.single("image"), async (req, res) => {
  try{
    const file = req.file;
    if (!file) return res.status(400).json({ error: "No file" });

    const base = path.basename(file.filename, path.extname(file.filename));
    const thumbPath = path.join(UPLOAD_DIR, `${base}_thumb.webp`);
    await sharp(file.path).resize(480).webp({ quality: 80 }).toFile(thumbPath);

    const url = `${FILE_BASE_URL}/uploads/${file.filename}`;
    const thumbUrl = `${FILE_BASE_URL}/uploads/${path.basename(thumbPath)}`;
    res.json({ url, thumbUrl });
  }catch(e){
    console.error(e);
    res.status(500).json({ error: "Upload error" });
  }
});

router.post("/products/csv", upload.single("file"), async (req, res) => {
  try{
    if (!req.file) return res.status(400).json({ error: "No file" });
    const text = fs.readFileSync(req.file.path, "utf-8");
    const rows = parse(text, { columns: true, skip_empty_lines: true });
    let created = 0;
    for (const r of rows){
      const doc = new Product({
        name: r.name,
        description: r.description,
        price: Number(r.price_pence || 0),
        category: r.category || "general",
        imageUrl: r.imageUrl || "",
        stock: Number(r.stock || 0),
        sku: r.sku || undefined
      });
      await doc.save();
      created++;
    }
    res.json({ created });
  }catch(e){
    console.error(e);
    res.status(500).json({ error: "CSV import error" });
  }
});

export default router;
