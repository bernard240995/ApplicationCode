// backend/routes/adminReviews.js
import express from 'express';
import Review from '../models/Review.js';
let { adminGuard } = await import('../utils/authGuards.js').catch(()=>({ adminGuard:(req,res,next)=>next() }));
const router = express.Router();

router.get('/', adminGuard, async (req,res)=>{
  res.json({ ok:true, items: await Review.find().sort({createdAt:-1}).lean() });
});
router.patch('/:id', adminGuard, async (req,res)=>{
  res.json({ ok:true, item: await Review.findByIdAndUpdate(req.params.id, req.body||{}, {new:true}) });
});
export default router;
