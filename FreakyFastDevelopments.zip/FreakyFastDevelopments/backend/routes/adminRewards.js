// backend/routes/adminRewards.js
import express from 'express';
import RewardPoint from '../models/RewardPoint.js';
let { adminGuard } = await import('../utils/authGuards.js').catch(()=>({ adminGuard:(req,res,next)=>next() }));
const router = express.Router();

router.get('/', adminGuard, async (req,res)=>{
  res.json({ ok:true, items: await RewardPoint.find().sort({createdAt:-1}).lean() });
});
router.post('/', adminGuard, async (req,res)=>{
  res.json({ ok:true, item: await RewardPoint.create(req.body||{}) });
});
export default router;
