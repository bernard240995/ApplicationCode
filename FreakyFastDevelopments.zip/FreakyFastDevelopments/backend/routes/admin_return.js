const r=require('express').Router();
const Model=require('../models/Return');
r.get('/admin/returns', async(_q,res)=>res.json({{items:await Model.find({{}}).limit(50).lean()}}));
r.post('/admin/return', async(req,res)=>res.json({{ok:true, item:await Model.create(req.body||{{}})}}));
r.put('/admin/return/:id', async(req,res)=>res.json({{ok:true, item:await Model.findByIdAndUpdate(req.params.id,{{$set:req.body||{{}}}},{{new:true}})}}));
r.delete('/admin/return/:id', async(req,res)=>{{ await Model.findByIdAndDelete(req.params.id); res.json({{ok:true}}) }});
module.exports=r;
