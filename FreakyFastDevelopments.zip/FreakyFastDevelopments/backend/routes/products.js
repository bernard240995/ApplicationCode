import express from "express";
import Product from "../models/Product.js";
import { cacheGet, cacheSet } from "../services/redis.js";
const router = express.Router();

router.get("/", async (req,res)=>{
  const key = "products:list";
  const cached = await cacheGet(key);
  if (cached) return res.json(JSON.parse(cached));
  const items = await Product.find({ active: true }).sort({ createdAt: -1 }).limit(100).lean();
  const payload = { ok: true, items };
  await cacheSet(key, JSON.stringify(payload), 60);
  res.json(payload);
});

export default router;
