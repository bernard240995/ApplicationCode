
import express from "express";
import Coupon from "../models/Coupon.js";
const router = express.Router();
// Middleware placeholder: ensureAdmin
const ensureAdmin = (req,res,next)=> next(); // replace with your real admin guard

router.get("/", ensureAdmin, async (req,res)=>{
  const { q="", page=1, limit=20, sort="createdAt:desc" } = req.query;
  const [sortField, sortDir] = String(sort).split(":");
  const s = {};
  if (q) {
    s.$or = [
      { code: new RegExp(q, "i") },
      { description: new RegExp(q, "i") }
    ];
  }
  const skip = (Math.max(1, parseInt(page))-1) * Math.max(1, parseInt(limit));
  const cursor = Coupon.find(s).sort({ [sortField || "createdAt"]: (sortDir==="asc"?1:-1) }).skip(skip).limit(Math.max(1, parseInt(limit)));
  const [items, total] = await Promise.all([cursor, Coupon.countDocuments(s)]);
  res.json({ items, total, page: Number(page), limit: Number(limit) });
});

router.get("/:id", ensureAdmin, async (req,res)=>{
  const c = await Coupon.findById(req.params.id);
  if (!c) return res.status(404).json({ error: "Not found" });
  res.json(c);
});

router.post("/", ensureAdmin, async (req,res)=>{
  const body = req.body || {};
  try {
    const c = await Coupon.create(body);
    res.status(201).json(c);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

router.put("/:id", ensureAdmin, async (req,res)=>{
  try {
    const c = await Coupon.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!c) return res.status(404).json({ error: "Not found" });
    res.json(c);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

router.delete("/:id", ensureAdmin, async (req,res)=>{
  await Coupon.findByIdAndDelete(req.params.id);
  res.json({ ok: true });
});

export default router;
