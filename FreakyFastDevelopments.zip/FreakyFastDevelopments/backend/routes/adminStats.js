// backend/routes/adminStats.js
import express from 'express';
import mongoose from 'mongoose';
import ABEvent from '../models/ABEvent.js';
import Ticket from '../models/Ticket.js';

let adminGuard = (req,res,next)=>next();
try { ({ adminGuard } = await import('../utils/authGuards.js')); } catch {}

const router = express.Router();

router.get('/summary', adminGuard, async (_req, res) => {
  const [abAgg, ticketCounts] = await Promise.all([
    ABEvent.aggregate([
      { $group: { _id: { exp: '$exp', var: '$var', type: '$type' }, count: { $sum: 1 } } },
      { $sort: { '_id.exp': 1, '_id.var': 1, '_id.type': 1 } }
    ]),
    Ticket.aggregate([{ $group: { _id: '$status', count: { $sum: 1 } } }])
  ]).catch(()=>[[],[]]);

  const ab = {};
  for (const row of abAgg) {
    const { exp, var:variant, type } = row._id || {};
    if (!ab[exp]) ab[exp] = {};
    if (!ab[exp][variant]) ab[exp][variant] = { impressions: 0, clicks: 0 };
    if (type === 'impression') ab[exp][variant].impressions = row.count;
    if (type === 'click') ab[exp][variant].clicks = row.count;
  }

  const tickets = Object.fromEntries(ticketCounts.map(t => [t._id, t.count]));

  res.json({ ok:true, ab, tickets });
});

export default router;
