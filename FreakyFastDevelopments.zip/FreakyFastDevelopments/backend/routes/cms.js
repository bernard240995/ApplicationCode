import express from "express";
import fs from "fs";
import path from "path";
import crypto from "crypto";
import FooterContent from "../models/FooterContent.js";
import FooterContentRevision from "../models/FooterContentRevision.js";
import { requireAnyRole, requireRole } from "../middleware/roles.js";
import { notifySlack } from "../services/alerting.js";

const router = express.Router();
const __dirname = path.resolve();

// Helpers
function getPreviewSecret(){ return process.env.CMS_PREVIEW_SECRET || "dev-preview-secret"; }
function signPreview(exp){ return crypto.createHmac("sha256", getPreviewSecret()).update(`footer-preview|${exp}`).digest("hex"); }
function verifyPreview(token, exp){
  if (!exp || !token) return false;
  const now = Math.floor(Date.now()/1000);
  if (Number(exp) < now) return false;
  const expect = signPreview(exp);
  return expect === token;
}

// PUBLIC read
router.get("/footer", async (req, res) => {
  const preview = String(req.query.preview || "0") === "1";
  const token = req.headers["x-preview-token"] || req.query.token;
  const exp = req.query.exp;
  let doc;
  if (preview && ((token && token.length > 0 && req.headers["x-preview-token"]) || verifyPreview(token, exp))) {
    doc = await FooterContent.findOne({}).sort({ createdAt: -1 }).lean(); // latest (draft/approved)
  } else {
    doc = await FooterContent.findOne({ published: true }).sort({ createdAt: -1 }).lean();
  }
  if (doc) return res.json({ ok: true, data: doc.data, published: !!doc.published, status: doc.status });

  // fallback to file json if db empty
  try {
    const cfgPath = process.env.CMS_DIR ? path.join(__dirname, process.env.CMS_DIR, "footer.json") : path.join(__dirname, "config", "footer.json");
    const data = JSON.parse(fs.readFileSync(cfgPath, "utf-8"));
    return res.json({ ok: true, data, published: true, status: "published", fallback: true });
  } catch {
    return res.json({ ok: true, data: { columns: [], bottom: "" }, published: false, status: "draft", fallback: true });
  }
});

// Save draft || submit for review
router.put("/admin/footer", requireAnyRole(["editor","reviewer","superadmin"]), async (req, res) => {
  const { data, submit, note } = req.body || {};
  if (!data) return res.status(400).json({ error: "Missing data" });
  const status = submit ? "pending_review" : "draft";
  const doc = await FooterContent.create({ data, status, published: false, createdBy: req.user?._id || null, note: note || "" });
  await FooterContentRevision.create({ data, status, published: false, by: req.user?._id || null, note: note || "" });
  notifySlack(`CMS: draft ${submit ? 'submitted' : 'saved'} by ${req.user?.email||'unknown'}`, 'cms-submit');
  res.json({ ok: true, id: doc._id, status });
});

// List pending for reviewers/superadmins
router.get("/admin/footer/pending", requireAnyRole(["reviewer","superadmin"]), async (req, res) => {
  const items = await FooterContent.find({ status: { $in: ["pending_review","approved","scheduled"] } }).sort({ createdAt: -1 }).lean();
  res.json({ ok: true, items });
});

// Reviewer approves (moves to 'approved')
router.post("/admin/footer/approve", requireAnyRole(["reviewer","superadmin"]), async (req, res) => {
  const { id, note } = req.body || {};
  const doc = await FooterContent.findById(id);
  if (!doc) return res.status(404).json({ error: "Not found" });
  doc.status = "approved";
  doc.approvedBy = req.user?._id || null;
  doc.note = note || doc.note || "";
  await doc.save();
  await FooterContentRevision.create({ data: doc.data, status: "approved", published: false, by: req.user?._id || null, note: note || "" });
  notifySlack(`CMS: approved by ${req.user?.email||'unknown'}`, 'cms-approve');
  res.json({ ok: true });
});

// Reviewer/SuperAdmin rejects
router.post("/admin/footer/reject", requireAnyRole(["reviewer","superadmin"]), async (req, res) => {
  const { id, note } = req.body || {};
  const doc = await FooterContent.findById(id);
  if (!doc) return res.status(404).json({ error: "Not found" });
  doc.status = "rejected";
  doc.note = note || doc.note || "";
  await doc.save();
  await FooterContentRevision.create({ data: doc.data, status: "rejected", published: false, by: req.user?._id || null, note: note || "" });
  res.json({ ok: true });
});

// SuperAdmin publish now
router.post("/admin/footer/publish", requireRole("superadmin"), async (req, res) => {
  const { id } = req.body || {};
  const doc = id ? await FooterContent.findById(id) : await FooterContent.findOne({}).sort({ createdAt: -1 });
  if (!doc) return res.status(404).json({ error: "Not found" });
  await FooterContent.updateMany({}, { $set: { published: false, status: "draft" } });
  doc.published = true;
  doc.status = "published";
  doc.publishAt = null;
  await doc.save();
  await FooterContentRevision.create({ data: doc.data, status: "published", published: true, by: req.user?._id || null });
  notifySlack(`CMS: published by ${req.user?.email||'unknown'}`, 'cms-publish');
  res.json({ ok: true, id: doc._id, published: true });
});

// SuperAdmin schedule publish
router.post("/admin/footer/schedule", requireRole("superadmin"), async (req, res) => {
  const { id, publishAt } = req.body || {};
  if (!id || !publishAt) return res.status(400).json({ error: "Missing id || publishAt" });
  const when = new Date(publishAt);
  if (isNaN(when.getTime())) return res.status(400).json({ error: "Invalid date" });
  const doc = await FooterContent.findById(id);
  if (!doc) return res.status(404).json({ error: "Not found" });
  doc.status = "scheduled";
  doc.publishAt = when;
  await doc.save();
  await FooterContentRevision.create({ data: doc.data, status: "scheduled", published: false, by: req.user?._id || null });
  res.json({ ok: true });
});

// Diff between two revisions || content docs
router.get("/admin/footer/diff", requireAnyRole(["editor","reviewer","superadmin"]), async (req, res) => {
  const { a, b, typeA="content", typeB="content" } = req.query;
  if (!a || !b) {
      return res.status(400).json({ error: "Missing a || b" })
  let A=null, B=null;
  if (typeA === "revision") A = await FooterContentRevision.findById(a).lean();
  else A = await FooterContent.findById(a).lean();
  if (typeB === "revision") B = await FooterContentRevision.findById(b).lean();
  else B = await FooterContent.findById(b).lean();
  if (!A || !B) return res.status(404).json({ error: "Items !found" });
  const diff = buildDiff(A.data || {}, B.data || {});
  res.json({ ok: true, diff });
});

function buildDiff(a, b){
  // Simple recursive JSON diff
  if (typeof a !== "object" || typeof b !== "object" || !a || !b){
    if (JSON.stringify(a) === JSON.stringify(b)) return { type: "equal", a, b };
    return { type: "change", a, b };
  }
  const out = { type: "object", children: {} };
  const keys = new Set([...Object.keys(a), ...Object.keys(b)]);
  for (const k of keys){
    if (!(k in a)) out.children[k] = { type: "added", b: b[k] };
    else if (!(k in b)) out.children[k] = { type: "removed", a: a[k] };
    else out.children[k] = buildDiff(a[k], b[k]);
  }
  return out;
}

// Generate expiring preview link
router.get("/admin/footer/preview-link", requireAnyRole(["editor","reviewer","superadmin"]), async (req, res) => {
  const exp = Math.floor(Date.now()/1000) + 3600;
  const token = signPreview(exp);
  const siteLink = `/?ff_preview=1&ff_token=${token}&ff_exp=${exp}`;
  const apiLink = `/api/cms/footer?preview=1&token=${token}&exp=${exp}`;
  res.json({ ok: true, token, exp, siteLink, apiLink });
});

export default router;
