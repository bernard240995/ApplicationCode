import express from "express";
import Cart from "../models/Cart.js";
const router = express.Router();

router.put("/", async (req,res)=>{
  const { email, items } = req.body || {};
  if (!Array.isArray(items)) return res.status(400).json({ error: "items[] required" });
  const filter = { userId: req.user?._id || null, email: (email||"").toLowerCase() || undefined };
  const doc = await Cart.findOne(filter) || new Cart(filter);
  doc.items = items;
  doc.updatedAt = new Date();
  await doc.save();
  res.json({ ok: true });
});

export default router;
