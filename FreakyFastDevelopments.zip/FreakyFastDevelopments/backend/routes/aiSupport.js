// backend/routes/aiSupport.js
import express from 'express';
import Ticket from '../models/Ticket.js';

const router = express.Router();

router.post('/ai', async (req, res) => {
  const { message } = req.body;
  const lower = (message || '').toLowerCase();

  let reply = "Thanks for reaching out! I've logged your request for the team.";
  if (lower.includes('return')) reply = 'I can help with returns. What is your order number?';
  if (lower.includes('shipping')) reply = 'Shipping is UK-only with fast delivery. Need help tracking an order?';

  try {
    await Ticket.create({ subject: 'ChatBot Inquiry', message, status:'open', priority:'normal' });
  } catch {}

  res.json({ ok:true, reply });
});

export default router;
