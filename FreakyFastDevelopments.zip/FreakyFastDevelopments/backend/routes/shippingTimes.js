const router = require('express').Router();
/** Returns standard shipping times for common UK couriers */
router.get('/public/shipping-times', (_q,res)=>{
  res.json({
    couriers:[
      { name:'Royal Mail 2nd Class', eta_days:'2-3 working days' },
      { name:'Royal Mail Tracked 24', eta_days:'1 working day' },
      { name:'DPD Next Day', eta_days:'1 working day (by 12)' },
      { name:'Evri Standard', eta_days:'2-4 working days' },
      { name:'UPS Standard', eta_days:'1-2 working days' }
    ]
  })
})
module.exports = router;
