
import express from "express";
import axios from "axios";
const router = express.Router();

// Simple UK shipping rate rules with postcode validation
// Request: { items: [{qty, weight_g}], postcode, subtotal_pence }
// Response: { rates: [{id, label, amount_pence, eta}] }
router.post("/rates", async (req,res)=>{
  try{
    const { items = [], postcode = "", subtotal_pence = 0 } = req.body || {};
    const weight_g = items.reduce((a,b)=> a + Number(b.weight_g||0)*Number(b.qty||1), 0);
    // Validate UK postcode (best-effort) via postcodes.io
    let valid = false;
    try{
      const clean = String(postcode||"").replace(/\s+/g,"");
      const r = await axios.get(`https://api.postcodes.io/postcodes/${encodeURIComponent(clean)}`);
      valid = !!r.data?.result && r.data.result.country === "England" || r.data.result.country === "Scotland" || r.data.result.country === "Wales" || r.data.result.country === "Northern Ireland";
    }catch(_){ valid = true; } // if API fails, don't block

    if (!valid) return res.status(400).json({ error: "Invalid UK postcode" });

    const overThreshold = subtotal_pence >= 5000; // free standard over £50
    const standard = { id: "standard", label: `Standard${overThreshold?" (Free over £50)":""}`, amount_pence: overThreshold ? 0 : 0, eta: "2-4 business days" };
    // Weight tiers for express/next-day
    const tier = weight_g <= 1000 ? 1 : weight_g <= 5000 ? 2 : 3;
    const expressPrice = tier===1? 499 : tier===2? 799 : 1299;
    const nextDayPrice = tier===1? 999 : tier===2? 1499 : 1999;
    const express = { id: "express", label: "Express", amount_pence: expressPrice, eta: "1-2 business days" };
    const nextday = { id: "nextday", label: "Next‑Day", amount_pence: nextDayPrice, eta: "next business day" };
    res.json({ rates: [standard, express, nextday] });
  }catch(e){
    console.error("rates error", e);
    res.status(500).json({ error: "Could not calculate rates" });
  }
});

export default router;
