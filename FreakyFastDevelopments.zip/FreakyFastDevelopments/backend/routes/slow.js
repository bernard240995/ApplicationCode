import express from "express";
import { getRecentSlow } from "../services/mongoSlowLog.js";
const router = express.Router();

router.get("/", (req,res)=>{
  if (process.env.SLOW_DEBUG_SECRET && req.headers["x-slow-secret"] !== process.env.SLOW_DEBUG_SECRET){
    return res.status(403).json({ error: "Forbidden" });
  }
  res.json({ ok: true, items: getRecentSlow() });
});

export default router;
