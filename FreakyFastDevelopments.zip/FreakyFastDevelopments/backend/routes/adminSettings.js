const router = require('express').Router();
const Setting = require('../models/Setting');

router.get('/admin/settings', async (_q,res)=>{
  const keys = await Setting.find({}).lean();
  res.json({ items: keys });
});

router.post('/admin/settings', async (req,res)=>{
  const { key, value } = req.body||{}; if(!key) return res.status(400).json({ ok:false });
  const up = await Setting.findOneAndUpdate({ key }, { $set: { value } }, { new:true, upsert:true });
  res.json({ ok:true, item: up });
});

module.exports = router;
