import { notifySlack } from "../services/alerting.js";
import { Worker } from "bullmq";
import nodemailer from "nodemailer";
import EmailEvent from "../models/EmailEvent.js";
import { renderTemplate } from "../services/emailTemplates.js";
import { renderMjml } from "../services/mjmlRenderer.js";
import client from "prom-client";

const connection = { url: process.env.REDIS_URL || "redis://127.0.0.1:6379" };
const EMAILS_SENT = new client.Counter({ name: "emails_sent_total", help: "Total emails sent" });

function getTransport(){
  if (process.env.SMTP_HOST){
    return nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: process.env.SMTP_SECURE === "1",
      auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined
    });
  }
  return nodemailer.createTransport({ jsonTransport: true });
}

const worker = new Worker("email", async job => {
  const transporter = getTransport();
  let { to, subject, html, text, template, data, attachments } = job.data;
  if (template && !html) { if (template.endsWith(".mjml")) { const mjIn = renderTemplate(template, data || {}); const out = renderMjml(mjIn); html = out || mjIn; } else { html = renderTemplate(template, data || {}); } }
  const info = await transporter.sendMail({ from: process.env.MAIL_FROM || "noreply@freakyfast.example", to, subject, html, text, attachments });
  try { await EmailEvent.create({ to, subject, template, status: "sent", messageId: info?.messageId, meta: { provider: info?.envelope?.from } }); } catch(_) {}
  EMAILS_SENT.inc();
}, { connection });

worker.on("completed", () => {});
worker.on("failed", err => { console.error("Email job failed", err?.failedReason); notifySlack(`Email job failed: ${err?.failedReason||"unknown"}`, "email-worker-failed"); });
