import mongoose from "mongoose";
import { Queue } from "bullmq";
import Cart from "../models/Cart.js";

const connection = { url: process.env.REDIS_URL || "redis://127.0.0.1:6379" };
const emailQueue = new Queue("email", { connection });

const MONGO = process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/freakyfast";
await mongoose.connect(MONGO);

function ageHours(d){ return (Date.now() - new Date(d).getTime()) / 36e5; }

async function scan(){
  const carts = await Cart.find({ items: { $exists: true, $ne: [] } }).lean();
  for (const c of carts){
    const h = ageHours(c.updatedAt);
    let step = null;
    if (h >= 24 && !(c.remindersSent||[]).includes("24h")) step = "24h";
    else if (h >= 72 && !(c.remindersSent||[]).includes("3d")) step = "3d";
    else if (h >= 168 && !(c.remindersSent||[]).includes("7d")) step = "7d";
    if (!step || !c.email) continue;
    // enqueue
    await emailQueue.add("abandoned-cart", {
      to: c.email,
      subject: step==="24h" ? "Complete your order" : step==="3d" ? "We saved your cart" : "Last chance to save your cart",
      text: "You left items in your basket — come back to finish your order.",
      html: `<p>You left items in your basket — come back to finish your order.</p>`
    });
    // mark reminder sent
    await Cart.updateOne({ _id: c._id }, { $addToSet: { remindersSent: step } });
  }
}

setInterval(scan, 60 * 60 * 1000); // hourly
console.log("AbandonedCartWorker running (hourly scan)");
