import OutboxEvent from "../models/OutboxEvent.js";
import { emailQueue } from "../queues/emailQueue.js";
export default async function tickOutbox(){ const batch=await OutboxEvent.find({ status:"pending" }).limit(20); for (const ev of batch){ try{ if(ev.type==="email"){ await emailQueue.add("generic", ev.payload); } await OutboxEvent.findByIdAndUpdate(ev._id,{ $set:{ status:"processed" } }); }catch(e){ await OutboxEvent.findByIdAndUpdate(ev._id,{ $inc:{ attempts:1 }, $set:{ status:"failed" } }); } } }
