const roles = {
  user: { allows: [["account","read"]] },
  admin: { allows: [["analytics","read"],["emails","read"],["products","read"],["products","import"],["replays","read"]] },
  superadmin: { allows: [["*","*"]] }
};
function has(list, res, act){ return list.some(([r,a]) => (r==="*"||r===res) && (a==="*"||a===act)); }
export function can(user, action, resource){ const role = user?.role || "user"; const r = roles[role] || roles.user; return has(r.allows, resource, action); }
export function requirePerm(resource, action){ return (req,res,next)=>{ if (!can(req.user, action, resource)) return res.status(403).json({ error:"Forbidden", resource, action }); next(); }; }
