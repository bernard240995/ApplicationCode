export function productJsonLd(p){
  return {
    "@context": "https://schema.org/",
    "@type": "Product",
    "name": p.name,
    "image": [p.imageUrl].filter(Boolean),
    "description": p.description,
    "sku": p.slug || p._id,
    "offers": {
      "@type": "Offer",
      "priceCurrency": (p.currency||"GBP").toUpperCase(),
      "price": (p.price||0).toFixed ? p.price.toFixed(2) : p.price,
      "availability": "https://schema.org/InStock"
    }
  };
}
