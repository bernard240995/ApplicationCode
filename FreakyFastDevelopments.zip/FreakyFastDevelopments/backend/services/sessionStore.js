import session from "express-session";
import connectRedis from "connect-redis";
import { createClient } from "redis";

export async function mountSession(app){
  if (process.env.ENABLE_SESSION_STORE !== "1") return;
  const RedisStore = connectRedis(session);
  const client = createClient({ url: process.env.REDIS_URL || "redis://127.0.0.1:6379" });
  await client.connect();
  app.use(session({
    store: new RedisStore({ client }),
    secret: process.env.SESSION_SECRET || "dev-session-secret",
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: process.env.NODE_ENV === "production" ? "none" : "lax",
      maxAge: 7*24*3600*1000
    }
  }));
}
