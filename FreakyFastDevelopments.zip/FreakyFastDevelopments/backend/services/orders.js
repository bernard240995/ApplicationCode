import Order from "../models/Order.js";
import { ensureInvoiceNumber, buildInvoicePdfBuffer } from "./invoicePdf.js";
import { emailQueue } from "../queues/emailQueue.js";
import { uploadBuffer, signedUrl } from "../services/s3.js";

export async function upsertOrderFromStripeSession(session){
  const Stripe = (await import('stripe')).default; const stripe = new Stripe(process.env.STRIPE_SECRET_KEY||'');
  const id = session.id;
  const email = session.customer_details?.email || session.customer_email || "";
  const currency = session.currency;
  const amount = session.amount_total != null ? session.amount_total : session.amount_subtotal;
  const metadata = session.metadata || {};
  const items = []; // consider expanding if you add line items retrieve
    // enrich with PI/charge if available
  let paymentIntentId = session.payment_intent || null;
  let chargeId = null;
  try {
    if (paymentIntentId) {
      const pi = await stripe.paymentIntents.retrieve(typeof paymentIntentId === 'string' ? paymentIntentId : paymentIntentId.id);
      chargeId = pi?.charges?.data?.[0]?.id || null;
    }
  } catch {}

  const doc = await Order.findOneAndUpdate(
    { provider: "stripe", providerId: id },
    { $set: { status: "paid", email, currency, amountTotal: amount, meta: metadata, items, paymentIntentId, chargeId } },
    { new: true, upsert: true }
  );
  // send order confirmation email via template
  try{
    await emailQueue.add("order-confirmation", {
      to: email,
      subject: "Your Freaky Fast order",
      template: "brand/order_confirmation.mjml",
      data: { customer: { name: email?.split("@")[0] || "Customer" }, order: { id: doc._id.toString(), total: (amount/100).toFixed(2), url: (process.env.FRONTEND_ORIGIN||"") + "/account/orders/"+doc._id } , year: new Date().getFullYear() }
    });
  }catch{}
  await ensureInvoiceNumber(doc);
try {
  if (process.env.INVOICE_BUCKET) {
    const key = `invoices/${doc.invoiceNumber}.pdf`;
    const buf = await buildInvoicePdfBuffer(doc);
    await uploadBuffer({ bucket: process.env.INVOICE_BUCKET, key, body: buf, contentType: "application/pdf" });
    doc.invoiceS3Key = key;
    await doc.save();
    const url = await signedUrl({ bucket: process.env.INVOICE_BUCKET, key, expiresIn: Number(process.env.INVOICE_URL_TTL||604800) });
    // Send invoice email
    await emailQueue.add("invoice-ready", {
      to: email,
      subject: `Your invoice ${doc.invoiceNumber}`,
      template: "brand/invoice_ready.mjml",
      data: { customer: { name: email?.split("@")[0] || "Customer" }, invoice: { number: doc.invoiceNumber, url }, order: { id: doc._id.toString(), total: (amount/100).toFixed(2) }, year: new Date().getFullYear() },
      attachments: process.env.ATTACH_INVOICE === "1" ? [{ filename: `${doc.invoiceNumber}.pdf`, content: buf, contentType: "application/pdf" }] : undefined
    });
  }
} catch (e) { console.warn("[Invoice upload/email] failed:", e?.message); }
return doc;
}
