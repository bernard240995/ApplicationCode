let mjml;
try { mjml = (await import("mjml")).default; } catch { mjml = null; }

export function renderMjml(mjmlString){
  if (!mjml) return null;
  const { html, errors } = mjml(mjmlString, { keepComments: false, validationLevel: "soft" });
  return html;
}
