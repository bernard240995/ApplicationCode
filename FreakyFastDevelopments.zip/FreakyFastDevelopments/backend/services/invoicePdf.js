import PDFDocument from "pdfkit";
import Counters from "../models/Counters.js";

export async function ensureInvoiceNumber(order){
  if (order.invoiceNumber) return order.invoiceNumber;
  const n = await Counters.next("invoice");
  const prefix = process.env.ORDER_INVOICE_PREFIX || "FF";
  const year = new Date().getFullYear();
  const num = `${prefix}-${year}-${String(n).padStart(5, "0")}`;
  order.invoiceNumber = num;
  await order.save();
  return num;
}

export async function buildInvoicePdf(order, res){
  const doc = new PDFDocument({ size: "A4", margin: 50 });
  const company = {
    name: process.env.COMPANY_NAME || "Freaky Fast Ltd.",
    line1: process.env.COMPANY_ADDR1 || "1 Fast Lane",
    line2: process.env.COMPANY_ADDR2 || "London, UK",
    vat: process.env.COMPANY_VAT || "GB123456789"
  };
  const currency = (order.currency || "gbp").toUpperCase();
  const total = (order.amountTotal/100).toFixed(2);

  doc.fontSize(18).text(company.name, { align: "right" });
  doc.fontSize(10).text(company.line1, { align: "right" });
  doc.text(company.line2, { align: "right" });
  doc.text("VAT: " + company.vat, { align: "right" });

  doc.moveDown();
  doc.fontSize(20).text("INVOICE", { align: "left" });
  doc.moveDown(0.5);
  doc.fontSize(10).text("Invoice No: " + (order.invoiceNumber||"pending"));
  doc.text("Order ID: " + order._id);
  doc.text("Email: " + (order.email||""));
  doc.text("Date: " + new Date(order.createdAt).toLocaleDateString());

  doc.moveDown();
  doc.fontSize(12).text("Items");
  doc.moveDown(0.3);
  const items = order.items || [];
  if (!items.length){
    doc.text("Order items not captured at checkout (line items API not enabled).", { continued: false });
  } else {
    items.forEach(it => {
      doc.text(`${it.qty||1} × ${it.name}  ${it.price?.toFixed?.(2)||it.price} ${currency}`);
    });
  }
  doc.moveDown();
  doc.fontSize(14).text(`Total: ${total} ${currency}`, { align: "right" });

  doc.end();
  doc.pipe(res);
}


export async function buildInvoicePdfBuffer(order){
  return await new Promise((resolve, reject)=>{
    const PDFDocument = ((await import("pdfkit")).default);
    const doc = new PDFDocument({ size: "A4", margin: 50 });
    const chunks = [];
    doc.on("data", c => chunks.push(c));
    doc.on("end", ()=> resolve(Buffer.concat(chunks)));
    doc.on("error", reject);
    const company = {
      name: process.env.COMPANY_NAME || "Freaky Fast Ltd.",
      line1: process.env.COMPANY_ADDR1 || "1 Fast Lane",
      line2: process.env.COMPANY_ADDR2 || "London, UK",
      vat: process.env.COMPANY_VAT || "GB123456789"
    };
    const currency = (order.currency || "gbp").toUpperCase();
    const total = (order.amountTotal/100).toFixed(2);

    doc.fontSize(18).text(company.name, { align: "right" });
    doc.fontSize(10).text(company.line1, { align: "right" });
    doc.text(company.line2, { align: "right" });
    doc.text("VAT: " + company.vat, { align: "right" });

    doc.moveDown();
    doc.fontSize(20).text("INVOICE", { align: "left" });
    doc.moveDown(0.5);
    doc.fontSize(10).text("Invoice No: " + (order.invoiceNumber||"pending"));
    doc.text("Order ID: " + order._id);
    doc.text("Email: " + (order.email||""));
    doc.text("Date: " + new Date(order.createdAt).toLocaleDateString());

    doc.moveDown();
    doc.fontSize(12).text("Items");
    doc.moveDown(0.3);
    const items = order.items || [];
    if (!items.length){
      doc.text("Order items not captured at checkout (line items API not enabled).", { continued: false });
    } else {
      items.forEach(it => {
        doc.text(`${it.qty||1} × ${it.name}  ${it.price?.toFixed?.(2)||it.price} ${currency}`);
      });
    }
    doc.moveDown();
    doc.fontSize(14).text(`Total: ${total} ${currency}`, { align: "right" });

    doc.end();
  });
}
