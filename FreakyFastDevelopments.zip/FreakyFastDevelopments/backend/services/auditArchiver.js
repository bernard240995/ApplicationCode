import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import AuditLog from "../models/AuditLog.js";

const enabled = process.env.AUDIT_ARCHIVE_ENABLED === "1";
const bucket = process.env.AUDIT_ARCHIVE_BUCKET;
const prefix = process.env.AUDIT_ARCHIVE_PREFIX || "audit/";

export function startAuditArchiver(){
  if (!enabled || !bucket) return;
  const client = new S3Client({ region: process.env.AWS_REGION || "eu-west-2" });
  setInterval(async ()=>{
    try{
      const batch = await AuditLog.find({ archived: false }).limit(100).lean();
      if (!batch.length) return;
      const body = batch.map(b => JSON.stringify(b)).join("\n") + "\n";
      const key = `${prefix}${new Date().toISOString().replace(/[:.]/g,"-")}-${Math.random().toString(36).slice(2)}.ndjson`;
      await client.send(new PutObjectCommand({
        Bucket: bucket,
        Key: key,
        Body: body,
        ContentType: "application/x-ndjson",
        ServerSideEncryption: "AES256"
        // For true WORM, enable Object Lock on the bucket and apply retention via bucket policy.
      }));
      const ids = batch.map(b => b._id);
      await AuditLog.updateMany({ _id: { $in: ids } }, { $set: { archived: true } });
    }catch(e){ /* swallow */ }
  }, 60 * 1000);
}
