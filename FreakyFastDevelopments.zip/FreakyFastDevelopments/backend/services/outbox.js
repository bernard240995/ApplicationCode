import OutboxEvent from "../models/OutboxEvent.js";
export async function addEvent(type, payload){ return await OutboxEvent.create({ type, payload }); }
export async function markProcessed(id){ return await OutboxEvent.findByIdAndUpdate(id, { $set:{ status:"processed" } }); }
export async function markFailed(id){ return await OutboxEvent.findByIdAndUpdate(id, { $inc:{ attempts:1 }, $set:{ status:"failed" } }); }
