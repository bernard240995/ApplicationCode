import fs from "fs";
import path from "path";

const tmplDir = path.join(process.cwd(), "templates", "emails");
const cache = new Map();

function renderString(t, data={}){
  return t.replace(/{{\s*([\w.]+)\s*}}/g, (_, k) => {
    const v = k.split(".").reduce((a,p)=> (a||{})[p], data);
    return v == null ? "" : String(v);
  });
}

export function renderTemplate(name, data){
  const fp = path.join(tmplDir, name + ".html");
  let t = cache.get(fp);
  if (!t){
    t = fs.readFileSync(fp, "utf-8");
    cache.set(fp, t);
  }
  return renderString(t, data);
}
