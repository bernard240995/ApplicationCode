import { S3Client, PutObjectCommand, GetObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

function client(){ return new S3Client({ region: process.env.AWS_REGION || "eu-west-2" }); }

export async function uploadBuffer({ bucket, key, body, contentType="application/octet-stream" }){
  const c = client();
  await c.send(new PutObjectCommand({ Bucket: bucket, Key: key, Body: body, ContentType: contentType, ServerSideEncryption: "AES256" }));
  return { bucket, key };
}

export async function signedUrl({ bucket, key, expiresIn=3600 }){
  const c = client();
  const cmd = new GetObjectCommand({ Bucket: bucket, Key: key });
  return await getSignedUrl(c, cmd, { expiresIn });
}
