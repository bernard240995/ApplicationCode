import { notifySlack } from "./alerting.js";

export function startMemoryWatch(){
  const threshMb = Number(process.env.MEMORY_ALERT_MB || 1024); // default 1GB
  const cooldownMs = 30*60*1000; // 30 minutes
  let last = 0;
  setInterval(()=>{
    try{
      const rss = process.memoryUsage().rss / (1024*1024);
      if (rss > threshMb){
        const now = Date.now();
        if (now - last > cooldownMs){
          notifySlack(`High memory usage detected: RSS ${rss.toFixed(0)} MB (threshold ${threshMb} MB)`, "mem-high", cooldownMs);
          last = now;
        }
      }
    }catch(_){}
  }, 60*1000);
}
