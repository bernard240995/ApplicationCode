import fetch from "node-fetch";

let lastSent = new Map(); // key -> ts

function shouldSend(key, cooldownMs=5*60*1000){
  const now = Date.now();
  const last = lastSent.get(key) || 0;
  if (now - last < cooldownMs) return false;
  lastSent.set(key, now);
  return true;
}

export async function notifySlack(text, key="generic", cooldownMs){
  try{
    const url = process.env.SLACK_WEBHOOK_URL;
    if (!url) return;
    if (!shouldSend(key, cooldownMs)) return;
    await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text })
    });
  }catch(_){}
}
