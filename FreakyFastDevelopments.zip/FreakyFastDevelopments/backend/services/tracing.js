export async function startTracing(){
  if (process.env.ENABLE_OTEL !== "1") return;
  try{
    const { NodeSDK } = await import("@opentelemetry/sdk-node");
    const { getNodeAutoInstrumentations } = await import("@opentelemetry/auto-instrumentations-node");
    const { OTLPTraceExporter } = await import("@opentelemetry/exporter-trace-otlp-http");
    const { Resource } = await import("@opentelemetry/resources");
    const { SemanticResourceAttributes } = await import("@opentelemetry/semantic-conventions");
    const sdk = new NodeSDK({
      resource: new Resource({
        [SemanticResourceAttributes.SERVICE_NAME]: process.env.OTEL_SERVICE_NAME || "freakyfast-api",
        [SemanticResourceAttributes.DEPLOYMENT_ENVIRONMENT]: process.env.NODE_ENV || "development"
      }),
      traceExporter: new OTLPTraceExporter({ url: process.env.OTEL_EXPORTER_OTLP_ENDPOINT || "http://localhost:4318/v1/traces" }),
      instrumentations: [getNodeAutoInstrumentations({ '@opentelemetry/instrumentation-express': { enabled: true } })],
    });
    await sdk.start();
    console.log("[OTEL] tracing initialized");
  }catch(e){
    console.warn("[OTEL] failed to start:", e?.message);
  }
}
