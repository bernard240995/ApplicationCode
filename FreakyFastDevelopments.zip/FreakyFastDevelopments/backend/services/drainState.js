let drained = false;
export function setDrained(v){ drained = !!v; }
export function isDrained(){ return drained; }
