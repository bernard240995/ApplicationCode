import mongoose from "mongoose";
import client from "prom-client";

const SLOW_MS = Number(process.env.MONGO_SLOW_MS || 200);
const SLOW_COUNT = new client.Counter({ name:"mongo_slow_queries_total", help:"Slow Mongo queries total" });
const recent = []; // keep last 200 entries

export function startMongoSlowLog(){
  if (!mongoose || !mongoose.connection) return;
  mongoose.set("debug", function (collectionName, method, ...args){
    const start = Date.now();
    const cb = args[args.length-1];
    if (typeof cb === "function"){
      args[args.length-1] = function(...cbArgs){
        const dur = Date.now() - start;
        if (dur >= SLOW_MS){
          SLOW_COUNT.inc();
          const entry = { t: new Date().toISOString(), collection: collectionName, method, dur, args: safeArgs(args) };
          recent.push(entry);
          if (recent.length > 200) recent.shift();
        }
        return cb.apply(this, cbArgs);
      };
    }
  });
}

function safeArgs(args){
  try{ return JSON.parse(JSON.stringify(args.slice(0,2))); }catch{ return []; }
}

export function getRecentSlow(){ return recent.slice().reverse(); }
