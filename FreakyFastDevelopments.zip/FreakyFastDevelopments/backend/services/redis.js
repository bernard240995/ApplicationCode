let client = null;
let mem = new Map();

export async function getRedis(){
  if (client !== null) return client;
  if (!process.env.REDIS_URL) { client = null; return null; }
  try {
    const { createClient } = await import("redis");
    const c = createClient({ url: process.env.REDIS_URL });
    c.on("error", (e)=>console.error("[redis] error", e?.message));
    await c.connect();
    client = c;
  } catch {
    client = null;
  }
  return client;
}

export async function cacheGet(key){
  const r = await getRedis();
  if (r) return await r.get(key);
  return mem.get(key) || null;
}

export async function cacheSet(key, val, ttlSec=60){
  const r = await getRedis();
  if (r) { await r.set(key, val, { EX: ttlSec }); return; }
  mem.set(key, val);
  setTimeout(()=>mem.delete(key), ttlSec*1000);
}
