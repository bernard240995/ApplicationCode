import crypto from "crypto";

export function signUrl(url){
  const secret = process.env.CDN_SIGNING_SECRET;
  if (!secret) return url;
  const ttl = Number(process.env.CDN_SIGNING_TTL || 300);
  const exp = Math.floor(Date.now()/1000) + ttl;
  const data = `${url}|${exp}`;
  const sig = crypto.createHmac("sha256", secret).update(data).digest("hex");
  const sep = url.includes("?") ? "&" : "?";
  return `${url}${sep}exp=${exp}&sig=${sig}`;
}
