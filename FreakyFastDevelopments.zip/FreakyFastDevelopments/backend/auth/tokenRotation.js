import jwt from "jsonwebtoken";
import { randomUUID } from "crypto";

const SECRET = process.env.JWT_SECRET || "dev-secret";
const LIFETIME_SEC = Number(process.env.JWT_LIFETIME_SEC || 3600);
const ROTATE_AFTER_SEC = Number(process.env.JWT_ROTATE_AFTER_SEC || 900);

export function signToken(payload){
  const now = Math.floor(Date.now()/1000);
  const body = { ...payload, iat: now, nbf: now, jti: randomUUID() };
  return jwt.sign(body, SECRET, { expiresIn: LIFETIME_SEC });
}

export function verifyToken(token){
  try { return jwt.verify(token, SECRET); }
  catch { return null; }
}

export function needsRotation(decoded){
  if (!decoded?.iat) return true;
  const now = Math.floor(Date.now()/1000);
  return (now - decoded.iat) > ROTATE_AFTER_SEC;
}

export function rotateIfNeeded(token){
  const decoded = verifyToken(token);
  if (!decoded) return { rotated: true, token: signToken({}) };
  if (needsRotation(decoded)){
    const { iat, exp, nbf, jti, ...rest } = decoded;
    return { rotated: true, token: signToken(rest) };
  }
  return { rotated: false, token };
}
