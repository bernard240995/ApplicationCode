// backend/utils/sentry.js
export function initSentry(app){
  const dsn = process.env.SENTRY_DSN;
  if (!dsn) return;
  import('@sentry/node').then(({ init, Handlers }) => {
    init({ dsn, tracesSampleRate: 0.2 });
    app.use(Handlers.requestHandler());
    app.use(Handlers.tracingHandler());
    app.use(Handlers.errorHandler());
  }).catch(()=>{});
}
