// backend/utils/seedPages.js
import CmsPage from '../models/CmsPage.js';

export async function ensureCorePages(){
  const pages = [
    { slug:'about-us', title:'About FreakyFast', body: '<p>FreakyFast is a UK-born clothing brand obsessed with premium fabrics, fearless design, and same-day dispatch. All text/images are editable in Admin.</p>' },
    { slug:'returns', title:'Returns & Exchanges', body: '<p>30-day returns on unworn items. Start a return via your account or contact support. This is placeholder text — edit in Admin.</p>' },
    { slug:'shipping', title:'Shipping & Delivery', body: '<p>Fast UK delivery with Royal Mail, DPD, and more. Free shipping thresholds are configurable. Placeholder content.</p>' },
    { slug:'size-guide', title:'Size Guide', body: '<p>Find your perfect fit. Include chest/waist/length charts per product type. Placeholder content.</p>' },
    { slug:'contact', title:'Contact Us', body: '<p>Email support@yourdomain.co.uk or use the chat widget to open a ticket.</p>' },
    { slug:'privacy-policy', title:'Privacy Policy', body: '<p>Explain how data is collected, used, and stored. Placeholder content only.</p>' },
    { slug:'terms', title:'Terms & Conditions', body: '<p>Standard e-commerce terms, warranties, and liabilities. Placeholder content.</p>' },
    { slug:'cookies', title:'Cookie Policy', body: '<p>Explain analytics, essential cookies, and user choices. Placeholder content.</p>' },
  ];
  for (const p of pages){
    const exists = await CmsPage.findOne({ slug: p.slug });
    if (!exists){
      await CmsPage.create({ slug: p.slug, title: p.title, body: p.body, status:'published', metaTitle: p.title, metaDescription: p.title+' — FreakyFast Clothing' });
    }
  }
}
