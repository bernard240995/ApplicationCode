// backend/utils/branding.js
import Setting from '../models/Setting.js';

export async function getLogoUrl(baseOverride){
  try{
    const base = baseOverride || process.env.FRONTEND_URL || '';
    const rec = await Setting.findOne({ key: 'site.logoUrl' }).lean();
    const path = (rec?.value) || '/assets/brand/logo-header.png';
    if (path.startsWith('http')) return path;
    return base ? (base.replace(/\/$/,'') + path) : path;
  }catch{
    const base = baseOverride || process.env.FRONTEND_URL || '';
    const path = '/assets/brand/logo-header.png';
    return base ? (base.replace(/\/$/,'') + path) : path;
  }
}


export async function getEmailFooter(){
  try{
    const vat = (await Setting.findOne({ key:'company.vat' }))?.value || '';
    const reg = (await Setting.findOne({ key:'company.reg' }))?.value || '';
    const addr = (await Setting.findOne({ key:'company.address' }))?.value || '';
    const parts = [];
    if (vat) parts.push(`VAT: ${vat}`);
    if (reg) parts.push(`Company No: ${reg}`);
    if (addr) parts.push(addr);
    return parts.join(' • ');
  }catch{ return '' }
}
