
// backend/utils/mailer.js
import nodemailer from 'nodemailer';

export function buildTransport(){
  const { SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_SECURE } = process.env;
  return nodemailer.createTransport({
    host: SMTP_HOST, port: Number(SMTP_PORT||587), secure: String(SMTP_SECURE||'false')==='true',
    auth: SMTP_USER? { user: SMTP_USER, pass: SMTP_PASS } : undefined
  });
}

export async function sendOrderEmail({ to, subject, html }){
  const tx = buildTransport();
  await tx.sendMail({
    from: process.env.MAIL_FROM || 'FreakyFast <no-reply@freakyfast.co.uk>',
    to, subject, html
  });
}

export function renderOrderEmail({ orderId, items, totalMinor }){
  const logoUrl = (process.env.PUBLIC_URL || '') + '/logo.png';
  const lines = (items||[]).map(i=>`<tr><td style="padding:6px 0">${i.name} × ${i.quantity}</td><td style="text-align:right">£${(i.amountMinor/100).toFixed(2)}</td></tr>`).join('');
  return `
  <div style="font-family:Inter,system-ui,Segoe UI,Arial,sans-serif;color:#0b0d12">
    <div style="padding:16px;border-bottom:1px solid #eee;display:flex;align-items:center">
      <img alt="FreakyFast" src="${logoUrl}" style="height:32px;margin-right:10px" />
      <b>Order Confirmation</b>
    </div>
    <div style="padding:16px">
      <p>Thanks for your order <b>#${orderId}</b> — we’re on it.</p>
      <table style="width:100%">${lines}</table>
      <div style="text-align:right;margin-top:8px"><b>Total: £${(totalMinor/100).toFixed(2)}</b></div>
    </div>
    <div style="padding:16px;border-top:1px solid #eee;font-size:12px;opacity:.7">FreakyFast Clothing Co.</div>
  </div>`;
}
