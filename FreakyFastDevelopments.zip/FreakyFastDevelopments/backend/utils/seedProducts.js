// backend/utils/seedProducts.js
import Product from '../models/Product.js';

export async function ensureDemoProducts(){
  const count = await Product.countDocuments();
  if (count > 0) return;
  
  const demo = [
    { title:'FreakyFast Essential Hoodie', slug:'essential-hoodie', description:'Heavyweight, brushed fleece. Built for UK weather.', priceMinor:5999, currency:'GBP', images:['https://images.unsplash.com/photo-1520974735194-6c0fa19a8ba3?w=1200&q=80','https://images.unsplash.com/photo-1520975661595-6453be3f7070?w=1200&q=80'], sizes:['XS','S','M','L','XL'], colors:['Black','Grey'], sku:'FF-HOOD-ESS', status:'active', stock:12, minStock:2, maxStock:100 },
    { title:'Everyday Tee', slug:'everyday-tee', description:'Premium cotton tee with perfect drape.', priceMinor:2499, currency:'GBP', images:['https://images.unsplash.com/photo-1512436991641-6745cdb1723f?w=1200&q=80'], sizes:['S','M','L','XL'], colors:['White','Black'], sku:'FF-TEE-CORE', status:'active', stock:1, minStock:2, maxStock:100 },
    { title:'Classic Cap', slug:'classic-cap', description:'Adjustable fit, tonal logo.', priceMinor:1999, currency:'GBP', images:['https://images.unsplash.com/photo-1520975661595-6453be3f7070?w=1200&q=80'], sizes:[], colors:['Black'], sku:'FF-CAP-CLASSIC', status:'active', stock:23, minStock:2, maxStock:100 },
    { title:'Pro Joggers', slug:'pro-joggers', description:'Tapered fit joggers for every day.', priceMinor:4499, currency:'GBP', images:['https://images.unsplash.com/photo-1495121605193-b116b5b09a61?w=1200&q=80'], sizes:['S','M','L','XL'], colors:['Black','Navy'], sku:'FF-JOG-PRO', status:'active', stock:9, minStock:2, maxStock:100 },
    { title:'Storm Jacket', slug:'storm-jacket', description:'Water-resistant with heat-sealed seams.', priceMinor:7999, currency:'GBP', images:['https://images.unsplash.com/photo-1544025162-d76694265947?w=1200&q=80'], sizes:['S','M','L','XL'], colors:['Black','Olive'], sku:'FF-JKT-STORM', status:'active', stock:6, minStock:2, maxStock:100 },
    { title:'Oversized Hoodie', slug:'oversized-hoodie', description:'Oversized fit with dropped shoulders.', priceMinor:6299, currency:'GBP', images:['https://images.unsplash.com/photo-1519741497674-611481863552?w=1200&q=80'], sizes:['S','M','L','XL'], colors:['Black','Cream'], sku:'FF-HOOD-OVR', status:'active', stock:3, minStock:2, maxStock:100 },
    { title:'Performance Tee', slug:'performance-tee', description:'Moisture-wicking fabric for training.', priceMinor:2999, currency:'GBP', images:['https://images.unsplash.com/photo-1520974735194-6c0fa19a8ba3?w=1200&q=80'], sizes:['S','M','L','XL'], colors:['Navy','Grey'], sku:'FF-TEE-PERF', status:'active', stock:15, minStock:2, maxStock:100 },
    { title:'Puffer Jacket', slug:'puffer-jacket', description:'Warm, lightweight puffer.', priceMinor:9999, currency:'GBP', images:['https://images.unsplash.com/photo-1517341720791-fb363f42c32f?w=1200&q=80'], sizes:['S','M','L','XL'], colors:['Black','Navy'], sku:'FF-JKT-PUFF', status:'active', stock:4, minStock:2, maxStock:100 },
    { title:'Logo Beanie', slug:'logo-beanie', description:'Ribbed knit, tonal branding.', priceMinor:1499, currency:'GBP', images:['https://images.unsplash.com/photo-1545186420-74c36fcdeddb?w=1200&q=80'], sizes:[], colors:['Black','Grey'], sku:'FF-BEANIE', status:'active', stock:18, minStock:2, maxStock:100 },
    { title:'Athletic Shorts', slug:'athletic-shorts', description:'Lightweight training shorts.', priceMinor:3499, currency:'GBP', images:['https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=1200&q=80'], sizes:['S','M','L','XL'], colors:['Black','Navy'], sku:'FF-SHRT-ATH', status:'active', stock:11, minStock:2, maxStock:100 }
  ];
  await Product.insertMany(demo);

}
