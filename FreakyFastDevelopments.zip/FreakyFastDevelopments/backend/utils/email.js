import { getLogoUrl, getEmailFooter } from './branding.js';
const nodemailer = require('nodemailer');
let transporter=null;
function getTransport(){
  if(transporter) return transporter;
  const host = process.env.SMTP_HOST||''; const user=process.env.SMTP_USER||''; const pass=process.env.SMTP_PASS||'';
  if(!host || !user || !pass){
    // Dev fallback: console "transport"
    return { sendMail: async (o)=>{ console.log('[email:dev]', o.to, o.subject); return { messageId:'dev' } } }
  }
  transporter = nodemailer.createTransport({ host, port: Number(process.env.SMTP_PORT||587), secure: false, auth:{ user, pass } });
  return transporter;
}
async function send({ to, subject, html, text }){
  const from = process.env.SMTP_FROM || 'FreakyFast <no-reply@local.test>';
  return getTransport().sendMail({ from, to, subject, html: html||text, text: text||html });
}
module.exports = { send };


export function renderTicketEmail(ticket, {statusChanged=false}={}){
  const title = statusChanged ? `Ticket ${ticket._id} status: ${ticket.status}` : `New Support Ticket: ${ticket.subject}`;
  return `
  <table width="100%" cellpadding="0" cellspacing="0" style="font-family:Arial,Helvetica,sans-serif;background:#0b0d12;color:#fff;padding:24px">
    <tr><td align="center">
      <table width="640" style="background:#111827;border-radius:16px;overflow:hidden">
        <tr><td style="padding:24px"><div style=\"text-align:center;margin-bottom:12px\"><img src=\"${await getLogoUrl()}\" alt=\"FreakyFast\" height=\"40\"/></div><div style=\"text-align:center;margin-bottom:12px\"><img src=\"${await getLogoUrl()}\" alt=\"FreakyFast\" height=\"40\"/></div>
          <h2 style="margin:0 0 10px">FreakyFast Support <!-- brand logo --></h2>
          <p style="opacity:.8;margin:0 0 20px">${title}</p>
          <div style="background:#0a0c10;border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:16px">
            <p><b>Subject:</b> ${ticket.subject || ''}</p>
            <p><b>Message:</b> ${ticket.message || ''}</p>
            <p><b>Status:</b> ${ticket.status}</p>
            <p><b>Priority:</b> ${ticket.priority}</p>
            <p><b>Name:</b> ${ticket.name || ''}</p>
            <p><b>Email:</b> ${ticket.email || ''}</p>
            <p><b>Phone:</b> ${ticket.phone || ''}</p>
          </div>
        ${await footerHtml()}</td></tr>
      </table>
    </td></tr>
  </table>`;
}


export function renderOrderEmail(order, {type='confirmation'}={}){
  let subject = type==='confirmation' ? `Order Confirmation #${order._id}` :
                type==='shipped' ? `Your Order #${order._id} has shipped` :
                `Update on your Order #${order._id}`;
  return {
    subject,
    html: `<div style="font-family:sans-serif;padding:24px;background:#f7f8fa">
      <h2 style="color:#0b0d12">${subject}</h2>
      <p>Hi ${order.name||'Customer'},</p>
      <p>Status: ${order.status}</p>
      <ul>${(order.items||[]).map(i=>`<li>${i.title} x${i.qty}</li>`).join('')}</ul>
      <p>Total: £${order.total}</p>
      <p>Thank you for shopping with FreakyFast.</p>
    </div>`
  };
}


import nodemailer from 'nodemailer';
export async function createTransport() {
  const host = process.env.SMTP_HOST;
  const port = Number(process.env.SMTP_PORT || 587);
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;
  if (!host || !user || !pass) throw new Error('SMTP not configured');
  return nodemailer.createTransport({ host, port, auth: { user, pass } });
}


async function footerHtml(){
  const f = await getEmailFooter();
  if (!f) return '';
  return `<tr><td style="padding:16px 24px;color:#9ca3af;font-size:12px;border-top:1px solid rgba(255,255,255,.1)">${f}</td></tr>`;
}


export async function renderShipmentEmail({ id='', name='', carrier='', trackingNumber='', trackingUrl='' }){
  const logo = await getLogoUrl();
  const footer = await getEmailFooter?.() || '';
  const link = trackingUrl || (trackingNumber ? `https://www.google.com/search?q=${encodeURIComponent(carrier+' '+trackingNumber)}` : '');
  return `
  <table width="100%" cellpadding="0" cellspacing="0" style="font-family:Arial,Helvetica,sans-serif;background:#0b0d12;color:#fff;padding:24px">
    <tr><td align="center">
      <table width="640" style="background:#111827;border-radius:16px;overflow:hidden">
        <tr><td style="padding:24px">
          <div style="text-align:center;margin-bottom:12px"><img src="${logo}" alt="FreakyFast" height="40"/></div>
          <h2 style="margin:0 0 10px">Good news${name?`, ${name}`:''} — your order is on the way!</h2>
          <p style="opacity:.8;margin:0 0 20px">Order <b>${id}</b> has been shipped.</p>
          <div style="background:#0a0c10;border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:16px">
            <p><b>Carrier:</b> ${carrier||'—'}</p>
            <p><b>Tracking number:</b> ${trackingNumber||'—'}</p>
            ${link ? `<p><a href="${link}" style="display:inline-block;background:#00d1ff;color:#0a0c10;padding:10px 14px;border-radius:10px;text-decoration:none;font-weight:800">Track shipment</a></p>`:''}
          </div>
        </td></tr>
        ${footer ? `<tr><td style="padding:16px 24px;color:#9ca3af;font-size:12px;border-top:1px solid rgba(255,255,255,.1)">${footer}</td></tr>`:''}
      </table>
    </td></tr>
  </table>`;
}


export async function renderDeliveredEmail({ id='', name='' }){
  const logo = await getLogoUrl();
  const footer = await getEmailFooter?.() || '';
  return `
  <table width="100%" cellpadding="0" cellspacing="0" style="font-family:Arial,Helvetica,sans-serif;background:#0b0d12;color:#fff;padding:24px">
    <tr><td align="center">
      <table width="640" style="background:#111827;border-radius:16px;overflow:hidden">
        <tr><td style="padding:24px">
          <div style="text-align:center;margin-bottom:12px"><img src="${logo}" alt="FreakyFast" height="40"/></div>
          <h2 style="margin:0 0 10px">Delivered${name?`, ${name}`:''} — we hope you love it!</h2>
          <p style="opacity:.8;margin:0 0 20px">Order <b>${id}</b> shows as delivered. If anything's not perfect, reply to this email and we'll help.</p>
          <p><a href="${(process.env.FRONTEND_URL||'') + '/account/orders'}" style="display:inline-block;background:#00d1ff;color:#0a0c10;padding:10px 14px;border-radius:10px;text-decoration:none;font-weight:800">View your orders</a></p>
        </td></tr>
        ${footer ? `<tr><td style="padding:16px 24px;color:#9ca3af;font-size:12px;border-top:1px solid rgba(255,255,255,.1)">${footer}</td></tr>`:''}
      </table>
    </td></tr>
  </table>`;
}
