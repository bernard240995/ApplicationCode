// backend/utils/carriers.js
export const CARRIERS = [
  { key:'Royal Mail', pattern:'https://www.royalmail.com/track-your-item#/tracking-results/%s' },
  { key:'DPD', pattern:'https://www.dpd.co.uk/apps/tracking/?reference=%s&postcode=' },
  { key:'Evri', pattern:'https://www.evri.com/track/parcel/%s' },
  { key:'DHL', pattern:'https://www.dhl.com/global-en/home/tracking/tracking-express.html?tracking-id=%s' },
  { key:'UPS', pattern:'https://www.ups.com/track?tracknum=%s' },
  { key:'Parcelforce', pattern:'https://www.parcelforce.com/track-trace?trackNumber=%s' }
];

export function makeTrackingUrl(carrier, num){
  if (!num) return '';
  const c = CARRIERS.find(x => (x.key.toLowerCase()===String(carrier||'').toLowerCase()));
  if (c) return c.pattern.replace('%s', encodeURIComponent(num));
  return `https://www.google.com/search?q=${encodeURIComponent((carrier||'')+' '+num)}`;
}
