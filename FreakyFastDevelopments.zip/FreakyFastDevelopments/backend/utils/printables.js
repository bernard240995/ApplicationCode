// backend/utils/printables.js
import { getLogoUrl } from './branding.js';

export async function renderInvoiceHTML(order, base){
  const logo = await getLogoUrl(base);
  const rows = (order.items||[]).map(i => `<tr>
      <td>${escapeHtml(i.title||'')}</td>
      <td>${i.qty||1}</td>
      <td>${escapeHtml(i.price||'')}</td>
    </tr>`).join('');
  return `<!doctype html>
<html><head><meta charset="utf-8"><title>Invoice ${order.id||''}</title>
<style>
  body{font-family:Arial,Helvetica,sans-serif;color:#111}
  .wrap{max-width:800px;margin:24px auto;padding:24px;border:1px solid #e5e7eb;border-radius:12px}
  .brand{display:flex;align-items:center;gap:12px;margin-bottom:16px}
  .brand img{height:44px}
  h1{margin:0 0 8px}
  table{width:100%;border-collapse:collapse;margin-top:12px}
  th,td{border:1px solid #e5e7eb;padding:10px;text-align:left}
  .grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:12px}
  .muted{color:#6b7280}
</style></head>
<body>
  <div class="wrap">
    <div class="brand"><img src="${logo}" alt="Logo"/><div><h1>Invoice</h1><div class="muted">${order.id||''}</div></div></div>
    <div class="grid">
      <div>
        <h3>Bill To</h3>
        <div>${escapeHtml(order.name||'')}</div>
        <div>${escapeHtml(order.email||'')}</div>
        <div>${escapeHtml(order.address||'')}</div>
      </div>
      <div>
        <h3>Details</h3>
        <div>Date: ${new Date().toLocaleDateString()}</div>
        <div>Total: <b>${escapeHtml(order.total||'')}</b></div>
      </div>
    </div>
    <table>
      <thead><tr><th>Item</th><th>Qty</th><th>Price</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
  </div>
</body></html>`;
}

export async function renderLabelHTML(order, base){
  const logo = await getLogoUrl(base);
  return `<!doctype html>
<html><head><meta charset="utf-8"><title>Label ${order.id||''}</title>
<style>
  body{font-family:Arial,Helvetica,sans-serif;color:#111}
  .lab{width:4in;height:6in;padding:.25in;border:1px solid #111;margin:0 auto}
  .brand{text-align:center;margin-bottom:.15in}
  .brand img{height:.5in}
  .blk{border:1px solid #111;padding:.1in;margin-bottom:.1in}
  .addr{font-size:14px;line-height:1.3}
  .code{font-size:18px;font-weight:700;margin-top:.1in}
</style></head>
<body>
  <div class="lab">
    <div class="brand"><img src="${logo}" alt="Logo"/></div>
    <div class="blk addr">
      <div><b>Ship To</b></div>
      <div>${escapeHtml(order.name||'')}</div>
      <div>${escapeHtml(order.address||'')}</div>
      <div>${escapeHtml(order.postcode||'')}</div>
    </div>
    <div class="blk">
      <div><b>Order:</b> ${escapeHtml(order.id||'')}</div>
      <div><b>Phone:</b> ${escapeHtml(order.phone||'')}</div>
    </div>
    <div class="code">${escapeHtml((order.postcode||'').toUpperCase())}</div>
  </div>
</body></html>`;
}

function escapeHtml(s){
  return String(s||'').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
}
