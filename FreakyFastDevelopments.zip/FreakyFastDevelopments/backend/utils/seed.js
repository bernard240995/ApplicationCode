// backend/utils/seed.js
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import Product from '../models/Product.js';
dotenv.config();
const MONGO_URL = process.env.MONGO_URL || 'mongodb://localhost:27017/freakyfast';
await mongoose.connect(MONGO_URL);

const products = [
  { title:'Essential Hoodie', slug:'essential-hoodie', priceMinor:5999, currency:'GBP', images:['https://images.unsplash.com/photo-1519741497674-611481863552?w=1600&q=80'], sizes:['S','M','L','XL'], colors:['Black'], stock:50, minStock:5, maxStock:200 },
  { title:'Performance Tee', slug:'performance-tee', priceMinor:2499, currency:'GBP', images:['https://images.unsplash.com/photo-1520974735194-6c0fa19a8ba3?w=1600&q=80'], sizes:['S','M','L','XL'], colors:['White'], stock:80, minStock:10, maxStock:300 },
  { title:'All-Weather Jacket', slug:'all-weather-jacket', priceMinor:8999, currency:'GBP', images:['https://images.unsplash.com/photo-1495121605193-b116b5b09a61?w=1600&q=80'], sizes:['S','M','L','XL'], colors:['Navy'], stock:30, minStock:3, maxStock:100 }
];
for (const p of products){
  await Product.updateOne({ slug:p.slug }, { $set: p }, { upsert:true });
}
console.log('Seed complete:', products.length, 'products');
await mongoose.disconnect();
