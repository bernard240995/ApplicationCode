// backend/models/Review.js
import mongoose from 'mongoose';
const ReviewSchema = new mongoose.Schema({
  productSlug: { type:String, index:true },
  customerEmail: String,
  rating: { type:Number, min:1, max:5 },
  comment: String,
  status: { type:String, enum:['pending','approved','rejected'], default:'approved' }
}, { timestamps:true });
export default mongoose.models.Review || mongoose.model('Review', ReviewSchema);
