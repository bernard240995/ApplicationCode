const mongoose=require('mongoose');
const SessionSchema=new mongoose.Schema({ jti:String, userId:String, ts:{type:Date,default:Date.now} });
module.exports = mongoose.model('Session', SessionSchema);
