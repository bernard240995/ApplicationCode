// backend/models/ProcessedWebhook.js
import mongoose from 'mongoose';
const ProcessedWebhookSchema = new mongoose.Schema({
  source: String, // 'stripe'
  eventId: { type:String, unique:true },
}, { timestamps:true });
export default mongoose.models.ProcessedWebhook || mongoose.model('ProcessedWebhook', ProcessedWebhookSchema);
