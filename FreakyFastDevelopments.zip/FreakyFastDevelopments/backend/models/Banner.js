// backend/models/Banner.js
import mongoose from 'mongoose';
const BannerSchema = new mongoose.Schema({
  title: String,
  image: String,
  link: String,
  active: { type:Boolean, default:true },
  order: { type:Number, default:0 }
}, { timestamps:true });
export default mongoose.models.Banner || mongoose.model('Banner', BannerSchema);
