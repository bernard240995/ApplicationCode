// backend/models/AdminAudit.js
import mongoose from 'mongoose';
const AdminAuditSchema = new mongoose.Schema({
  path: String,
  method: String,
  actor: String, // admin id/email if available
  ip: String,
  payload: Object,
}, { timestamps:true });
export default mongoose.models.AdminAudit || mongoose.model('AdminAudit', AdminAuditSchema);
