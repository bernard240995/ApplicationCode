import mongoose from "mongoose";
const SiteConfig = new mongoose.Schema({
  key: { type: String, unique: true, index: true },
  value: mongoose.Schema.Types.Mixed
}, { timestamps: true, versionKey: false });
export default mongoose.model("SiteConfig", SiteConfig);
