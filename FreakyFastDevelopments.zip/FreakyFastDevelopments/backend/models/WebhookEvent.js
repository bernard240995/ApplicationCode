import mongoose from "mongoose";
const WebhookEventSchema = new mongoose.Schema({
  provider: { type: String, index: true },
  eventId: { type: String, unique: true, index: true },
  payload: { type: Object },
  processed: { type: Boolean, default: false },
  note: { type: String, default: "" }
}, { timestamps: true, versionKey: false });
export default mongoose.model("WebhookEvent", WebhookEventSchema);
