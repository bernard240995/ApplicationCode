// backend/models/Order.js
import mongoose from 'mongoose';

const OrderSchema = new mongoose.Schema({
  orderId: { type: String, index: true },
  email: String,
  name: String,
  address: String,
  postcode: String,
  phone: String,
  currency: { type: String, default: 'gbp' },
  amount: Number,
  items: [{
    title: String,
    qty: Number,
    price: String
  }],
  status: { type: String, enum: ['created','paid','failed','refunded'], default: 'created' },
  stripeSessionId: String,
  stripePaymentIntentId: String,
  carrier: String,
  trackingNumber: String,
  trackingUrl: String,
  shippedAt: Date,
  deliveredAt: Date,
}, { timestamps: true });

export default mongoose.models.Order || mongoose.model('Order', OrderSchema);
