// backend/models/CmsPage.js
import mongoose from 'mongoose';

const CmsPageSchema = new mongoose.Schema({
  metaTitle: { type: String, default: '' },
  metaDescription: { type: String, default: '' },
  ogImage: { type: String, default: '' },
  slug: { type: String, unique: true, index: true },
  title: { type: String, required: true },
  content: { type: String, default: '' },
  status: { type: String, enum: ['draft','published'], default: 'published' }
}, { timestamps: true });

export default mongoose.models.CmsPage || mongoose.model('CmsPage', CmsPageSchema);
