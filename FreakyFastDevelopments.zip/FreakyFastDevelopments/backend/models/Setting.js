// backend/models/Setting.js
import mongoose from 'mongoose';

const SettingSchema = new mongoose.Schema({
  key: { type: String, unique: true, index: true },
  value: {},
}, { timestamps: true });

export default mongoose.models.Setting || mongoose.model('Setting', SettingSchema);
