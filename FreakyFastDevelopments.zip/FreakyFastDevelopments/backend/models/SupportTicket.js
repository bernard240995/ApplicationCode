
// backend/models/SupportTicket.js
import mongoose from 'mongoose';
const SupportTicketSchema = new mongoose.Schema({
  name: String,
  email: String,
  phone: String,
  message: String,
  status: { type:String, default:'open' },
  createdAt: { type:Date, default: Date.now }
});
export default mongoose.models.SupportTicket || mongoose.model('SupportTicket', SupportTicketSchema);
