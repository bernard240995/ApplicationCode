import mongoose from "mongoose";
const SessionReplay = new mongoose.Schema({
  sessionId: { type: String, index: true },
  user: String,
  events: Array,
  page: String,
  startedAt: Date
}, { timestamps: true, versionKey: false });
export default mongoose.model("SessionReplay", SessionReplay);
