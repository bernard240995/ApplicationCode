import mongoose from "mongoose";
const EmailEventSchema = new mongoose.Schema({
  to: { type: String, index: true },
  subject: String,
  template: String,
  status: { type: String, default: "sent" },
  error: String,
  messageId: String,
  meta: Object
}, { timestamps: true, versionKey: false });
EmailEventSchema.index({ createdAt: -1 });
export default mongoose.model("EmailEvent", EmailEventSchema);
