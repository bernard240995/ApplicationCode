import mongoose from "mongoose";
const AuditLog = new mongoose.Schema({ ts:{type:Date,default:Date.now,index:true}, user:String, method:String, path:String, resource:String, action:String, ip:String, before:Object, after:Object }, { versionKey:false });
export default mongoose.model("AuditLog", AuditLog);
