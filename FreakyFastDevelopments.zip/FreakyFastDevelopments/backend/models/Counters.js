import mongoose from "mongoose";
const Counters = new mongoose.Schema({ key: { type: String, unique: true }, seq: { type: Number, default: 0 } }, { versionKey: false });
Counters.statics.next = async function(key){
  const doc = await this.findOneAndUpdate({ key }, { $inc: { seq: 1 } }, { upsert: true, new: true });
  return doc.seq;
};
export default mongoose.model("Counters", Counters);
