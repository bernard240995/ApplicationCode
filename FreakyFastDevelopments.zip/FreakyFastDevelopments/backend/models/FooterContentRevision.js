import mongoose from "mongoose";
const FooterContentRevisionSchema = new mongoose.Schema({
  data: { type: Object, required: true },
  published: { type: Boolean, default: false },
  status: { type: String, enum: ["draft","pending_review","approved","scheduled","published","rejected"], default: "draft" },
  by: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
  note: { type: String, default: "" }
}, { timestamps: true, versionKey: false });
export default mongoose.model("FooterContentRevision", FooterContentRevisionSchema);
