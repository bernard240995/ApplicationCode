import mongoose from "mongoose";
const CartSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  email: String,
  items: [{ productId: String, name: String, price: Number, qty: Number, imageUrl: String }],
  remindersSent: [{ type: String }], // "24h","3d","7d"
  updatedAt: { type: Date, default: Date.now }
}, { timestamps: true, versionKey: false });
export default mongoose.model("Cart", CartSchema);
