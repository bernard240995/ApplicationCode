// backend/models/Ticket.js
import mongoose from 'mongoose';

const TicketSchema = new mongoose.Schema({
  subject: { type: String, required: true },
  message: { type: String, required: true },
  status: { type: String, enum: ['open','pending','resolved','closed'], default: 'open' },
  priority: { type: String, enum: ['low','normal','high','urgent'], default: 'normal' },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  name: String,
  email: String,
  phone: String,
  orderId: { type: mongoose.Schema.Types.ObjectId, ref: 'Order' },
  meta: {},
}, { timestamps: true });

export default mongoose.models.Ticket || mongoose.model('Ticket', TicketSchema);
