// backend/models/HeroVariant.js
import mongoose from 'mongoose';
const HeroVariantSchema = new mongoose.Schema({
  key: { type: String, default: 'home_hero', index: true }, // experiment key
  variant: { type: String, required: true }, // 'A' / 'B' / 'C' etc.
  headline: { type: String, default: '' },
  subhead: { type: String, default: '' },
  ctaText: { type: String, default: 'Shop Now' },
  ctaHref: { type: String, default: '/shop' },
  imageUrl: { type: String, default: '/assets/banners/banner1.jpg' },
  status: { type: String, enum: ['draft','active'], default: 'active' },
  weight: { type: Number, default: 1 } // for future weighted assign
}, { timestamps: true });
export default mongoose.models.HeroVariant || mongoose.model('HeroVariant', HeroVariantSchema);
