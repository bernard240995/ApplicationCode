import mongoose from "mongoose";
const S = new mongoose.Schema({ type:{type:String,index:true}, payload:Object, status:{type:String,default:"pending",index:true}, attempts:{type:Number,default:0} }, { timestamps:true, versionKey:false });
export default mongoose.model("OutboxEvent", S);
