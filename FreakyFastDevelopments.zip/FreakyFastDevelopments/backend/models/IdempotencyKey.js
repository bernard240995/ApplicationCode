import mongoose from "mongoose";
const S = new mongoose.Schema({ key:{type:String,unique:true,index:true}, method:String, path:String, status:Number, response:Object }, { timestamps:true, versionKey:false });
S.index({ createdAt:1 }, { expireAfterSeconds: 86400 });
export default mongoose.model("IdempotencyKey", S);
