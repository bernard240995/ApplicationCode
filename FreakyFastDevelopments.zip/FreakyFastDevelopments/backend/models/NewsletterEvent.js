import mongoose from "mongoose";
const NewsletterEventSchema = new mongoose.Schema({
  email: String,
  provider: String,
  event: String,
  payload: Object,
  createdAt: { type: Date, default: Date.now }
}, { versionKey:false });
export default mongoose.model("NewsletterEvent", NewsletterEventSchema);
