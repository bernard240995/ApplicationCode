// backend/models/RewardPoint.js
import mongoose from 'mongoose';
const RewardPointSchema = new mongoose.Schema({
  email: String,
  points: { type:Number, default:0 },
  note: String
}, { timestamps:true });
export default mongoose.models.RewardPoint || mongoose.model('RewardPoint', RewardPointSchema);
