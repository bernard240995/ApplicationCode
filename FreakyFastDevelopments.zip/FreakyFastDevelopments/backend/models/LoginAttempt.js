import mongoose from "mongoose";
const LoginAttemptSchema = new mongoose.Schema({
  email: { type: String, index: true },
  ip: { type: String, index: true },
  count: { type: Number, default: 0 },
  lastAt: { type: Date, default: Date.now }
}, { timestamps: true, versionKey: false });
LoginAttemptSchema.index({ email: 1, ip: 1 }, { unique: true, sparse: true });
export default mongoose.model("LoginAttempt", LoginAttemptSchema);
