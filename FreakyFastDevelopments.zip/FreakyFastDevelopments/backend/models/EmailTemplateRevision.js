import mongoose from "mongoose";
const EmailTemplateRevision = new mongoose.Schema({
  name: { type: String, index: true },
  content: String,
  author: String
}, { timestamps: true, versionKey: false });
export default mongoose.model("EmailTemplateRevision", EmailTemplateRevision);
