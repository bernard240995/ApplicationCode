// backend/models/PromoCode.js
import mongoose from 'mongoose';
const PromoCodeSchema = new mongoose.Schema({
  code: { type:String, unique:true, index:true },
  type: { type:String, enum:['percent','shipping','fixed'], default:'percent' },
  value: { type:Number, default:0 },
  active: { type:Boolean, default:true },
  startsAt: { type:Date },
  endsAt: { type:Date },
}, { timestamps:true });
export default mongoose.models.PromoCode || mongoose.model('PromoCode', PromoCodeSchema);
