// backend/models/Product.js
import mongoose from 'mongoose';
const ProductSchema = new mongoose.Schema({
  title: { type:String, required:true },
  slug: { type:String, required:true, unique:true, index:true },
  description: { type:String, default:'' },
  price: { type:Number, default:0 }, // in minor units? we will store in pence with priceMinor
  priceMinor: { type:Number, default:0 }, // pence
  currency: { type:String, default:'GBP' },
  images: { type:[String], default:[] },
  category: { type:String, default:'Apparel' },
  sizes: { type:[String], default:[] },
  colors: { type:[String], default:[] },
  sku: { type:String, default:'' },
  status: { type:String, enum:['draft','active','archived'], default:'active' },
  stock: { type:Number, default:0 },
  minStock: { type:Number, default:0 },
  maxStock: { type:Number, default:9999 },
}, { timestamps:true });
export default mongoose.models.Product || mongoose.model('Product', ProductSchema);
