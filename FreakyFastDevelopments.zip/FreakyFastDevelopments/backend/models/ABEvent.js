// backend/models/ABEvent.js
import mongoose from 'mongoose';
const ABEventSchema = new mongoose.Schema({
  exp: { type: String, index: true },
  var: { type: String },
  type: { type: String, enum: ['impression','click'], index: true },
  path: String,
  user: String,
}, { timestamps: true });
export default mongoose.models.ABEvent || mongoose.model('ABEvent', ABEventSchema);
