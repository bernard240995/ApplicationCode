import mongoose from "mongoose";
const FooterContentSchema = new mongoose.Schema({
  data: { type: Object, required: true },
  published: { type: Boolean, default: false },
  status: { type: String, enum: ["draft","pending_review","approved","scheduled","published","rejected"], default: "draft" },
  publishAt: { type: Date, default: null },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
  approvedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
  note: { type: String, default: "" }
}, { timestamps: true, versionKey: false });
export default mongoose.model("FooterContent", FooterContentSchema);
