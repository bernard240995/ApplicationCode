
import mongoose from "mongoose";
const CouponSchema = new mongoose.Schema({
  code: { type: String, unique: true, required: true, uppercase: true, trim: true },
  type: { type: String, enum: ["percent","fixed"], required: true },
  value: { type: Number, required: true }, // percent (0-100) or fixed pence
  startsAt: { type: Date, default: () => new Date(Date.now() - 86400000) },
  endsAt: { type: Date },
  active: { type: Boolean, default: true },
  minSubtotal: { type: Number, default: 0 }, // in pence
  maxUses: { type: Number, default: 0 }, // 0 = unlimited
  used: { type: Number, default: 0 }
}, { timestamps: true, versionKey: false });

CouponSchema.methods.isValidNow = function(subtotal){
  const now = new Date();
  if (!this.active) return false;
  if (this.startsAt && now < this.startsAt) return false;
  if (this.endsAt && now > this.endsAt) return false;
  if (this.maxUses && this.used >= this.maxUses) return false;
  if (subtotal < (this.minSubtotal || 0)) return false;
  return true;
};

export default mongoose.model("Coupon", CouponSchema);
