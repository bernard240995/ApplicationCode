// backend/models/OrderEvent.js
import mongoose from 'mongoose';
const OrderEventSchema = new mongoose.Schema({
  orderId: String,
  type: String, // created|paid|packed|shipped|delivered|refund|note
  message: String,
  actor: String,
}, { timestamps:true });
export default mongoose.models.OrderEvent || mongoose.model('OrderEvent', OrderEventSchema);
