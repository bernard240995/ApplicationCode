import mongoose from 'mongoose'

export async function connectDb(){
  const uri = process.env.MONGO_URL || 'mongodb://127.0.0.1:27017/freakyfast_test'
  if(mongoose.connection.readyState===1) return mongoose
  await mongoose.connect(uri, { serverSelectionTimeoutMS: 5000 })
  return mongoose
}

export async function clearDb(){
  const conn = mongoose.connection
  const cols = await conn.db.listCollections().toArray()
  for(const c of cols){
    await conn.db.collection(c.name).deleteMany({})
  }
}

export async function closeDb(){
  if(mongoose.connection.readyState!==0){
    await mongoose.disconnect()
  }
}
