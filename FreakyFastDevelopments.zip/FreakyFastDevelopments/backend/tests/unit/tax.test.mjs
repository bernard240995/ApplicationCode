import assert from 'node:assert/strict'
import { calcTax } from '../../services/tax.js'
test('calcTax 20%', ()=>{
  const r = calcTax(10000,20)
  assert.equal(r.net, 10000)
  assert.equal(r.tax, 2000)
  assert.equal(r.gross, 12000)
})
