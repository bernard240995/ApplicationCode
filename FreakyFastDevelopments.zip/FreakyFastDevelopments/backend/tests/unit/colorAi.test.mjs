import assert from 'node:assert/strict'
import sharp from 'sharp'
import { dominantHexFromBuffer } from '../../services/colorAi.js'
test('dominantHexFromBuffer returns a hex', async ()=>{
  const buf = await sharp({ create: { width:16, height:16, channels:3, background:{ r:37, g:99, b:235 } } }).png().toBuffer()
  const hex = await dominantHexFromBuffer(buf)
  assert.ok(/^#[0-9A-F]{6}$/.test(hex))
})
