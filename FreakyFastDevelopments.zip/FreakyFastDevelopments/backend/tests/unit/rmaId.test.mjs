import assert from 'node:assert/strict'
import { makeRmaId } from '../../services/rmaId.js'
test('RMA id format', ()=>{
  const id = makeRmaId()
  assert.match(id, /^RMA-[A-Z0-9]{6}$/)
})
