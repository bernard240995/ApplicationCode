import assert from 'node:assert/strict'
import request from 'supertest'
import { connectDb, clearDb, closeDb } from '../helpers/db.mjs'
import app from '../../server.js'
import Order from '../../models/Order.js'
import SupportTicket from '../../models/SupportTicket.js'

test('DSAR export and delete', async ()=>{
  await connectDb(); await clearDb()
  await Order.create({ email:'person@example.com', items:[], total:0, status:'paid' })
  await SupportTicket.create({ email:'person@example.com', subject:'Help', messages:[{ role:'user', content:'Hi', at:new Date() }], status:'open' })
  let r = await request(app).get('/privacy/export').query({ email: 'person@example.com' })
  assert.equal(r.status, 200)
  assert.ok((r.body.orders||[]).length===1)
  r = await request(app).post('/privacy/delete').set('Content-Type','application/json').send({ email:'person@example.com' })
  assert.equal(r.status, 200)
  await closeDb()
})
