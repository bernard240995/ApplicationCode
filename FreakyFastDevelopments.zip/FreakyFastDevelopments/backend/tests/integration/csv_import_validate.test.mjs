import assert from 'node:assert/strict'
import request from 'supertest'
import { connectDb, clearDb, closeDb } from '../helpers/db.mjs'
import app from '../../server.js'
import Product from '../../models/Product.js'

const payload = `name,slug,description,price_pennies,audience,brand,category,tags,material,season,warranty_months,origin_country,hs_code,weight_grams,dimensions_mm,shipping_class,lead_time_days,minStock,maxStock,stock_total,variants
Air Runner,air-runner,Lightweight running shoe,12999,men,FreakyFast,Shoes,"running,summer",Mesh,SS24,24,GB,640411,850,300x200x120,standard,7,2,20,40,"Blue|auto|air-blue|20|S:air-blue-s:10,M:air-blue-m:10|https://example.com/blue1.jpg|12345678|FF-AR-BL|BLU-CODE"`

test('CSV validate and import', async ()=>{
  await connectDb(); await clearDb()
  // validate
  let r = await request(app).post('/api/admin/products/validate').set('Content-Type','text/plain').send(payload)
  assert.equal(r.status, 200)
  // import
  r = await request(app).post('/api/admin/products/import').set('Content-Type','text/plain').send(payload)
  assert.equal(r.status, 200)
  const p = await Product.findOne({ slug:'air-runner' }).lean()
  assert.ok(p)
  await closeDb()
})
