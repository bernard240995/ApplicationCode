import assert from 'node:assert/strict'
import request from 'supertest'
import { connectDb, clearDb, closeDb } from '../helpers/db.mjs'
import app from '../../server.js'

test('checkout webhook stores order', async ()=>{
  await connectDb(); await clearDb()
  const fakeEvent = {
    type: 'checkout.session.completed',
    data: { object: { id: 'cs_test_123', customer_details: { email: 'buyer@example.com' }, metadata: { cart: JSON.stringify([{ slug:'x', name:'X', sku:'sku', qty:2, price:1500 }]) } } }
  }
  const r = await request(app).post('/checkout/webhook').set('Content-Type','application/json').send(JSON.stringify(fakeEvent))
  assert.equal(r.status, 200)
  // try fetch via order-by-session
  const r2 = await request(app).get('/checkout/order-by-session').query({ sid: 'cs_test_123' })
  assert.equal(r2.status, 200)
  assert.equal(r2.body.order.email, 'buyer@example.com')
  await closeDb()
})
