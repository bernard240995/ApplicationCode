import assert from 'node:assert/strict'
import request from 'supertest'
import { connectDb, clearDb, closeDb } from '../helpers/db.mjs'
import app from '../../server.js'
import Order from '../../models/Order.js'

test('RMA request creates an RMA', async ()=>{
  await connectDb(); await clearDb()
  const o = await Order.create({ email:'test@example.com', items:[{ name:'P', sku:'sku1', qty:1, price:1000 }], total:1000, status:'paid' })
  const r = await request(app).post('/returns/request').send({ orderId: String(o._id), email: 'test@example.com', reason:'No fit' }).set('Content-Type','application/json')
  assert.equal(r.status, 200)
  assert.equal(r.body.ok, true)
  assert.match(r.body.rma.rmaId, /^RMA-/)
  await closeDb()
})
