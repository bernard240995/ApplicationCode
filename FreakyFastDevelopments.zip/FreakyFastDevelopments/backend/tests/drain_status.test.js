import request from "supertest";
import express from "express";
import drainRoute from "../routes/drain.js";
import drainGuard from "../middleware/drainGuard.js";

const app = express();
app.use(express.json());
app.use("/status/drain", drainRoute);
app.use(drainGuard);
app.post("/write", (req,res)=> res.json({ ok: true }));

describe("Drain", ()=>{
  it("blocks writes when drained", async ()=>{
    await request(app).post("/status/drain").set("x-drain-secret","").send({});
    const r = await request(app).post("/write");
    expect(r.status).toBe(503);
  });
  it("allows writes when undrained", async ()=>{
    await request(app).delete("/status/drain").set("x-drain-secret","").send({});
    const r = await request(app).post("/write");
    expect(r.status).toBe(200);
  });
});
