import assert from 'node:assert/strict'
import request from 'supertest'
import app from '../server.js'
process.env.STRIPE_FAKE='1'
test('fake checkout session returns url', async ()=>{ const r = await request(app).post('/checkout/session').send({ items:[{ slug:'aero-runner', variantIndex:0, quantity:1 }] }).set('Content-Type','application/json'); assert.equal(r.status,200); assert.equal(r.body.ok,true); assert.ok(r.body.url) })
