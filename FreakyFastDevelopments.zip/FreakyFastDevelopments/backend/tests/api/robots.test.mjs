import assert from 'node:assert/strict'
import request from 'supertest'
import app from '../../server.js'
test('robots.txt serves and contains Sitemap', async ()=>{
  const r = await request(app).get('/robots.txt')
  assert.equal(r.status, 200)
  assert.match(r.text, /Sitemap:/)
})
