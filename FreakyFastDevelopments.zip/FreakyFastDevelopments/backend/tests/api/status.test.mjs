import assert from 'node:assert/strict'
import request from 'supertest'
import app from '../../server.js'
test('/status/services is JSON', async ()=>{
  const r = await request(app).get('/status/services')
  assert.equal(r.status, 200)
  assert.equal(typeof r.body, 'object')
})
