import assert from 'node:assert/strict'
import request from 'supertest'
import app from '../../server.js'
test('sitemap.xml responds', async ()=>{
  const r = await request(app).get('/sitemap.xml')
  assert.equal(r.status, 200)
  assert.match(r.text, /<urlset/)
})
