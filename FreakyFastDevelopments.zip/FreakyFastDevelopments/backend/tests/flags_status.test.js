import request from "supertest";
import express from "express";
import flagsRoute from "../routes/flags.js";
import statusRoute from "../routes/status.js";

const app = express();
app.use(express.json());
app.use("/api/flags", flagsRoute);
app.use("/", statusRoute);

describe("Flags & Status", ()=>{
  it("returns health ok", async ()=>{
    const r = await request(app).get("/status/health");
    expect(r.status).toBe(200);
    expect(r.body.ok).toBe(true);
  });
  it("reads and writes flags", async ()=>{
    const put = await request(app).put("/api/flags/admin").send({ data: { testFlag: true } });
    expect(put.status).toBe(200);
    const get = await request(app).get("/api/flags");
    expect(get.body.data.testFlag).toBe(true);
  });
});
