/* Seed demo data for local/staging */
const mongoose = require('mongoose');
const Product = require('../models/Product');

async function run(){
  const mongo = process.env.MONGO_URL || 'mongodb://localhost:27017/freakyfast';
  await mongoose.connect(mongo);
  const items=[
    { title:'Men Shoe', description:'Comfort runner', pricePence:6900, images:[{url:'/media/test-products/shoe.png'}], stock:20, brand:'FreakyFast', popularity:15 },
    { title:'Women Hoodie', description:'Soft fleece', pricePence:4900, images:[{url:'/media/test-products/hoodie.png'}], stock:15, brand:'FreakyFast', popularity:20 },
    { title:'Smart Watch', description:'Fitness + Alerts', pricePence:12900, images:[{url:'/media/test-products/watch.png'}], stock:8, brand:'FreakyFast', popularity:30 },
    { title:'Travel Bag', description:'Carry-on', pricePence:7900, images:[{url:'/media/test-products/bag.png'}], stock:12, brand:'FreakyFast', popularity:10 },
    { title:'Cap', description:'Adjustable', pricePence:1900, images:[{url:'/media/test-products/cap.png'}], stock:50, brand:'FreakyFast', popularity:5 },
    { title:'Jacket', description:'All-weather', pricePence:10900, images:[{url:'/media/test-products/jacket.png'}], stock:5, brand:'FreakyFast', popularity:18 },
  ];
  await Product.deleteMany({});
  await Product.insertMany(items);
  console.log('Seeded products:', items.length);
  await mongoose.disconnect();
}

run().catch(e=>{ console.error(e); process.exit(1) });
