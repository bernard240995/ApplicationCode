
import "dotenv/config.js";
import mongoose from "mongoose";
import Coupon from "../models/Coupon.js";

const uri = process.env.MONGODB_URI || "mongodb://localhost:27017/freakyfast";
await mongoose.connect(uri);

const seeds = [
  { code: "WELCOME10", type: "percent", value: 10 },
  { code: "FF5", type: "fixed", value: 500 },
  { code: "VIP20", type: "percent", value: 20, minSubtotal: 5000 }
];

for (const s of seeds){
  await Coupon.updateOne({ code: s.code }, { $setOnInsert: s }, { upsert: true });
  console.log("Upserted:", s.code);
}
await mongoose.disconnect();
console.log("Done.");
