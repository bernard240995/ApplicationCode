import mongoose from "mongoose";
import dotenv from "dotenv";
import { runDbBootstrap } from "../bootstrap/dbInit.js";
dotenv.config({ path: process.env.DOTENV_PATH || ".env" });

const uri = process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/freakyfast";
await mongoose.connect(uri);
await runDbBootstrap();
await mongoose.disconnect();
console.log("DB bootstrap complete.");
