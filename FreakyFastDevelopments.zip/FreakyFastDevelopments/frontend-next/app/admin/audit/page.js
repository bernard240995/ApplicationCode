'use client'
import React from 'react'
export default function Audit(){
  const API=(process.env.NEXT_PUBLIC_API_BASE||'http://localhost:5000')
  return (<main className='container' style={{padding:'24px 0'}}>
    <h2>Audit Log</h2>
    <div style={{marginBottom:8}}><a className='btn' href={API+'/api/admin/audit/export'} target='_blank' rel='noreferrer'>Export CSV</a></div>
    <div className='text-sm' style={{opacity:.7}}>Live events will display here.</div>
  </main>)
}
