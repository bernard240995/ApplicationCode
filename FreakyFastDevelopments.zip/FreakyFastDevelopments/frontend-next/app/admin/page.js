'use client'
export default function Admin(){ const tiles=[{href:'/admin/products/import',label:'Import Products'},{href:'/admin/qa',label:'QA Dashboard'}]; return (<main className='container' style={{padding:'24px 0'}}><h2>Admin</h2><ul>{tiles.map(t=>(<li key={t.href}><a className='link' href={t.href}>{t.label}</a></li>))}</ul></main>) }
