
// app/admin/fulfillment/page.js
import dynamic from 'next/dynamic';
const AdminFulfillment = dynamic(()=>import('../../../src/admin/pages/AdminFulfillment'), { ssr:false });
export default function Page(){ return <main><AdminFulfillment/></main>; }
