
// app/account/page.js
'use client'
import React, { useEffect, useState } from 'react';

export default function AccountPage(){
  const [email, setEmail] = useState('sam.wilson@example.co.uk');
  const [balance, setBalance] = useState(0);
  useEffect(()=>{
    (async()=>{
      const r = await fetch('/api/rewards/balance?email='+encodeURIComponent(email));
      const j = await r.json();
      if (j.ok) setBalance(j.points||0);
    })();
  }, [email]);
  return (<main>
    <h1>Your Account</h1>
    <div className="card">
      <h3>Loyalty Points</h3>
      <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email to lookup" />
      <div className="bal"><b>{balance}</b> points</div>
      <small>Rule: 100 points = £5 voucher</small>
    </div>
    <style jsx>{`
      .card{border:1px solid #e5e7eb;border-radius:16px;padding:16px;margin-top:12px}
      input{padding:8px;border:1px solid #ddd;border-radius:8px;margin-bottom:8px}
      .bal{font-size:1.4rem;margin-top:4px}
    `}</style>
  </main>);
}
