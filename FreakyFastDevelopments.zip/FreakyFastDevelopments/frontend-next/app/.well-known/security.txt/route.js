export async function GET(){
  const contact = process.env.NEXT_PUBLIC_SECURITY_CONTACT || 'mailto:security@freakyfast.local'
  const policy = process.env.NEXT_PUBLIC_SECURITY_POLICY_URL || ''
  const lines = [`Contact: ${contact}`]
  if(policy) lines.push(`Policy: ${policy}`)
  lines.push('Preferred-Languages: en')
  return new Response(lines.join('\n'), { headers: { 'Content-Type': 'text/plain; charset=utf-8' } })
}
