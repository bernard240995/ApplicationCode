# FreakyFast — Release Build (Round26)

## Local quickstart
```bash
# Backend
cd backend
cp .env.example .env   # set MONGO_URL, Stripe, SMTP
npm i
npm run seed           # optional demo data
npm run dev

# Frontend
cd ../frontend-next
cp .env.local.example .env.local
npm i
npm run dev
```

## Health checks
- Backend: `GET http://localhost:4000/health`
- Frontend: `GET http://localhost:3000/health`

## Production (Docker)
```bash
# Backend
cd backend
docker build -t freakyfast-backend .
docker run -p 4000:4000 --env-file .env freakyfast-backend

# Frontend
cd ../frontend-next
docker build -t freakyfast-frontend .
docker run -p 3000:3000 --env NEXT_PUBLIC_BACKEND_URL=http://localhost:4000 freakyfast-frontend
```

## Stripe Webhook
Use Stripe CLI in dev:
```bash
stripe listen --forward-to localhost:4000/api/stripe/webhook
```
Set `STRIPE_WEBHOOK_SECRET` in backend `.env` accordingly.

## Notes
- Dummy product images use Unsplash URLs for layout testing.
- Right-click and copy are disabled site-wide (can be toggled in `public/protect.js`).
- Admin pages provide promos, reviews moderation, rewards, banners, fulfillment, exports, and labels.
- This Round26 includes robustness & deployment polish on top of Round25 ultra UI/UX.
Generated: 2025-09-15T22:53:17.239277Z
