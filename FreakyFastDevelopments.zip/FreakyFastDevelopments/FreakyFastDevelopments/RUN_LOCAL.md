# Run Locally

## Backend
```
cd backend
npm i
npm run dev
```
Ensure .env has:
```
MONGO_URL=mongodb://localhost:27017/freakyfast
FRONTEND_URL=http://localhost:3000
TESTING_MODE=true
TESTING_MODE_PASSCODE=2409

# Optional
SENTRY_DSN=
SMTP_HOST=
SMTP_PORT=587
SMTP_USER=
SMTP_PASS=
CSP_REPORT_ONLY=true
CSP_REPORT_URI=
```
## Frontend (Next.js)
```
cd FreakyFast_Ultra_Enterprise/frontend-next
npm i
npm run dev
```
Set (optional) in .env.local:
```
NEXT_PUBLIC_SENTRY_DSN=
```


## When to start local testing
- ✅ Core pages render with the new theme and header/footer/logo
- ✅ Chat bot + ticketing flows reach the backend and create tickets
- ✅ Admin: CMS, Settings, Tickets, SEO, Experiments, Analytics pages open and save
- ✅ Route-aware SEO meta applies (title/description/OG) per URL
- ✅ Checkout progress bar shows on /checkout

**This build meets the above criteria as of 2025-09-11.**

### Start here
1) Run backend and frontend (see above), seed at least one Hero variant in **/admin/experiments**.
2) Hit the homepage; confirm the hero content matches the admin variant; click the CTA (CTR will appear in **Admin Analytics**).
3) Use the chat widget; verify an open ticket appears in **Admin Tickets**, and an email is sent if SMTP is set.


## Round 6 additions (2025-09-11)
- Checkout form now validates and saves state in localStorage.
- Order email template helper (`renderOrderEmail`) added in backend/utils/email.js.
- Sitemap generator now includes product pages.
- CSP: stricter rollout guidance added (disable reportOnly after validating).
- ProductCard uses Next.js <Image> for optimization.

### Suggested tests now:
1) Fill checkout form, refresh page, confirm values persist, errors show for invalid input.
2) Trigger order creation (stub or admin action) and verify email HTML via renderOrderEmail.
3) Hit /api/sitemap/sitemap.xml and confirm product URLs appear.
4) Ensure product cards render images with Next <Image> optimization.


## Printables & Invoices (HTML)
- Invoice: `POST /api/print/invoice/html`
- Packing Label: `POST /api/print/label/html`

Example:
```
curl -X POST http://localhost:4000/api/print/invoice/html \
  -H 'Content-Type: application/json' \
  -d '{ "id":"FF-1001","name":"Sam","email":"sam@example.com","address":"221B Baker St, London","postcode":"NW1 6XE","total":"£129.99","items":[{"title":"Hoodie","qty":1,"price":"£79.99"},{"title":"Cap","qty":1,"price":"£50.00"}] }'
```
The HTML is printer-friendly and includes your **company logo** automatically (pulled from Admin **Settings → site.logoUrl**, falling back to `/assets/brand/logo-header.png`).

## Emails with logo
All **ticket** and **order** emails render the logo at the top using `FRONTEND_URL` + `site.logoUrl`.


## Stripe-only payments
Set in backend `.env` and frontend `.env.local`:
```
STRIPE_SECRET_KEY=sk_test_...
NEXT_PUBLIC_STRIPE_PK=pk_test_...
ADD_SCRIPT_SRC=https://js.stripe.com
ADD_CONNECT_SRC=https://api.stripe.com,https://r.stripe.com
ADD_IMG_SRC=https://*.stripe.com
```
The checkout page shows a **Stripe** button. Clicking it creates a Checkout Session via `/api/payments/stripe/create-session` and redirects securely to Stripe.
All legacy PayPal code has been removed/neutralized.


## Stripe Webhook (orders)
Add to backend `.env`:
```
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
```
Start backend, then run Stripe CLI:
```
stripe listen --forward-to localhost:4000/api/payments/stripe/webhook
```
When a Checkout Session completes, an order record is created and a confirmation email is sent (with logo).
You can view orders in **Admin → Orders** and print **Invoice/Label**.


## PDFs (optional)
For server-side PDFs, install puppeteer in backend:
```
cd backend && npm i puppeteer
```
Endpoints:
- `POST /api/print/invoice/pdf`
- `POST /api/print/label/pdf`
If puppeteer is not installed, the endpoints respond with a helpful 501 message.


## Company footer in emails
Set these in Admin → Settings to show in all outgoing emails:
- `company.vat`
- `company.reg`
- `company.address`

## Order timeline & notes
- View an order in **Admin → Orders** (click row) to see the timeline and add internal notes.


## Manual tracking (Admin)
- In **Admin → Orders**, add a *Carrier*, *Tracking #*, and optional *Tracking URL*.
- Click **Save** to store it, automatically mark the order as **shipped**, create a timeline event, and send the customer a **shipment email** with a tracking link.


## Delivered workflow
- In **Admin → Orders**, use **Mark delivered** to set `deliveredAt` and notify the customer automatically.
- Use **Save** in the Tracking box to store carrier/number/URL and auto-mark as shipped.


## Core pages & footer
- On server start we ensure the essential pages exist (About, Returns, Shipping, Size Guide, Contact, Privacy, Terms, Cookies).
- You can edit them from the Admin CMS; footer links are always visible site-wide.


## Products (Shop-only)
- Public API: `GET /api/products` returns active products with stock logic: if `stock < minStock` → `stock = 0`; otherwise returns actual stock.
- Admin: `GET/POST/PATCH /api/admin/products` for CRUD.
- Frontend: `GET /shop` lists products only on the Shop page (with Out of stock badge when `stock=0`).

### Image guidance
Seed products use external placeholder images (Unsplash). Replace image URLs in Admin with your real photos or CDN links at any time.
