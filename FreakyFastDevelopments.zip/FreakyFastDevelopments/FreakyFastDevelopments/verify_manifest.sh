#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")"; pwd)"
MAN="$ROOT/MANIFEST.json"
if [ ! -f "$MAN" ]; then echo "MANIFEST.json not found"; exit 1; fi
jq -r '.entries[] | [.path,.sha256]|@tsv' "$MAN" | while IFS=$'\t' read -r p h; do
  f="$ROOT/../$p"
  if [ ! -f "$f" ]; then echo "MISSING: $p"; continue; fi
  calc=$(sha256sum "$f" | awk '{print $1}')
  if [ "$calc" != "$h" ]; then echo "CHANGED: $p"; fi
done
echo "Done. Inspect output above for MISSING/CHANGED files."
