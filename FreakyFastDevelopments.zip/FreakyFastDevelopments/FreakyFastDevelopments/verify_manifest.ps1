$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$man = Join-Path $root 'MANIFEST.json'
if (!(Test-Path $man)) { Write-Error 'MANIFEST.json not found' }
$manifest = Get-Content $man -Raw | ConvertFrom-Json
$missing = 0; $changed = 0
foreach ($e in $manifest.entries) {
  $f = Join-Path (Split-Path $root) $e.path
  if (!(Test-Path $f)) { Write-Host "MISSING: $($e.path)"; $missing++ ; continue }
  $hash = (Get-FileHash -Path $f -Algorithm SHA256).Hash.ToLower()
  if ($hash -ne $e.sha256) { Write-Host "CHANGED: $($e.path)"; $changed++ }
}
Write-Host "Done. See lines above for MISSING/CHANGED"
